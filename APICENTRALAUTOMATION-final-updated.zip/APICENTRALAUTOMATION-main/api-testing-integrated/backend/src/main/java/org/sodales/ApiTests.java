package org.sodales;

import model.ApiTestCase;
import model.AuthContext;
import model.TestRunContext;
import reader.ExcelReader;
import runner.ApiTestRunner;

import java.time.LocalDateTime;
import java.util.List;

public class ApiTests {

    public static void run(TestRunContext context, AuthContext authContext) {
        LocalDateTime testcaseexecutionstarttime = LocalDateTime.now();

        GlobalVariableHandler variableHandler = new GlobalVariableHandler();
        List<ApiTestCase> tests = ExcelReader.readTestCases(context.excelPath);

        LogCollector.log("Execution of the Test cases has been started..");
        LogCollector.log("Execution Start time: " + testcaseexecutionstarttime);
        LogCollector.log("Using Excel file: " + context.excelPath);
        LogCollector.log("Run ID: " + context.runId);

        for (ApiTestCase test : tests) {
            if (test.skip != null && test.skip.equalsIgnoreCase("yes")) {
                LogCollector.log("Skipping the test " + test.testName);
            } else {
                LogCollector.log("Currently Executing: " + test.testName);
                ApiTestRunner.run(test, context, variableHandler, authContext);
            }
        }

        LogCollector.log("Execution of the Test cases has been completed..");
        LocalDateTime testcaseexecutionstoptime = LocalDateTime.now();
        LogCollector.log("Execution Stop time: " + testcaseexecutionstoptime);
    }
}