package org.sodales;

import model.AuthContext;
import model.RunRecord;
import model.RunStatus;
import model.TestRunContext;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.*;
import java.nio.file.Files;
import java.time.Instant;
import java.util.*;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

@RestController
@CrossOrigin("*")
public class ApiController {
    private static final String BASE_TEMP_DIR = System.getProperty("java.io.tmpdir") + File.separator + "api-testing";
    private final RunManager runManager;

    public ApiController(RunManager runManager) { this.runManager = runManager; }

    @PostMapping("/run-tests")
    public ResponseEntity<?> runTests(@RequestParam("file") MultipartFile file,
                                      @RequestParam String authType,
                                      @RequestParam(required = false) String username,
                                      @RequestParam(required = false) String password,
                                      @RequestParam(required = false) String clientId,
                                      @RequestParam(required = false) String clientSecret,
                                      @RequestParam(required = false) String tokenUrl,
                                      @RequestParam(required = false) String grantType) {
        TestRunContext context = null;
        try {
            cleanupOldRuns();
            validateFile(file);
            AuthContext authContext = buildAuthContext(authType, username, password, clientId, clientSecret, tokenUrl, grantType);
            context = createRunContext();
            LogCollector.createRun(context.runId);
            file.transferTo(new File(context.excelPath));
            RunRecord record = runManager.submit(context, authContext);
            return ResponseEntity.status(HttpStatus.ACCEPTED)
                    .header("X-Run-Id", context.runId)
                    .body(runBody(record));
        } catch (IllegalArgumentException e) {
            String runId = context == null ? null : context.runId;
            if (runId != null) LogCollector.log(runId, "Validation failed: " + e.getMessage());
            return ResponseEntity.badRequest().body(errorBody("VALIDATION_FAILED", e.getMessage(), runId));
        } catch (Exception e) {
            String runId = context == null ? null : context.runId;
            if (runId != null) LogCollector.log(runId, "Unable to start run: " + e.getMessage());
            e.printStackTrace();
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(errorBody("RUN_START_FAILED", "Unable to start the test run: " + safeMessage(e), runId));
        }
    }

    @GetMapping({"/logs/{runId}", "/runs/{runId}/logs"})
    public ResponseEntity<?> getLogs(@PathVariable String runId) {
        if (!validRunId(runId)) return ResponseEntity.badRequest().body(errorBody("INVALID_RUN_ID", "Invalid Run ID", runId));
        if (runManager.get(runId) == null) return ResponseEntity.status(404).body(errorBody("RUN_NOT_FOUND", "Run not found", runId));
        return ResponseEntity.ok(LogCollector.getLogs(runId));
    }

    @GetMapping("/runs/{runId}/status")
    public ResponseEntity<?> getStatus(@PathVariable String runId) {
        if (!validRunId(runId)) return ResponseEntity.badRequest().body(errorBody("INVALID_RUN_ID", "Invalid Run ID", runId));
        RunRecord record = runManager.get(runId);
        if (record == null) return ResponseEntity.status(404).body(errorBody("RUN_NOT_FOUND", "Run not found", runId));
        return ResponseEntity.ok(runBody(record));
    }

    @GetMapping("/runs/{runId}/report")
    public ResponseEntity<?> downloadReport(@PathVariable String runId) {
        if (!validRunId(runId)) return ResponseEntity.badRequest().body(errorBody("INVALID_RUN_ID", "Invalid Run ID", runId));
        RunRecord record = runManager.get(runId);
        if (record == null) return ResponseEntity.status(404).body(errorBody("RUN_NOT_FOUND", "Run not found", runId));
        if (record.status != RunStatus.COMPLETED) {
            String msg = record.status == RunStatus.FAILED ? "Run failed; a report is not available." : "Run is not complete yet.";
            return ResponseEntity.status(HttpStatus.CONFLICT).body(errorBody("REPORT_NOT_READY", msg, runId));
        }
        try {
            byte[] zip = buildReportZip(record.context);
            return ResponseEntity.ok()
                    .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=" + runId + "_api-test-results.zip")
                    .contentType(MediaType.parseMediaType("application/zip"))
                    .body(zip);
        } catch (Exception e) {
            LogCollector.log(runId, "Report download failed: " + e.getMessage());
            return ResponseEntity.internalServerError().body(errorBody("REPORT_DOWNLOAD_FAILED", safeMessage(e), runId));
        }
    }

    private Map<String, Object> runBody(RunRecord record) {
        Map<String, Object> body = new LinkedHashMap<>();
        body.put("success", record.status != RunStatus.FAILED);
        body.put("runId", record.context.runId);
        body.put("status", record.status.name());
        body.put("errorCode", record.errorCode);
        body.put("message", record.errorMessage);
        body.put("createdAt", record.createdAt);
        body.put("startedAt", record.startedAt);
        body.put("completedAt", record.completedAt);
        return body;
    }

    private Map<String, Object> errorBody(String code, String message, String runId) {
        Map<String, Object> body = new LinkedHashMap<>();
        body.put("success", false); body.put("code", code); body.put("message", message);
        body.put("runId", runId == null ? "unavailable" : runId); body.put("timestamp", Instant.now().toString());
        return body;
    }

    private void validateFile(MultipartFile file) {
        if (file == null || file.isEmpty()) throw new IllegalArgumentException("Excel file is required.");
        String name = Optional.ofNullable(file.getOriginalFilename()).orElse("").toLowerCase(Locale.ROOT);
        if (!name.endsWith(".xlsx") && !name.endsWith(".xls")) throw new IllegalArgumentException("Only .xlsx or .xls Excel files are allowed.");
    }

    private AuthContext buildAuthContext(String authType, String username, String password, String clientId, String clientSecret, String tokenUrl, String grantType) {
        if (isBlank(authType)) throw new IllegalArgumentException("Authentication Type is required.");
        AuthContext auth = new AuthContext();
        auth.authenticationType = authType.trim().toUpperCase(Locale.ROOT);
        if ("BASIC".equals(auth.authenticationType)) {
            if (isBlank(username) || isBlank(password)) throw new IllegalArgumentException("Username and Password are required for BASIC authentication.");
            auth.username = username; auth.password = password;
        } else if ("OAUTH".equals(auth.authenticationType) || "OAUTH2".equals(auth.authenticationType)) {
            if (isBlank(clientId) || isBlank(clientSecret) || isBlank(tokenUrl)) throw new IllegalArgumentException("Token URL, Client ID and Client Secret are required for OAUTH2.");
            auth.clientId = clientId; auth.clientSecret = clientSecret; auth.tokenUrl = tokenUrl;
            auth.grantType = isBlank(grantType) ? "client_credentials" : grantType;
        } else throw new IllegalArgumentException("Unsupported Authentication Type: " + authType);
        return auth;
    }

    private TestRunContext createRunContext() throws IOException {
        String runId = "run_" + System.currentTimeMillis() + "_" + UUID.randomUUID();
        File dir = new File(BASE_TEMP_DIR, runId);
        Files.createDirectories(dir.toPath());
        TestRunContext c = new TestRunContext();
        c.runId = runId; c.runDir = dir.getAbsolutePath();
        c.excelPath = new File(dir, "api_test_data.xlsx").getAbsolutePath();
        c.htmlPath = new File(dir, "api_debug_report.html").getAbsolutePath();
        c.extentPath = new File(dir, "api_extent_debug_report.html").getAbsolutePath();
        c.csvPath = new File(dir, "api_debug_report.csv").getAbsolutePath();
        return c;
    }

    private byte[] buildReportZip(TestRunContext c) throws IOException {
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        try (ZipOutputStream zip = new ZipOutputStream(baos)) {
            addFileToZip(zip, new File(c.htmlPath), "api_debug_report.html");
            addFileToZip(zip, new File(c.csvPath), "api_debug_report.csv");
            addFileToZip(zip, new File(c.extentPath), "api_extent_debug_report.html");
        }
        return baos.toByteArray();
    }

    private void addFileToZip(ZipOutputStream zip, File file, String name) throws IOException {
        if (!file.exists()) return;
        zip.putNextEntry(new ZipEntry(name));
        Files.copy(file.toPath(), zip);
        zip.closeEntry();
    }

    private boolean validRunId(String id) { return id != null && id.matches("run_[A-Za-z0-9_-]+"); }
    private boolean isBlank(String v) { return v == null || v.trim().isEmpty(); }
    private String safeMessage(Throwable e) { return e.getMessage() == null ? e.getClass().getSimpleName() : e.getMessage(); }

    private void cleanupOldRuns() {
        File base = new File(BASE_TEMP_DIR); File[] files = base.listFiles(); if (files == null) return;
        long cutoff = System.currentTimeMillis() - 24L * 60 * 60 * 1000;
        for (File f : files) if (f.isDirectory() && f.lastModified() < cutoff) deleteDirectory(f);
    }
    private void deleteDirectory(File dir) {
        File[] files = dir.listFiles(); if (files != null) for (File f : files) { if (f.isDirectory()) deleteDirectory(f); else f.delete(); }
        dir.delete();
    }
}
