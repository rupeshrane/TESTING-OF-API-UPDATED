package org.sodales;

import java.time.Instant;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/** Run-scoped log storage. A request binds its Run ID for the duration of execution. */
public final class LogCollector {
    private static final Map<String, List<String>> RUN_LOGS = new ConcurrentHashMap<>();
    private static final ThreadLocal<String> CURRENT_RUN = new ThreadLocal<>();
    private LogCollector() {}

    public static void beginRun(String runId) {
        CURRENT_RUN.set(runId);
        RUN_LOGS.put(runId, Collections.synchronizedList(new ArrayList<>()));
        log("=== API test execution started ===");
    }
    public static void endRun() { CURRENT_RUN.remove(); }
    public static void log(String message) {
        String runId = CURRENT_RUN.get();
        String line = Instant.now() + " " + (message == null ? "" : message);
        System.out.println((runId == null ? "[unscoped] " : "[" + runId + "] ") + line);
        if (runId != null) {
            List<String> lines = RUN_LOGS.computeIfAbsent(runId, k -> Collections.synchronizedList(new ArrayList<>()));
            synchronized (lines) {
                lines.add(line);
                // Bound memory usage while retaining the most recent diagnostic context.
                if (lines.size() > 3000) lines.subList(0, 1000).clear();
            }
        }
    }
    public static List<String> getLogs(String runId) {
        List<String> lines = RUN_LOGS.get(runId);
        if (lines == null) return List.of();
        synchronized (lines) { return new ArrayList<>(lines); }
    }
    /** Legacy compatibility: returns only the current execution's logs. */
    public static List<String> getLogs() {
        String runId = CURRENT_RUN.get();
        return runId == null ? List.of() : getLogs(runId);
    }
    /** Legacy compatibility: clears only the current run, never other users' logs. */
    public static void clear() {
        String runId = CURRENT_RUN.get();
        if (runId != null) RUN_LOGS.put(runId, Collections.synchronizedList(new ArrayList<>()));
    }
    public static void removeRun(String runId) { RUN_LOGS.remove(runId); }
}
