# Error handling and concurrent execution update

## What was changed
- Run-scoped log storage keyed by Run ID. `LogCollector` uses a `ThreadLocal` only to associate log statements emitted during the current synchronous request with its run; the stored log collections are concurrent and independently retrievable.
- Added `GET /logs/{runId}` and `GET /runs/{runId}/logs` while retaining the existing run-specific UI route.
- Removed `System.setProperty` / `System.getProperty` use for extracted test variables. `GlobalVariableHandler` now stores variables in an instance-local concurrent map; `ApiTests.run` creates one handler per run.
- Replaced the static ExtentReports `HashMap` with `ConcurrentHashMap` to avoid unsafe concurrent map access.
- Added structured JSON errors for validation and unexpected execution failures, and attached `X-Run-Id` to normal and handled validation responses.
- Frontend now parses JSON error messages, captures the Run ID on failed responses, and uses `VITE_API_BASE_URL` (default `http://localhost:9090`) instead of a hard-coded LAN IP.
- Configured embedded Tomcat request worker and queue limits in `application.yml`.

## Important execution design note
The existing `/run-tests` contract returns a ZIP directly, so this update retains synchronous HTTP execution. Spring Boot's servlet container can process simultaneous requests on separate request threads; this update isolates the known shared state so concurrent requests do not clear or overwrite one another's run logs and extracted variables. This is not a durable asynchronous job queue. If you require queued background jobs, server-restart recovery, cross-instance execution, or cancel/status endpoints, that is a separate API/UI lifecycle change and requires persistent run storage and authenticated run ownership.

## Security note
The current project has permissive `@CrossOrigin("*")` and does not establish authenticated run ownership in the inspected source. Run IDs are identifiers, not access credentials. Do not expose this service to untrusted networks until authentication/authorization and CORS restrictions are configured. Never log credentials, tokens, or sensitive payloads.

## Build and verification
Run from `api-testing-integrated/backend`:

```bash
mvn clean test
mvn package
```

Run from `api-testing-integrated/frontend`:

```bash
npm ci
npm run build
```

Then test at least two simultaneous uploads with distinct files and same-named global variables; verify both requests finish and `/logs/{runId}` returns only the matching run's messages. Also test invalid auth, invalid file extension, malformed workbook, unreachable target API, and report-generation failure.

This source archive was statically reviewed and packaged, but a full Maven/frontend build and live multi-user test were not run in the preparation environment. Validate against your local Java 21 and Node/npm setup before deployment.
