package model;

public enum RunStatus {
    QUEUED, RUNNING, COMPLETED, FAILED
}
