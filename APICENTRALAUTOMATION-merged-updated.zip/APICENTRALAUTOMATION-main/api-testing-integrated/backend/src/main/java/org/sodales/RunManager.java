package org.sodales;

import model.AuthContext;
import model.RunRecord;
import model.RunStatus;
import model.TestRunContext;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import java.io.File;
import java.time.Instant;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.Executor;

@Service
public class RunManager {
    private final Map<String, RunRecord> runs = new ConcurrentHashMap<>();
    private final Executor executor;

    public RunManager(@Qualifier("testRunExecutor") Executor executor) {
        this.executor = executor;
    }

    public RunRecord submit(TestRunContext context, AuthContext authContext) {
        RunRecord record = new RunRecord(context);
        runs.put(context.runId, record);
        LogCollector.createRun(context.runId);
        LogCollector.log(context.runId, "Run queued.");
        try {
            executor.execute(() -> execute(record, authContext));
        } catch (RuntimeException e) {
            record.status = RunStatus.FAILED;
            record.errorCode = "QUEUE_FULL";
            record.errorMessage = "The server is currently at execution capacity. Please retry shortly.";
            record.completedAt = Instant.now();
            LogCollector.log(context.runId, "Unable to queue run: " + e.getMessage());
            throw e;
        }
        return record;
    }

    private void execute(RunRecord record, AuthContext authContext) {
        TestRunContext context = record.context;
        LogCollector.beginRun(context.runId);
        record.status = RunStatus.RUNNING;
        record.startedAt = Instant.now();
        try {
            LogCollector.log("Execution started.");
            ApiTests.run(context, authContext);
            verifyReports(context);
            record.status = RunStatus.COMPLETED;
            LogCollector.log("Execution completed successfully.");
        } catch (Throwable e) {
            record.status = RunStatus.FAILED;
            record.errorCode = e instanceof IllegalArgumentException ? "VALIDATION_FAILED" : "EXECUTION_FAILED";
            record.errorMessage = safeMessage(e);
            LogCollector.log("Execution failed: " + e.getClass().getSimpleName() + ": " + safeMessage(e));
            e.printStackTrace();
        } finally {
            record.completedAt = Instant.now();
            runner.ApiTestRunner.closeRun(context.runId);
            LogCollector.endRun();
        }
    }

    private void verifyReports(TestRunContext context) {
        if (!new File(context.htmlPath).exists() && !new File(context.csvPath).exists() && !new File(context.extentPath).exists()) {
            throw new IllegalStateException("Test execution finished but no report was generated.");
        }
    }

    public RunRecord get(String runId) { return runs.get(runId); }

    private String safeMessage(Throwable e) {
        String message = e.getMessage();
        if (message == null || message.isBlank()) return "The test execution failed. Check the run logs for details.";
        return message.length() > 1000 ? message.substring(0, 1000) : message;
    }
}
