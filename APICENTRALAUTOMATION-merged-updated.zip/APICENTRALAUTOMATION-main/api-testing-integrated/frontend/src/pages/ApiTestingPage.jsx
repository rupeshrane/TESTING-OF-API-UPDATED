import React, { useMemo, useRef, useState, useEffect } from "react";
import "../styles/global.css";

const API_BASE_URL = import.meta.env.VITE_API_BASE_URL || "http://localhost:9090";

const REQUIRED_COLUMNS = [
  "TestName",
  "Method",
  "URL",
  "Headers",
  "BodyType",
  "Payload",
  "FormData",
  "FilePath",
  "ExpectedStatus",
  "ExpectedResponseContains",
  "Skip?",
  "GlobalVariableJsonorXMLPath",
  "GlobalVariable",
  "JsonorXML",
];

const API_TESTING_DOCUMENTS = [
  {
    name: "API Testing Excel Template",
    url: "/docs/Dummy File For API Testing.xlsx",
    // available: false,
  },
  {
    name: "API TEST PDF",
    url: "/docs/",
    // available: true,
  },
  {
    name: "API Testing Process Document",
    url: "/docs/api-testing-process.docx",
    // available: true,
  },
];

export default function App() {
  const [authType, setAuthType] = useState("BASIC");
  const [file, setFile] = useState(null);
  const [status, setStatus] = useState("");
  const [busy, setBusy] = useState(false);
  const [reportUrl, setReportUrl] = useState("");
  const [showClientSecret, setShowClientSecret] = useState(false);
  const [dragActive, setDragActive] = useState(false);
  const [logs, setLogs] = useState([]);
  const [showDocsModal, setShowDocsModal] = useState(false);
  const [runId, setRunId] = useState(null);
  const [projects, setProjects] = useState([]);
  const [selectedProject, setSelectedProject] = useState("");
  const [newProject, setNewProject] = useState("");
  const [showAddProjectModal, setShowAddProjectModal] = useState(false);
  const [reportPortalEnabled, setReportPortalEnabled] = useState(false);
  const [projectsLoading, setProjectsLoading] = useState(false);

  const fileInputRef = useRef(null);

  const [form, setForm] = useState({
    username: "",
    password: "",
    clientId: "",
    clientSecret: "",
    tokenUrl: "",
    grantType: "client_credentials",
  });

  const canRun = useMemo(() => !!file && !busy, [file, busy]);

  // selection of File Excel
  const handleSelectedFile = (selected) => {
    setStatus("");
    setReportUrl("");

    if (!selected) {
      setFile(null);
      return;
    }

    const lower = selected.name.toLowerCase();
    if (!(lower.endsWith(".xlsx") || lower.endsWith(".xls"))) {
      setStatus("Only .xlsx or .xls files are allowed.");
      setFile(null);
      return;
    }

    setFile(selected);
    setStatus(`Selected file: ${selected.name}`);
  };

  const onFileChange = (event) => {
    const selected = event.target.files?.[0];
    handleSelectedFile(selected);
  };

  const handleDrag = (event) => {
    event.preventDefault();
    event.stopPropagation();

    if (event.type === "dragenter" || event.type === "dragover") {
      setDragActive(true);
    } else if (event.type === "dragleave") {
      setDragActive(false);
    }
  };

  const handleDrop = (event) => {
    event.preventDefault();
    event.stopPropagation();
    setDragActive(false);

    const droppedFile = event.dataTransfer.files?.[0];
    handleSelectedFile(droppedFile);
  };

  const updateField = (key, value) => {
    setForm((prev) => ({ ...prev, [key]: value }));
  };

  // Logs Function
  // const pollLogs = () => {
  //   console.log("Start polling for:", runId);
  //   const interval = setInterval(async () => {
  //     try {
  //       // const response = await fetch("http://192.168.3.173:9090/logs");
  //       const response = await fetch(`${API_BASE_URL}/logs/${runId}`);
  //       if (!response.ok) {
  //         clearInterval(interval);
  //         return;
  //       }

  //       const data = await response.json();
  //       setRunId(data.runId);
  //       setLogs(data);

  //       const joined = data.join(" | ");

  //       if (
  //         joined.includes("Execution of the Test cases has been completed..") ||
  //         joined.includes("Execution Stop time:")
  //       ) {
  //         clearInterval(interval);
  //       }
  //     } catch (error) {
  //       clearInterval(interval);
  //     }
  //   }, 1000);

  //   return interval;
  // };
  useEffect(() => {
    if (!runId) return;
    let stopped = false;

    const poll = async () => {
      try {
        const [statusResponse, logsResponse] = await Promise.all([
          fetch(`${API_BASE_URL}/runs/${runId}/status`),
          fetch(`${API_BASE_URL}/runs/${runId}/logs`),
        ]);

        if (logsResponse.ok) setLogs(await logsResponse.json());
        if (!statusResponse.ok) return;

        const run = await statusResponse.json();
        if (run.status === "QUEUED") setStatus(`Run ${runId} is queued...`);
        if (run.status === "RUNNING") setStatus(`Run ${runId} is running...`);
        if (run.status === "FAILED") {
          setStatus(`${run.errorCode || "EXECUTION_FAILED"}: ${run.message || "Execution failed."} (Run ID: ${runId})`);
          setBusy(false);
          stopped = true;
        }
        if (run.status === "COMPLETED") {
          setStatus(`Execution completed successfully. Run ID: ${runId}`);
          setBusy(false);
          stopped = true;
          await downloadReport(runId);
        }
      } catch (error) {
        setStatus(`Unable to read run status: ${error.message}`);
        setBusy(false);
        stopped = true;
      }
    };

    poll();
    const interval = setInterval(() => { if (!stopped) poll(); }, 1000);
    return () => clearInterval(interval);
  }, [runId]);

  const downloadReport = async (id) => {
    const response = await fetch(`${API_BASE_URL}/runs/${id}/report`);
    if (!response.ok) {
      const body = await response.json().catch(() => ({}));
      throw new Error(body.message || `Report download failed (${response.status})`);
    }
    const blob = await response.blob();
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `${id}_api-test-results.zip`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    setReportUrl(url);
  };

  // Download Documents from the Document Function
  const handleDocumentDownload = async (doc) => {
    try {
      const fileUrl = `${window.location.origin}${doc.url}`;
      const response = await fetch(fileUrl, { cache: "no-store" });

      if (!response.ok) {
        setStatus(`Document not found: ${doc.name} (${response.status})`);
        return;
      }

      const contentType = response.headers.get("content-type") || "";

      // Block HTML fallback pages
      if (contentType.includes("text/html")) {
        setStatus(`Document path is wrong or file is missing: ${doc.name}`);
        return;
      }

      const blob = await response.blob();

      if (!blob || blob.size === 0) {
        setStatus(`Document is empty or unavailable: ${doc.name}`);
        return;
      }

      const url = window.URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = doc.url.split("/").pop() || doc.name;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      window.URL.revokeObjectURL(url);

      setStatus(`Document downloaded: ${doc.name}`);
    } catch (error) {
      setStatus(`Unable to download document: ${doc.name}`);
    }
  };

  const loadProjects = async () => {
    try {
      setProjectsLoading(true);
      const response = await fetch(`${API_BASE_URL}/projects`);
      const body = await response.json().catch(() => []);
      if (!response.ok) {
        throw new Error(body.message || `Unable to load projects (${response.status})`);
      }
      const values = Array.isArray(body) ? body : [];
      setProjects([...new Set(values.filter(Boolean))]);
      if (selectedProject && !values.includes(selectedProject)) {
        setSelectedProject("");
      }
    } catch (error) {
      setProjects([]);
      setStatus(error.message || "Unable to load ReportPortal projects.");
    } finally {
      setProjectsLoading(false);
    }
  };

  useEffect(() => {
    if (reportPortalEnabled) loadProjects();
  }, [reportPortalEnabled]);

  const addProject = async () => {
    const projectName = newProject.trim();
    if (!projectName) {
      setStatus("Please enter a project name.");
      return;
    }

    try {
      const response = await fetch(`${API_BASE_URL}/projects`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name: projectName }),
      });
      const body = await response.json().catch(() => ({}));
      if (!response.ok) {
        throw new Error(body.message || `Unable to add project (${response.status})`);
      }
      const values = Array.isArray(body) ? body : [];
      setProjects([...new Set(values.filter(Boolean))]);
      setSelectedProject(projectName);
      setNewProject("");
      setShowAddProjectModal(false);
      setStatus(`Project "${projectName}" added successfully.`);
    } catch (error) {
      setStatus(error.message || "Unable to add ReportPortal project.");
    }
  };

  // RUN TEST Button Function
  const runTests = async () => {
    setStatus("");
    setReportUrl("");
    setLogs([]);
    setRunId(null);

    if (!file) { setStatus("Please choose an Excel file."); return; }
    if (authType === "BASIC" && (!form.username || !form.password)) {
      setStatus("Username and password are required for Basic authentication."); return;
    }
    if (authType === "OAUTH" && (!form.clientId || !form.clientSecret || !form.tokenUrl)) {
      setStatus("Token URL, Client ID and Client Secret are required for OAuth."); return;
    }
    if (reportPortalEnabled && !selectedProject) {
      setStatus("Please select or create a project when ReportPortal is enabled."); return;
    }

    const data = new FormData();
    data.append("file", file); data.append("authType", authType);
    data.append("username", form.username); data.append("password", form.password);
    data.append("clientId", form.clientId); data.append("clientSecret", form.clientSecret);
    data.append("tokenUrl", form.tokenUrl); data.append("grantType", form.grantType || "client_credentials");
    data.append("projectName", selectedProject);
    data.append("reportPortalEnabled", String(reportPortalEnabled));

    try {
      setBusy(true);
      setStatus("Submitting test run...");
      const response = await fetch(`${API_BASE_URL}/run-tests`, { method: "POST", body: data });
      const body = await response.json().catch(() => ({}));
      if (!response.ok) throw new Error(body.message || `Request failed (${response.status})`);
      const id = body.runId || response.headers.get("X-Run-Id");
      if (!id) throw new Error("Backend did not return a Run ID.");
      setRunId(id);
      setStatus(`Run ${id} submitted. Waiting for execution...`);
    } catch (error) {
      setStatus(error.message || "Unable to start execution.");
      setBusy(false);
    }
  };

  return (
    <div className="pageWithActions">
      <div className="topActionsBar">
        <button className="documentsBtn" onClick={() => setShowDocsModal(true)}>
          Documents
        </button>
      </div>
      <div className="card">
        <h1> API Automation Framework </h1>
        <p className="subtitle">
          Choose Authentication & Upload your Excel File
        </p>

        <div className="section">
          <label>Authentication Type</label>
          <select
            value={authType}
            onChange={(e) => setAuthType(e.target.value)}
          >
            <option value="BASIC">Basic</option>
            <option value="OAUTH">OAuth</option>
          </select>
        </div>

        {authType === "BASIC" ? (
          <div className="grid two">
            <div>
              <label>Username</label>
              <input
                value={form.username}
                onChange={(e) => updateField("username", e.target.value)}
                placeholder="Enter username"
              />
            </div>
            <div>
              <label>Password</label>
              <input
                type="password"
                value={form.password}
                onChange={(e) => updateField("password", e.target.value)}
                placeholder="Enter password"
              />
            </div>
          </div>
        ) : (
          <div className="grid two">
            <div>
              <label>Token URL</label>
              <input
                value={form.tokenUrl}
                onChange={(e) => updateField("tokenUrl", e.target.value)}
                placeholder="https://.../token"
              />
            </div>
            <div>
              <label>Grant Type</label>
              <input
                value={form.grantType}
                onChange={(e) => updateField("grantType", e.target.value)}
                placeholder="client_credentials"
                disabled
              />
            </div>
            <div>
              <label>Client ID</label>
              <input
                value={form.clientId}
                onChange={(e) => updateField("clientId", e.target.value)}
                placeholder="Enter client id"
              />
            </div>
            <div className="input-wrapper">
              <label>Client Secret</label>

              <div className="input-field">
                <input
                  type={showClientSecret ? "text" : "password"}
                  value={form.clientSecret}
                  onChange={(e) => updateField("clientSecret", e.target.value)}
                  placeholder="Enter client secret"
                />

                <button
                  type="button"
                  className="toggle-btn"
                  onClick={() => setShowClientSecret((prev) => !prev)}
                >
                  {showClientSecret ? "Hide" : "Show"}
                </button>
              </div>
            </div>
          </div>
        )}

        <div className="section reportPortalToggle">
          <label className="checkboxLabel">
            <input
              type="checkbox"
              checked={reportPortalEnabled}
              onChange={(e) => {
                setReportPortalEnabled(e.target.checked);
                if (!e.target.checked) setSelectedProject("");
              }}
            />
            <span>Send results to ReportPortal</span>
          </label>
        </div>

        {reportPortalEnabled ? (
          <div className="section">
            <label>ReportPortal Project</label>
            <div className="projectSelectRow">
              <select
                className="projectDropdown"
                value={selectedProject}
                onChange={(e) => setSelectedProject(e.target.value)}
                disabled={projectsLoading}
              >
                <option value="">
                  {projectsLoading ? "Loading projects..." : "Select a project"}
                </option>
                {projects.map((project) => (
                  <option key={project} value={project}>{project}</option>
                ))}
              </select>
              <button
                type="button"
                className="addProjectBtn"
                onClick={() => setShowAddProjectModal(true)}
              >
                + Add Project
              </button>
            </div>
          </div>
        ) : null}

        <div className="section">
          <label>Excel File</label>
          <div
            className={`dropzone ${dragActive ? "active" : ""}`}
            onDragEnter={handleDrag}
            onDragOver={handleDrag}
            onDragLeave={handleDrag}
            onDrop={handleDrop}
            onClick={() => fileInputRef.current?.click()}
            style={{ cursor: "pointer" }}
          >
            <p>
              {file
                ? `Selected file: ${file.name}`
                : "Drag & drop your Excel file here, or click to browse"}
            </p>

            <input
              ref={fileInputRef}
              type="file"
              accept=".xlsx,.xls"
              style={{ display: "none" }}
              onChange={onFileChange}
            />
          </div>
          <small>
            <b>Expected sheet columns: </b> {REQUIRED_COLUMNS.join(", ")}
          </small>
        </div>

        <button className="runBtn" disabled={!canRun} onClick={runTests}>
          {busy ? "Running..." : "Run Tests"}
        </button>


        {status ? <div className="status">{status}</div> : null}

        {/* {logs.length > 0 && (
          <div className="status logsBox">
            <strong>Execution Logs</strong>
            <div className="logsList">
              {logs.map((log, index) => (
                <div key={index} className="logLine">
                  • {log}
                </div>
              ))}
            </div>
          </div>
        )} */}
        {/* <div className="status logsBox">
          <strong>Execution Logs</strong>

          <div className="logsList">
            {logs.length === 0 ? (
              <div className="logLine">Waiting for logs...</div>
            ) : (
              logs.map((log, index) => (
                <div key={index} className="logLine">
                  • {log}
                </div>
              ))
            )}
          </div>
        </div> */}

        {runId ? (
          <div className="status logsBox">
            <strong>Execution Logs — {runId}</strong>
            <div className="logsList">
              {logs.length === 0 ? (
                <div className="logLine">Waiting for logs...</div>
              ) : (
                logs.map((log, index) => <div key={index} className="logLine">• {log}</div>)
              )}
            </div>
          </div>
        ) : null}

        {reportUrl ? (
          <div className="section">
            <a href={reportUrl} target="_blank" rel="noreferrer">
              Download generated report
            </a>
          </div>
        ) : null}
      </div>
      {showDocsModal && (
        <div className="modalOverlay" onClick={() => setShowDocsModal(false)}>
          <div className="modalCard" onClick={(e) => e.stopPropagation()}>
            <div className="modalHeader">
              <h2>API Testing Documents</h2>
              <button
                className="closeModalBtn"
                onClick={() => setShowDocsModal(false)}
              >
                ✕
              </button>
            </div>

            <div className="documentsList">
              {API_TESTING_DOCUMENTS.map((doc, index) => (
                <div className="documentRow" key={index}>
                  <span>{doc.name}</span>
                  <button
                    type="button"
                    className="downloadDocBtn"
                    // disabled={!doc.available}
                    onClick={() => handleDocumentDownload(doc)}
                  >
                    Download
                  </button>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {showAddProjectModal && (
        <div className="modalOverlay" onClick={() => setShowAddProjectModal(false)}>
          <div className="modalCard" onClick={(e) => e.stopPropagation()}>
            <div className="modalHeader">
              <h2>Add ReportPortal Project</h2>
              <button
                className="closeModalBtn"
                onClick={() => setShowAddProjectModal(false)}
              >
                ✕
              </button>
            </div>
            <div className="section">
              <label>Project Name</label>
              <input
                value={newProject}
                placeholder="Enter project name"
                onChange={(e) => setNewProject(e.target.value)}
                onKeyDown={(e) => { if (e.key === "Enter") addProject(); }}
              />
            </div>
            <button className="runBtn" type="button" onClick={addProject}>
              Save Project
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
