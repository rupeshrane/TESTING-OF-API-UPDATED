# OAuth / FIFO / Attachment update — 28 October 2026

## Scope and unchanged features

This build starts from `APICENTRALAUTOMATION-FIFO-SINGLE-RUN-UI-METRICS-UNCHANGED.zip`.
Only these four Java files changed:

- `backend/src/main/java/org/sodales/OAuth2Client.java`
- `backend/src/main/java/runner/ApiTestRunner.java`
- `backend/src/main/java/reader/ExcelReader.java`
- `backend/src/main/java/model/ApiTestCase.java`

**No changes** to `AsyncConfig.java`, `RunManager.java`, `ApiController.java`, `ReportPortalManager.java`, any React/JSX file, or the UI Metrics date-range, bar chart, pie chart, metrics logger, run access controls, report creation, and server configuration.

The FIFO executor still has ONE active worker and 100 queued positions (configurable). An interrupted/failed run releases the single worker only once the execution thread actually exits; queued jobs are not lost during ordinary run cancellation. A physical JVM/Windows service restart still loses the current in-memory queue and is intentionally NOT triggered by Cancel.

## OAuth hardening

- OAuth requests have a connect timeout (up to 10s), response timeout (default 20s), and at most 3 attempts (1 original + up to 2 retries).
- Only network errors, HTTP 429 and HTTP 5xx are retried. HTTP 400/401/403 fail immediately; invalid refresh token 400/401 falls back to exactly one new token acquisition sequence.
- A 401 from an API still triggers at most one refresh and one retry of that API.
- Cancellation interrupts HTTP requests/retry sleeps; the worker is not held by an unbounded token-generation loop.
- Expires-in of less than 30s is not treated as immediately expired.
- The existing per-run OAuth token reuse remains the default. To force a token for **each API test row**, set `QA_OAUTH_FRESH_TOKEN_PER_API=true` in the Windows service environment.
- The OAuth token and client secret are not printed to the metrics or execution logs.

Windows-service environment configuration (restart the Spring Boot service after changes):

| Variable | Default | Notes |
| --- | --- | --- |
| `QA_OAUTH_MAX_ATTEMPTS` | `3` | bounded 1–5 attempts |
| `QA_OAUTH_TIMEOUT_SECONDS` | `20` | per token request, bounded 2–120 seconds |
| `QA_OAUTH_FRESH_TOKEN_PER_API` | `false` | set to `true` only if required by upstream API |
| `QA_API_TIMEOUT_SECONDS` | `120` | per normal HTTP request, bounded 5–300 seconds |

These are environment variables for the **backend service process**, not properties to enter in Excel.

## Multipart upload from an Excel test case

Use `BodyType=FORM_DATA`, and set `FilePath` like `file=@C:\\attachments\\report.pdf` or `file=@report.pdf` (the latter requires selecting and uploading `report.pdf` in the portal's Additional Attachments). Other supported names include `FORM-DATA`, `MULTIPART` and `MULTIPART_FORM_DATA`. Any file contents can be sent (PDF, ZIP, DOCX, XML, JPG, PNG, XLSX, TXT, or arbitrary binary); the program no longer copies the entire multipart body into memory. The upstream API may still reject a file according to its own validation, type, size, or required form-field name.

If `BodyType` is blank but `FormData` is populated, the reader now correctly chooses `FORM_DATA` ahead of `BINARY`. When only FilePath is populated, the previous `BINARY` default is retained; explicitly select `FORM_DATA` for multipart POST.

## POST objectId → GET download example

Two Excel rows in order (examples only — use the exact JSONPath and URL required by your API):

1. `Method=POST`, `BodyType=FORM_DATA`, `FilePath=file=@report.pdf`, `GlobalVariable=objectId`, `GlobalVariableJSONorXMLPath=$.objectId`, `JSONorXML=json`, `ExpectedStatus=200` (or the actual successful response code).
2. `Method=GET`, `URL=https://host/api/attachments/[[objectId]]`, `ExpectedStatus=200`, `ExpectedResponseContains=NA` and no FilePath. `ResponseType=FILE` is optional, only required if the GET endpoint returns a file without an attachment Content-Disposition or binary Content-Type.

`ResponseType` is a NEW OPTIONAL Excel column. Allowed values: `FILE`, `BINARY`, `DOWNLOAD`, `ATTACHMENT`. Leaving it blank preserves the prior automatic response detection. The backend saves successful GET binary responses under each run's `downloads/` folder; that directory is included in the downloadable report ZIP. API errors are not written as successful attachments.

The raw GET response is from the backend HTTP call, not from a browser save dialog. The browser does not need to download the file for the HTTP GET to succeed.

### SAP/CPI MPL ID errors

An MPL ID commonly identifies an error in an SAP Cloud Integration message. If the GET returns 4xx/5xx and mentions an MPL ID, check the *upstream integration logs*, request endpoint/route (sometimes a `/$value` or different media endpoint is needed), actual object ID extracted from POST, encoded path, required headers, token scopes, and whether an API-generated object ID is valid in the GET route. The portal now logs that failure separately and never treats its error payload as a downloaded attachment. Without an actual failing POST/GET request+response pair, no guarantee of a fix to the upstream CPI flow is possible.

## Validation and limitations

Java 17 selective compilation with dependency stubs and a local HTTP mock passed for multipart POST, extracted object ID, binary GET, forced file-download GET, upstream MPL HTTP 500, OAuth permanent HTTP 401, bounded OAuth transient HTTP 503 and short-lived-token handling. This is not a full Maven or frontend production build, and was not tested against your live Windows Server, Docker ReportPortal, or SAP CPI environment.

To validate on Windows Server: run your normal `mvn clean package` build, then run a 2-user FIFO test where User A cancels during token generation and User B starts after worker cleanup. Test the attachment GET against the real environment and compare its status, URL, headers and SAP message log with the working Postman request.
