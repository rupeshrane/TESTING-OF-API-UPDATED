package org.sodales;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

@Configuration
public class AsyncConfig {
    /**
     * Exactly ONE worker executes API suites. The remaining submissions wait
     * in FIFO order; cancelling the running suite frees the worker after its
     * cleanup finally block, then the next queued suite starts.
     * This is intentionally NOT a JVM/server restart: the in-memory queue
     * would otherwise be destroyed.
     */
    @Bean("testRunExecutor")
    public ThreadPoolTaskExecutor testRunExecutor(
            @Value("${qa.runs.queue-capacity:100}") int queueCapacity) {
        ThreadPoolTaskExecutor executor = new ThreadPoolTaskExecutor();
        executor.setCorePoolSize(1);
        executor.setMaxPoolSize(1);
        executor.setQueueCapacity(Math.max(1, Math.min(queueCapacity, 10000)));
        executor.setThreadNamePrefix("api-test-serial-");
        executor.setWaitForTasksToCompleteOnShutdown(false);
        executor.setAwaitTerminationSeconds(10);
        executor.initialize();
        return executor;
    }
}
