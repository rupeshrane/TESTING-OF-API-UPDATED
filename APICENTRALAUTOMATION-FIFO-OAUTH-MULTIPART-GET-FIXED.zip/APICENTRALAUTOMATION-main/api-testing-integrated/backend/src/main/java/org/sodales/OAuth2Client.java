package org.sodales;

import model.AuthContext;

import java.io.IOException;
import java.net.URI;
import java.net.URLEncoder;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.time.Instant;
import java.util.Base64;
import java.util.Map;
import java.util.concurrent.CancellationException;

import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * Bounded, interruption-aware OAuth token acquisition for FIFO API executions.
 * Only transient errors (I/O, HTTP 429 and HTTP 5xx) are retried. Invalid
 * credentials (400/401/403) are never sent into a retry loop.
 */
public final class OAuth2Client {
    private static final ObjectMapper MAPPER = new ObjectMapper();
    private static final int MAX_ATTEMPTS = setting("QA_OAUTH_MAX_ATTEMPTS", 3, 1, 5);
    private static final int REQUEST_TIMEOUT = setting("QA_OAUTH_TIMEOUT_SECONDS", 20, 2, 120);
    private static final HttpClient CLIENT = HttpClient.newBuilder()
            .connectTimeout(Duration.ofSeconds(Math.min(10, REQUEST_TIMEOUT)))
            .build();

    private OAuth2Client() {}

    public static void getAccessToken(AuthContext auth) throws IOException, InterruptedException {
        checkCancellation();
        String grant = safe(auth.grantType).isBlank() ? "client_credentials" : auth.grantType;
        String body = "grant_type=" + form(grant)
                + "&client_id=" + form(auth.clientId)
                + "&client_secret=" + form(auth.clientSecret);
        requestToken(auth, body, "new access token", false);
    }

    public static void refreshAccessToken(AuthContext auth) throws IOException, InterruptedException {
        checkCancellation();
        if (safe(auth.refreshToken).isBlank()) {
            getAccessToken(auth);
            return;
        }
        String body = "grant_type=refresh_token"
                + "&client_id=" + form(auth.clientId)
                + "&client_secret=" + form(auth.clientSecret)
                + "&refresh_token=" + form(auth.refreshToken);
        try {
            requestToken(auth, body, "refresh token", true);
        } catch (NonRetryableTokenException failure) {
            // An expired/invalid refresh token may be replaced once with a new
            // client-credentials grant; never recursively refresh/retry.
            if (failure.statusCode == 400 || failure.statusCode == 401) {
                auth.refreshToken = null;
                getAccessToken(auth);
            } else {
                throw failure;
            }
        }
    }

    private static void requestToken(AuthContext auth, String body, String operation, boolean refresh)
            throws IOException, InterruptedException {
        URI url = HttpUriUtil.fromSpreadsheet(auth.tokenUrl);
        for (int attempt = 1; attempt <= MAX_ATTEMPTS; attempt++) {
            checkCancellation();
            HttpRequest request = HttpRequest.newBuilder(url)
                    .timeout(Duration.ofSeconds(REQUEST_TIMEOUT))
                    .header("Content-Type", "application/x-www-form-urlencoded")
                    .header("Authorization", "Basic " + Base64.getEncoder().encodeToString(
                            (safe(auth.clientId) + ":" + safe(auth.clientSecret))
                                    .getBytes(StandardCharsets.UTF_8)))
                    .POST(HttpRequest.BodyPublishers.ofString(body))
                    .build();
            try {
                HttpResponse<String> response = CLIENT.send(request, HttpResponse.BodyHandlers.ofString());
                checkCancellation();
                int status = response.statusCode();
                if (status >= 200 && status < 300) {
                    parseTokenResponse(response.body(), auth, refresh);
                    LogCollector.log("OAuth " + operation + " acquired (attempt " + attempt + ").");
                    return;
                }
                if (status != 429 && status < 500) {
                    throw new NonRetryableTokenException(status,
                            "OAuth " + operation + " rejected by token server (HTTP " + status
                                    + "). Check credentials, scope and token URL.");
                }
                if (attempt == MAX_ATTEMPTS) {
                    throw new TokenHttpException("OAuth " + operation + " failed with HTTP " + status
                            + " after " + attempt + " attempts.");
                }
                LogCollector.log("OAuth " + operation + " received transient HTTP " + status
                        + "; retry " + (attempt + 1) + "/" + MAX_ATTEMPTS + ".");
            } catch (NonRetryableTokenException | TokenHttpException e) {
                throw e;
            } catch (IOException e) {
                if (attempt == MAX_ATTEMPTS) {
                    throw new IOException("OAuth " + operation + " request failed after " + attempt
                            + " attempts (" + e.getClass().getSimpleName() + ").", e);
                }
                LogCollector.log("OAuth " + operation + " network failure; retry "
                        + (attempt + 1) + "/" + MAX_ATTEMPTS + ".");
            }
            checkCancellation();
            // Interruptible backoff means a cancelled run does not wait for retries.
            Thread.sleep(Math.min(1200, 250L * attempt));
        }
    }

    public static boolean isTokenMissingOrExpired(AuthContext auth) {
        return safe(auth.accessToken).isBlank() || auth.tokenExpiry == null
                || !Instant.now().isBefore(auth.tokenExpiry);
    }

    private static void parseTokenResponse(String json, AuthContext auth, boolean refresh) throws IOException {
        Map<?, ?> map = MAPPER.readValue(json, Map.class);
        Object token = map.get("access_token");
        if (!(token instanceof String) || ((String) token).isBlank()) {
            throw new IOException("OAuth token server returned no access_token.");
        }
        Object expiry = map.get("expires_in");
        long seconds;
        try {
            seconds = expiry == null ? 3600 : Long.parseLong(String.valueOf(expiry));
        } catch (NumberFormatException e) {
            throw new IOException("OAuth token server returned an invalid expires_in.", e);
        }
        if (seconds <= 0) throw new IOException("OAuth token expires_in must be positive.");
        auth.accessToken = (String) token;
        Object refreshValue = map.get("refresh_token");
        if (refreshValue instanceof String && !((String) refreshValue).isBlank())
            auth.refreshToken = (String) refreshValue;
        // Avoid subtracting a fixed 30 seconds from short-lived tokens; that
        // previously made every API immediately request another token.
        long skew = Math.min(30, seconds / 10);
        auth.tokenExpiry = Instant.now().plusSeconds(Math.max(1, seconds - skew));
    }

    public static boolean freshTokenPerApi() {
        return "true".equalsIgnoreCase(System.getenv("QA_OAUTH_FRESH_TOKEN_PER_API"));
    }

    private static String form(String value) {
        return URLEncoder.encode(safe(value), StandardCharsets.UTF_8);
    }
    private static String safe(String s) { return s == null ? "" : s; }
    private static void checkCancellation() {
        if (Thread.currentThread().isInterrupted())
            throw new CancellationException("Run cancelled during OAuth token generation");
    }
    private static int setting(String key, int fallback, int min, int max) {
        try {
            String raw = System.getenv(key);
            if (raw == null || raw.isBlank()) return fallback;
            int n = Integer.parseInt(raw.trim());
            return Math.max(min, Math.min(n, max));
        } catch (NumberFormatException e) { return fallback; }
    }
    private static final class TokenHttpException extends IOException {
        TokenHttpException(String message) { super(message); }
    }
    private static final class NonRetryableTokenException extends IOException {
        private final int statusCode;
        NonRetryableTokenException(int statusCode, String message) {
            super(message);
            this.statusCode = statusCode;
        }
    }
}
