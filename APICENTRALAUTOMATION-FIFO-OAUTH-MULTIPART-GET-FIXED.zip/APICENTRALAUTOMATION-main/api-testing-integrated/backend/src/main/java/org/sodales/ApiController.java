package org.sodales;

import model.AuthContext;
import model.RunRecord;
import model.RunStatus;
import model.TestRunContext;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;


import java.io.*;
import java.nio.file.Files;
import java.time.Instant;
import org.springframework.core.task.TaskRejectedException;
import java.util.*;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

@RestController
@CrossOrigin("*")
public class ApiController {
    private static final String BASE_TEMP_DIR = System.getProperty("java.io.tmpdir") + File.separator + "api-testing";
    private final RunManager runManager;
    private final PortalSessionService portalSessions;

    public ApiController(RunManager runManager, PortalSessionService portalSessions) {
        this.runManager = runManager;
        this.portalSessions = portalSessions;
    }

    /** Anonymous sessions: browser keeps this token in sessionStorage. No login or database. */
    @PostMapping("/portal-session")
    public ResponseEntity<?> portalSession(
            @RequestHeader(value = "X-QA-Session", required = false) String existingSession) {
        String issued = portalSessions.createOrResume(existingSession);
        return ResponseEntity.ok()
                .header(HttpHeaders.CACHE_CONTROL, "no-store")
                .body(Map.of("sessionToken", issued, "expiresAfterHours", 24));
    }

    @PostMapping("/run-tests")
    public ResponseEntity<?> runTests(@RequestParam("file") MultipartFile file,
                                      @RequestParam(value = "attachments", required = false) List<MultipartFile> attachments,
                                      @RequestParam String authType,
                                      @RequestParam(required = false) String username,
                                      @RequestParam(required = false) String password,
                                      @RequestParam(required = false) String clientId,
                                      @RequestParam(required = false) String clientSecret,
                                      @RequestParam(required = false) String tokenUrl,
                                      @RequestParam(required = false) String grantType,
                                      @RequestParam(required = false) String projectName,
                                      @RequestParam(required = false, defaultValue = "false") boolean reportPortalEnabled,
                                      @RequestHeader(value = "X-QA-Session", required = false) String ownerSession) {
        // Reject before creating run files. Every run is bound to its initiating browser session.
        if (!portalSessions.validAndTouch(ownerSession)) {
            return ResponseEntity.status(HttpStatus.FORBIDDEN)
                    .body(errorBody("SESSION_REQUIRED", "Portal session expired or missing. Refresh the portal and retry.", null));
        }
        TestRunContext context = null;
        try {
            cleanupOldRuns();
            validateFile(file);
            if (reportPortalEnabled && isBlank(projectName)) {
                throw new IllegalArgumentException("Project name is required when ReportPortal is enabled.");
            }

            AuthContext authContext = buildAuthContext(authType, username, password, clientId, clientSecret, tokenUrl, grantType);
            context = createRunContext();
            context.reportPortalEnabled = reportPortalEnabled;
            context.projectName = isBlank(projectName) ? null : projectName.trim();

            LogCollector.createRun(context.runId);
            LogCollector.log(context.runId, "Run request accepted.");
            LogCollector.log(context.runId, "Authentication Type: " + authType);
            LogCollector.log(context.runId, "Uploaded File: " + Optional.ofNullable(file.getOriginalFilename()).orElse("unknown"));
            LogCollector.log(context.runId, "ReportPortal: " + (reportPortalEnabled ? "ENABLED" : "DISABLED"));
            if (reportPortalEnabled) LogCollector.log(context.runId, "ReportPortal Project: " + context.projectName);

            file.transferTo(new File(context.excelPath));
            storeAttachments(context, attachments);
            RunRecord record = runManager.submit(context, authContext, portalSessions.fingerprint(ownerSession));
            return ResponseEntity.status(HttpStatus.ACCEPTED)
                    .header("X-Run-Id", context.runId)
                    .body(startBody(record));
        } catch (TaskRejectedException e) {
            String runId = context == null ? null : context.runId;
            return ResponseEntity.status(HttpStatus.TOO_MANY_REQUESTS)
                    .body(errorBody("RUN_CAPACITY_REACHED", "Execution queue is full; retry after a queued run finishes.", runId));
        } catch (IllegalArgumentException e) {
            String runId = context == null ? null : context.runId;
            if (runId != null) LogCollector.log(runId, "Validation failed: " + e.getMessage());
            return ResponseEntity.badRequest().body(errorBody("VALIDATION_FAILED", e.getMessage(), runId));
        } catch (Exception e) {
            String runId = context == null ? null : context.runId;
            if (runId != null) LogCollector.log(runId, "Unable to start run: " + e.getMessage());
            e.printStackTrace();
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(errorBody("RUN_START_FAILED", "Unable to start the test run: " + safeMessage(e), runId));
        }
    }

    @GetMapping({"/projects", "/reportportal/projects"})
    public ResponseEntity<?> getProjects() {
        try {
            return ResponseEntity.ok(ReportPortalManager.getProjects());
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.BAD_GATEWAY)
                    .body(errorBody("REPORT_PORTAL_UNAVAILABLE", "Unable to load ReportPortal projects: " + safeMessage(e), null));
        }
    }

    @PostMapping("/projects")
    public ResponseEntity<?> addProject(@RequestBody Map<String, String> request) {
        String projectName = request == null ? null : request.get("name");
        if (isBlank(projectName)) {
            return ResponseEntity.badRequest().body(errorBody("PROJECT_NAME_REQUIRED", "Project name is required.", null));
        }

        if (!ReportPortalManager.createProject(projectName.trim())) {
            return ResponseEntity.status(HttpStatus.BAD_GATEWAY)
                    .body(errorBody("PROJECT_CREATE_FAILED", "Unable to create the ReportPortal project.", null));
        }
        return ResponseEntity.ok(ReportPortalManager.getProjects());
    }

    @GetMapping({"/logs/{runId}", "/runs/{runId}/logs"})
    public ResponseEntity<?> getLogs(@PathVariable String runId,
            @RequestHeader(value = "X-QA-Session", required = false) String ownerSession,
            @RequestHeader(value = "X-Run-Access-Token", required = false) String accessToken) {
        if (!validRunId(runId)) return ResponseEntity.badRequest().body(errorBody("INVALID_RUN_ID", "Invalid Run ID", runId));
        RunRecord record = runManager.get(runId);
        if (record == null) return ResponseEntity.status(404).body(errorBody("RUN_NOT_FOUND", "Run not found", runId));
        if (!authorized(record, ownerSession, accessToken)) return denied(runId);
        return ResponseEntity.ok().header(HttpHeaders.CACHE_CONTROL, "no-store")
                .body(LogCollector.getLogs(runId));
    }

    @GetMapping("/runs/{runId}/status")
    public ResponseEntity<?> getStatus(@PathVariable String runId,
            @RequestHeader(value = "X-QA-Session", required = false) String ownerSession,
            @RequestHeader(value = "X-Run-Access-Token", required = false) String accessToken) {
        if (!validRunId(runId)) return ResponseEntity.badRequest().body(errorBody("INVALID_RUN_ID", "Invalid Run ID", runId));
        RunRecord record = runManager.get(runId);
        if (record == null) return ResponseEntity.status(404).body(errorBody("RUN_NOT_FOUND", "Run not found", runId));
        if (!authorized(record, ownerSession, accessToken)) return denied(runId);
        return ResponseEntity.ok().header(HttpHeaders.CACHE_CONTROL, "no-store").body(runBody(record));
    }

    /** Only the creator holding the run's secret cancellation key can stop it. */
    @PostMapping("/runs/{runId}/cancel")
    public ResponseEntity<?> cancelRun(@PathVariable String runId,
            @RequestHeader(value="X-Run-Cancel-Token", required=false) String token,
            @RequestHeader(value = "X-QA-Session", required = false) String ownerSession,
            @RequestHeader(value = "X-Run-Access-Token", required = false) String accessToken) {
        if (!validRunId(runId)) return ResponseEntity.badRequest().body(errorBody("INVALID_RUN_ID", "Invalid Run ID", runId));
        RunRecord record = runManager.get(runId);
        if (record == null) return ResponseEntity.status(404).body(errorBody("RUN_NOT_FOUND", "Run not found", runId));
        if (!authorized(record, ownerSession, accessToken)) return denied(runId);
        if (!PortalSessionService.tokenMatches(token, record.cancelToken)) {
            return ResponseEntity.status(HttpStatus.FORBIDDEN).body(errorBody("CANCEL_NOT_AUTHORIZED", "A valid run cancellation token is required.", runId));
        }
        runManager.requestCancel(record);
        return ResponseEntity.accepted().body(runBody(record));
    }

    @GetMapping("/runs/{runId}/report")
    public ResponseEntity<?> downloadReport(@PathVariable String runId,
            @RequestHeader(value = "X-QA-Session", required = false) String ownerSession,
            @RequestHeader(value = "X-Run-Access-Token", required = false) String accessToken) {
        if (!validRunId(runId)) return ResponseEntity.badRequest().body(errorBody("INVALID_RUN_ID", "Invalid Run ID", runId));
        RunRecord record = runManager.get(runId);
        if (record == null) return ResponseEntity.status(404).body(errorBody("RUN_NOT_FOUND", "Run not found", runId));
        if (!authorized(record, ownerSession, accessToken)) return denied(runId);
        if (record.status == RunStatus.QUEUED) {
            return ResponseEntity.status(HttpStatus.CONFLICT)
                    .body(errorBody("REPORT_NOT_READY", "No tests have started yet.", runId));
        }
        if (record.status == RunStatus.RUNNING && !new File(record.context.csvPath).exists()
                && !hasDownloads(record.context)) {
            return ResponseEntity.status(HttpStatus.CONFLICT)
                    .body(errorBody("REPORT_NOT_READY", "No completed test results yet.", runId));
        }
        try {
            byte[] zip = buildReportZip(record);
            return ResponseEntity.ok()
                    .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=" + runId + "_api-test-results.zip")
                    .header(HttpHeaders.CACHE_CONTROL, "no-store")
                    .contentType(MediaType.parseMediaType("application/zip"))
                    .body(zip);
        } catch (Exception e) {
            LogCollector.log(runId, "Report download failed: " + e.getMessage());
            return ResponseEntity.internalServerError().body(errorBody("REPORT_DOWNLOAD_FAILED", safeMessage(e), runId));
        }
    }

    private Map<String, Object> startBody(RunRecord record) {
        Map<String, Object> body = runBody(record);
        body.put("cancelToken", record.cancelToken); // only disclosed in initial POST response
        body.put("accessToken", record.accessToken); // only disclosed in initial POST response
        return body;
    }

    private boolean authorized(RunRecord record, String ownerSession, String accessToken) {
        return portalSessions.ownsRun(ownerSession, record.ownerSessionFingerprint)
                && PortalSessionService.tokenMatches(accessToken, record.accessToken);
    }

    private ResponseEntity<?> denied(String runId) {
        return ResponseEntity.status(HttpStatus.FORBIDDEN)
                .header(HttpHeaders.CACHE_CONTROL, "no-store")
                .body(errorBody("RUN_ACCESS_DENIED", "This browser session is not authorized to access this run.", runId));
    }

    private Map<String, Object> runBody(RunRecord record) {
        Map<String, Object> body = new LinkedHashMap<>();
        body.put("success", record.status != RunStatus.FAILED);
        body.put("runId", record.context.runId);
        body.put("status", record.status.name());
        body.put("errorCode", record.errorCode);
        body.put("message", record.errorMessage);
        body.put("totalTests", record.totalTests.get());
        body.put("executedTests", record.executedTests.get());
        body.put("partialReportAvailable", new File(record.context.csvPath).exists()
                || new File(record.context.htmlPath).exists() || hasDownloads(record.context));
        body.put("createdAt", record.createdAt);
        body.put("startedAt", record.startedAt);
        body.put("completedAt", record.completedAt);
        body.put("reportPortalEnabled", record.context.reportPortalEnabled);
        body.put("projectName", record.context.projectName);
        return body;
    }

    private Map<String, Object> errorBody(String code, String message, String runId) {
        Map<String, Object> body = new LinkedHashMap<>();
        body.put("success", false); body.put("code", code); body.put("message", message);
        body.put("runId", runId == null ? "unavailable" : runId); body.put("timestamp", Instant.now().toString());
        return body;
    }

    private void validateFile(MultipartFile file) {
        if (file == null || file.isEmpty()) throw new IllegalArgumentException("Excel file is required.");
        String name = Optional.ofNullable(file.getOriginalFilename()).orElse("").toLowerCase(Locale.ROOT);
        if (!name.endsWith(".xlsx") && !name.endsWith(".xls")) throw new IllegalArgumentException("Only .xlsx or .xls Excel files are allowed.");
    }

    private AuthContext buildAuthContext(String authType, String username, String password, String clientId, String clientSecret, String tokenUrl, String grantType) {
        if (isBlank(authType)) throw new IllegalArgumentException("Authentication Type is required.");
        AuthContext auth = new AuthContext();
        auth.authenticationType = authType.trim().toUpperCase(Locale.ROOT);
        if ("BASIC".equals(auth.authenticationType)) {
            if (isBlank(username) || isBlank(password)) throw new IllegalArgumentException("Username and Password are required for BASIC authentication.");
            auth.username = username; auth.password = password;
        } else if ("OAUTH".equals(auth.authenticationType) || "OAUTH2".equals(auth.authenticationType)) {
            if (isBlank(clientId) || isBlank(clientSecret) || isBlank(tokenUrl)) throw new IllegalArgumentException("Token URL, Client ID and Client Secret are required for OAUTH2.");
            auth.clientId = clientId; auth.clientSecret = clientSecret; auth.tokenUrl = tokenUrl;
            auth.grantType = isBlank(grantType) ? "client_credentials" : grantType;
        } else throw new IllegalArgumentException("Unsupported Authentication Type: " + authType);
        return auth;
    }

    private void storeAttachments(TestRunContext context, List<MultipartFile> attachments) throws IOException {
        if (attachments == null || attachments.isEmpty()) return;
        File directory = new File(context.runDir, "attachments");
        Files.createDirectories(directory.toPath());
        for (MultipartFile file : attachments) {
            if (file == null || file.isEmpty()) continue;
            String original = Optional.ofNullable(file.getOriginalFilename()).orElse("attachment");
            String base = original.replace('\\', '/');
            base = base.substring(base.lastIndexOf('/') + 1);
            String safe = base.replaceAll("[^a-zA-Z0-9._-]", "_");
            if (safe.isBlank() || safe.equals(".") || safe.equals(".."))
                throw new IllegalArgumentException("Invalid attachment filename");
            if (context.uploadedAttachments.containsKey(safe))
                throw new IllegalArgumentException("Duplicate attachment filename: " + safe);
            File target = new File(directory, safe);
            file.transferTo(target);
            context.uploadedAttachments.put(safe, target.getAbsolutePath());
            LogCollector.log(context.runId, "Attachment staged: " + safe + " (" + file.getSize() + " bytes)");
        }
    }

    private TestRunContext createRunContext() throws IOException {
        String runId = "run_" + System.currentTimeMillis() + "_" + UUID.randomUUID();
        File dir = new File(BASE_TEMP_DIR, runId);
        Files.createDirectories(dir.toPath());
        TestRunContext c = new TestRunContext();
        c.runId = runId; c.runDir = dir.getAbsolutePath();
        c.excelPath = new File(dir, "api_test_data.xlsx").getAbsolutePath();
        c.htmlPath = new File(dir, "api_debug_report.html").getAbsolutePath();
        c.extentPath = new File(dir, "api_extent_debug_report.html").getAbsolutePath();
        c.csvPath = new File(dir, "api_debug_report.csv").getAbsolutePath();
        return c;
    }

    private boolean hasDownloads(TestRunContext context) {
        File dir = new File(context.runDir, "downloads");
        File[] files = dir.listFiles(File::isFile);
        return files != null && files.length > 0;
    }

    private byte[] buildReportZip(RunRecord record) throws IOException {
        TestRunContext c = record.context;
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        try (ZipOutputStream zip = new ZipOutputStream(baos)) {
            String summary = "Run: " + c.runId + "\nStatus: " + record.status
                    + "\nCompleted test rows: " + record.executedTests.get() + "/" + record.totalTests.get()
                    + "\nThis ZIP contains only test steps whose report files have already been written.\n";
            zip.putNextEntry(new ZipEntry("RUN_SUMMARY.txt"));
            zip.write(summary.getBytes(java.nio.charset.StandardCharsets.UTF_8));
            zip.closeEntry();
            addFileToZip(zip, new File(c.htmlPath), "api_debug_report.html");
            addFileToZip(zip, new File(c.csvPath), "api_debug_report.csv");
            // ExtentReports may be writing while a run is active; include only after termination.
            if (RunManager.isTerminal(record.status))
                addFileToZip(zip, new File(c.extentPath), "api_extent_debug_report.html");
            File downloadDir = new File(c.runDir, "downloads");
            File[] downloads = downloadDir.listFiles(File::isFile);
            if (downloads != null) {
                for (File attachment : downloads)
                    addFileToZip(zip, attachment, "downloads/" + attachment.getName());
            }
        }
        return baos.toByteArray();
    }

    private void addFileToZip(ZipOutputStream zip, File file, String name) throws IOException {
        if (!file.exists()) return;
        zip.putNextEntry(new ZipEntry(name));
        Files.copy(file.toPath(), zip);
        zip.closeEntry();
    }

    private boolean validRunId(String id) { return id != null && id.matches("run_[A-Za-z0-9_-]+"); }
    private boolean isBlank(String v) { return v == null || v.trim().isEmpty(); }
    private String safeMessage(Throwable e) { return e.getMessage() == null ? e.getClass().getSimpleName() : e.getMessage(); }

    private void cleanupOldRuns() {
        File base = new File(BASE_TEMP_DIR); File[] files = base.listFiles(); if (files == null) return;
        long cutoff = System.currentTimeMillis() - 24L * 60 * 60 * 1000;
        for (File f : files) if (f.isDirectory() && f.lastModified() < cutoff
                && !runManager.isActive(f.getName())) deleteDirectory(f);
    }

    private void deleteDirectory(File dir) {
        File[] files = dir.listFiles(); if (files != null) for (File f : files) { if (f.isDirectory()) deleteDirectory(f); else f.delete(); }
        dir.delete();
    }
}
