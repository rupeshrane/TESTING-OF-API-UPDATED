package org.sodales;

import com.fasterxml.jackson.databind.ObjectMapper;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Value;
import java.time.LocalDate;
import java.security.MessageDigest;
import java.nio.charset.StandardCharsets;
import java.util.Map;
import model.UiMetricEvent;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@CrossOrigin("*")
@RequestMapping("/ui-metrics")
public class UiMetricsController {
    private final UiMetricsService uiMetricsService;
    private final ObjectMapper objectMapper;

    @Value("${ui.metrics.admin-key:}")
    private String adminKey;

    public UiMetricsController(UiMetricsService uiMetricsService, ObjectMapper objectMapper) {
        this.uiMetricsService = uiMetricsService;
        this.objectMapper = objectMapper;
    }

    /**
     * Write-only endpoint used by the portal UI. Metrics failures must never affect
     * normal QA portal functionality.
     */
    @PostMapping(value = "/event", consumes = MediaType.TEXT_PLAIN_VALUE)
    public ResponseEntity<Void> record(@RequestBody String payload, HttpServletRequest request) {
        try {
            UiMetricEvent event = objectMapper.readValue(payload, UiMetricEvent.class);
            uiMetricsService.record(event, request.getRemoteAddr(), request.getHeader("User-Agent"));
            return ResponseEntity.noContent().build();
        } catch (IllegalArgumentException e) {
            return ResponseEntity.badRequest().build();
        } catch (Exception e) {
            return ResponseEntity.badRequest().build();
        }
    }

    /** Existing single-day endpoint retained for backward compatibility. */
    @GetMapping(value = "/admin/summary", produces = MediaType.TEXT_PLAIN_VALUE)
    public ResponseEntity<String> summary(
            @RequestParam(required = false) String date,
            @RequestHeader(value = "X-UI-Metrics-Admin-Key", required = false) String supplied) {
        ResponseEntity<String> denied = authorize(supplied);
        if (denied != null) return denied;

        try {
            LocalDate day = date == null || date.isBlank() ? LocalDate.now() : LocalDate.parse(date);
            return ResponseEntity.ok()
                    .header("Cache-Control", "no-store")
                    .body(uiMetricsService.dailySummary(day));
        } catch (IllegalArgumentException e) {
            return ResponseEntity.badRequest().body("Invalid metrics date");
        } catch (Exception e) {
            return ResponseEntity.internalServerError().body("Could not read metrics summary");
        }
    }

    /**
     * Date-range endpoint for the administrative metrics screen. Returns JSON so the
     * frontend can render summary cards and bar/pie charts without extra libraries.
     */
    @GetMapping(value = "/admin/range", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<?> range(
            @RequestParam String from,
            @RequestParam String to,
            @RequestHeader(value = "X-UI-Metrics-Admin-Key", required = false) String supplied) {
        ResponseEntity<String> denied = authorize(supplied);
        if (denied != null) return denied;

        try {
            LocalDate fromDate = LocalDate.parse(from);
            LocalDate toDate = LocalDate.parse(to);
            Map<String, Object> result = uiMetricsService.rangeSummary(fromDate, toDate);
            return ResponseEntity.ok()
                    .header("Cache-Control", "no-store")
                    .body(result);
        } catch (IllegalArgumentException e) {
            return ResponseEntity.badRequest().body(Map.of("message", e.getMessage()));
        } catch (Exception e) {
            return ResponseEntity.internalServerError()
                    .body(Map.of("message", "Could not read metrics for the selected date range"));
        }
    }

    private ResponseEntity<String> authorize(String supplied) {
        if (adminKey == null || adminKey.length() < 16) {
            return ResponseEntity.status(503).body("Metrics admin access is disabled on the server.");
        }
        if (supplied == null || !MessageDigest.isEqual(
                adminKey.getBytes(StandardCharsets.UTF_8),
                supplied.getBytes(StandardCharsets.UTF_8))) {
            return ResponseEntity.status(403).body("Metrics admin authorization required.");
        }
        return null;
    }
}
