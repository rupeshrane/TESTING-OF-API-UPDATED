package reader;

import model.ApiTestCase;
import org.apache.poi.ss.usermodel.*;
import java.io.FileInputStream;
import java.util.*;

public final class ExcelReader {
    private ExcelReader() {}
    public static List<ApiTestCase> readTestCases(String path) {
        List<ApiTestCase> result = new ArrayList<>();
        try (FileInputStream input = new FileInputStream(path);
             Workbook wb = WorkbookFactory.create(input)) {
            Sheet sheet = wb.getSheetAt(0);
            DataFormatter fmt = new DataFormatter();
            if (sheet.getPhysicalNumberOfRows() == 0) throw new IllegalArgumentException("Excel sheet is empty");
            Iterator<Row> rows = sheet.iterator();
            Row header = rows.next();
            Map<String, Integer> column = new HashMap<>();
            for (Cell cell : header) {
                String key = fmt.formatCellValue(cell).replaceAll("[^A-Za-z0-9]", "").toLowerCase(Locale.ROOT);
                column.put(key, cell.getColumnIndex());
            }
            if (!column.containsKey("url") || !column.containsKey("method"))
                throw new IllegalArgumentException("Excel must have Method and URL columns");
            while (rows.hasNext()) {
                Row row = rows.next();
                if (row == null || isEmpty(row, fmt)) continue;
                ApiTestCase tc = new ApiTestCase();
                tc.testName = value(row, column, fmt, "testname");
                tc.method = value(row, column, fmt, "method");
                tc.url = value(row, column, fmt, "url");
                tc.headers = value(row, column, fmt, "headers");
                tc.bodyType = value(row, column, fmt, "bodytype");
                tc.payload = value(row, column, fmt, "payload");
                tc.formData = value(row, column, fmt, "formdata");
                tc.filePath = value(row, column, fmt, "filepath");
                tc.expectedStatus = value(row, column, fmt, "expectedstatus");
                tc.expectedResponse = value(row, column, fmt, "expectedresponsecontains", "expectedresponse");
                tc.skip = value(row, column, fmt, "skip");
                tc.globalvariablejsonxmlpath = value(row, column, fmt, "globalvariablejsonorxmlpath");
                tc.globalvariable = value(row, column, fmt, "globalvariable");
                tc.xmlorjson = value(row, column, fmt, "jsonorxml");
                // Optional: FILE forces GET response to be downloaded even if upstream
                // returns text/plain or no attachment Content-Disposition header.
                tc.responseType = value(row, column, fmt, "responsetype", "responsetreatment");
                // Backwards compatibility for 11-column pre-BodyType spreadsheets.
                if (tc.bodyType.isBlank()) {
                    // A multipart form with a FilePath must remain FORM_DATA;
                    // the previous priority silently sent raw binary instead.
                    tc.bodyType = !tc.formData.isBlank() && !"NA".equalsIgnoreCase(tc.formData) ? "FORM_DATA" :
                        !tc.filePath.isBlank() ? "BINARY" :
                        !tc.payload.isBlank() && !"NA".equalsIgnoreCase(tc.payload) ? "RAW" : "NONE";
                }
                result.add(tc);
            }
        } catch (Exception e) {
            if (e instanceof IllegalArgumentException) throw (IllegalArgumentException)e;
            throw new IllegalArgumentException("Could not read Excel test cases: " + e.getMessage(), e);
        }
        if (result.isEmpty()) throw new IllegalArgumentException("Excel contains no test cases");
        return result;
    }
    private static String value(Row row, Map<String,Integer> headers, DataFormatter formatter, String... names) {
        for (String name : names) {
            Integer at = headers.get(name);
            if (at != null) {
                Cell cell = row.getCell(at, Row.MissingCellPolicy.RETURN_BLANK_AS_NULL);
                return cell == null ? "" : formatter.formatCellValue(cell).trim();
            }
        }
        return "";
    }
    private static boolean isEmpty(Row row, DataFormatter fmt) {
        for (Cell cell : row) if (!fmt.formatCellValue(cell).isBlank()) return false;
        return true;
    }
}
