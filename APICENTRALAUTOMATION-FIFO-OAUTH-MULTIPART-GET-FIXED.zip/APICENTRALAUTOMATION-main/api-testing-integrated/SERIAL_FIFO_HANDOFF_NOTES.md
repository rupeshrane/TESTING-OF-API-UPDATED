# Serial FIFO queue and cancellation handoff

## What changed
- `AsyncConfig.java`: exactly 1 worker, FIFO waiting queue (default capacity 100).
- `RunManager.java`: queue-oriented log messages; existing owner-only cancel, partial reports, and cleanup remain.
- `ApiController.java`: queue-full message (HTTP 429).
- `application.yml`: `QA_RUN_QUEUE_CAPACITY` defaults to 100.
- **UI metrics have NOT been changed**: date range, bar/pie chart, admin controls and logging are identical to the previous metrics ZIP.

## Expected
User A RUNNING, User B QUEUED, User C QUEUED. Cancel A -> cancellation requested -> A's worker finishes cleanup -> B RUNNING -> C remains QUEUED. There is NEVER more than one active API suite inside this Spring Boot process. Cancelling A preserves existing completed results for A.

## Server restart distinction
This implementation does **NOT** restart Windows Server or the Spring Boot JVM. It reuses the worker after clean cancellation. Restarting the actual JVM destroys the in-memory waiting queue and active run metadata, potentially exposes credentials if state is dumped carelessly, and disconnects all users. Meeting *literal server restart + recover all waiting submissions* requires a separate durable queue (with encrypted secrets and attachment persistence) and a Windows service restart/recovery strategy. This has NOT been implemented and should not be represented as implemented.

## Limitations / deployment
The queue is in memory: real Windows Server/JVM restarts do not preserve waiting items. External target API calls already accepted by SAP/other servers might finish even if cancelled; their side effects cannot be rolled back. Some blocking network operations may not respond to interruption until HTTP timeout. The next queued run starts after prior worker cleanup, not necessarily at the instant Cancel is clicked.

## Integration
Deploy updated backend; frontend does not need any update. Do not set `QA_MAX_CONCURRENT_RUNS` expecting it to change serial mode; the executor is now strictly 1. Existing run ownership security and ReportPortal files remain unchanged. Verify 2-browser FIFO/cancellation test against your Windows Server before production deployment.
