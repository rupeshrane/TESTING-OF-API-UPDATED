import React, { useMemo, useState } from "react";

const API_BASE_URL = import.meta.env.VITE_API_BASE_URL || "http://localhost:9090";

function todayIso() {
  return new Date().toLocaleDateString("en-CA");
}

function daysAgoIso(days) {
  const date = new Date();
  date.setDate(date.getDate() - days);
  return date.toLocaleDateString("en-CA");
}

function MetricCard({ label, value }) {
  return (
    <div style={{background:"#f7f9fc",border:"1px solid #e5e9f0",borderRadius:10,padding:"16px 18px"}}>
      <div style={{fontSize:13,color:"#667085",marginBottom:6}}>{label}</div>
      <div style={{fontSize:25,fontWeight:700,color:"#18212b"}}>{value}</div>
    </div>
  );
}

function BarChart({ data }) {
  const max = Math.max(1, ...data.map(item => item.visits));
  return (
    <div style={{display:"grid",gap:12,marginTop:14}}>
      {data.map(item => (
        <div key={item.name} style={{display:"grid",gridTemplateColumns:"minmax(130px, 220px) 1fr 58px",gap:10,alignItems:"center"}}>
          <div title={item.name} style={{overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap",fontSize:13}}>{item.name}</div>
          <div style={{height:20,background:"#eef1f5",borderRadius:5,overflow:"hidden"}}>
            <div style={{height:"100%",width:`${Math.max(2, (item.visits / max) * 100)}%`,background:"#2563eb",borderRadius:5}} />
          </div>
          <strong style={{textAlign:"right"}}>{item.visits}</strong>
        </div>
      ))}
    </div>
  );
}

function PieChart({ data }) {
  const prepared = useMemo(() => {
    if (data.length <= 8) return data;
    const top = data.slice(0, 7);
    const other = data.slice(7).reduce((sum, item) => sum + item.visits, 0);
    return [...top, {name:"Other", visits:other}];
  }, [data]);

  const total = prepared.reduce((sum, item) => sum + item.visits, 0);
  const colors = ["#2563eb", "#16a34a", "#f59e0b", "#9333ea", "#dc2626", "#0891b2", "#ea580c", "#64748b"];
  let cumulative = 0;
  const stops = prepared.map((item, index) => {
    const start = total ? (cumulative / total) * 100 : 0;
    cumulative += item.visits;
    const end = total ? (cumulative / total) * 100 : 0;
    return `${colors[index % colors.length]} ${start}% ${end}%`;
  }).join(", ");

  return (
    <div style={{display:"flex",gap:28,alignItems:"center",flexWrap:"wrap",marginTop:16}}>
      <div aria-label="Page visit pie chart" style={{width:250,height:250,borderRadius:"50%",background: total ? `conic-gradient(${stops})` : "#eef1f5",flex:"0 0 auto"}} />
      <div style={{display:"grid",gap:10,minWidth:260,flex:1}}>
        {prepared.map((item, index) => (
          <div key={item.name} style={{display:"grid",gridTemplateColumns:"14px 1fr auto",gap:9,alignItems:"center"}}>
            <span style={{width:12,height:12,borderRadius:3,background:colors[index % colors.length]}} />
            <span>{item.name}</span>
            <strong>{item.visits}{total ? ` (${((item.visits / total) * 100).toFixed(1)}%)` : ""}</strong>
          </div>
        ))}
      </div>
    </div>
  );
}

export default function UiMetricsAdmin() {
  const [key, setKey] = useState("");
  const [fromDate, setFromDate] = useState(daysAgoIso(6));
  const [toDate, setToDate] = useState(todayIso());
  const [chartType, setChartType] = useState("bar");
  const [metrics, setMetrics] = useState(null);
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);

  async function getMetrics() {
    setBusy(true);
    setError("");
    setMetrics(null);
    try {
      const params = new URLSearchParams({ from: fromDate, to: toDate });
      const response = await fetch(`${API_BASE_URL}/ui-metrics/admin/range?${params.toString()}`, {
        headers: { "X-UI-Metrics-Admin-Key": key },
        cache: "no-store"
      });

      const contentType = response.headers.get("content-type") || "";
      const body = contentType.includes("application/json") ? await response.json() : await response.text();
      if (!response.ok) {
        const message = typeof body === "string" ? body : body?.message;
        throw new Error(message || `Server error (${response.status})`);
      }
      setMetrics(body);
    } catch (err) {
      setError(err.message || "Unable to load UI metrics");
    } finally {
      setBusy(false);
    }
  }

  const hasPageData = metrics?.pageVisits?.length > 0;

  return (
    <div className="card metricsAdmin" style={{maxWidth:1100,margin:"24px auto",padding:24}}>
      <h1>Server UI Usage Metrics</h1>
      <p>Restricted administrative view. Select a date range and compare page/tab visits using a bar or pie chart. No database is used.</p>

      <div style={{display:"grid",gridTemplateColumns:"repeat(auto-fit,minmax(190px,1fr))",gap:14,alignItems:"end"}}>
        <div>
          <label>Admin access key</label>
          <input type="password" autoComplete="off" value={key} onChange={e => setKey(e.target.value)} />
        </div>
        <div>
          <label>From date</label>
          <input type="date" value={fromDate} max={toDate || todayIso()} onChange={e => setFromDate(e.target.value)} />
        </div>
        <div>
          <label>To date</label>
          <input type="date" value={toDate} min={fromDate} max={todayIso()} onChange={e => setToDate(e.target.value)} />
        </div>
        <div>
          <label>Chart</label>
          <select value={chartType} onChange={e => setChartType(e.target.value)}>
            <option value="bar">Bar chart</option>
            <option value="pie">Pie chart</option>
          </select>
        </div>
      </div>

      <button className="runBtn" style={{marginTop:18}} disabled={busy || !key || !fromDate || !toDate || fromDate > toDate} onClick={getMetrics}>
        {busy ? "Loading..." : "View server metrics"}
      </button>

      {error && <div className="status" role="alert" style={{marginTop:16}}>{error}</div>}

      {metrics && (
        <div style={{marginTop:22}}>
          <div style={{marginBottom:14,fontWeight:600}}>{metrics.fromDate} to {metrics.toDate}</div>
          <div style={{display:"grid",gridTemplateColumns:"repeat(auto-fit,minmax(180px,1fr))",gap:12}}>
            <MetricCard label="Portal visits" value={metrics.portalVisits ?? 0} />
            <MetricCard label="Unique sessions" value={metrics.uniqueSessions ?? 0} />
            <MetricCard label="Total active time" value={metrics.totalActiveTime || "00:00:00"} />
            <MetricCard label="Pages / tabs tracked" value={metrics.pageVisits?.length ?? 0} />
          </div>

          <div style={{marginTop:24,padding:18,border:"1px solid #e5e9f0",borderRadius:10}}>
            <div style={{display:"flex",justifyContent:"space-between",gap:12,alignItems:"center",flexWrap:"wrap"}}>
              <h2 style={{margin:0}}>Page / Tab Visits</h2>
              <select value={chartType} onChange={e => setChartType(e.target.value)} style={{maxWidth:170}}>
                <option value="bar">Bar chart</option>
                <option value="pie">Pie chart</option>
              </select>
            </div>
            {!hasPageData && <p style={{marginBottom:0}}>No page or tab visits were recorded for this range.</p>}
            {hasPageData && chartType === "bar" && <BarChart data={metrics.pageVisits} />}
            {hasPageData && chartType === "pie" && <PieChart data={metrics.pageVisits} />}
          </div>

          {metrics.daily?.length > 0 && (
            <div style={{marginTop:24,overflowX:"auto"}}>
              <h2>Daily totals</h2>
              <table style={{width:"100%",borderCollapse:"collapse",minWidth:620}}>
                <thead>
                  <tr>
                    {['Date','Portal visits','Unique sessions','Active time'].map(head => <th key={head} style={{textAlign:"left",padding:"10px 12px",borderBottom:"1px solid #dfe3e8"}}>{head}</th>)}
                  </tr>
                </thead>
                <tbody>
                  {metrics.daily.map(day => (
                    <tr key={day.date}>
                      <td style={{padding:"10px 12px",borderBottom:"1px solid #eef1f4"}}>{day.date}</td>
                      <td style={{padding:"10px 12px",borderBottom:"1px solid #eef1f4"}}>{day.portalVisits}</td>
                      <td style={{padding:"10px 12px",borderBottom:"1px solid #eef1f4"}}>{day.uniqueSessions}</td>
                      <td style={{padding:"10px 12px",borderBottom:"1px solid #eef1f4"}}>{day.activeTime}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
