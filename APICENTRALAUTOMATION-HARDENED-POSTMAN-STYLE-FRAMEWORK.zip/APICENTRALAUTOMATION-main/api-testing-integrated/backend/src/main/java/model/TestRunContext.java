package model;

public class TestRunContext {
    public String runId;
    public String runDir;
    public String excelPath;
    public String htmlPath;
    public String extentPath;
    public String csvPath;
    public boolean reportPortalEnabled;
    public String projectName;
    // A cookie jar must belong to the run, not to the shared application.
    // This allows cookie-based session APIs without leaking cookies between users.
    private volatile java.net.http.HttpClient client;

    public synchronized java.net.http.HttpClient httpClient() {
        if (client == null) {
            java.net.CookieManager jar = new java.net.CookieManager(null, java.net.CookiePolicy.ACCEPT_ORIGINAL_SERVER);
            client = java.net.http.HttpClient.newBuilder()
                .cookieHandler(jar)
                .connectTimeout(java.time.Duration.ofSeconds(30))
                .followRedirects(java.net.http.HttpClient.Redirect.NORMAL)
                .build();
        }
        return client;
    }

    // Browser-uploaded attachments are stored only under the isolated run directory.
    public final java.util.Map<String, String> uploadedAttachments = new java.util.concurrent.ConcurrentHashMap<>();
}
