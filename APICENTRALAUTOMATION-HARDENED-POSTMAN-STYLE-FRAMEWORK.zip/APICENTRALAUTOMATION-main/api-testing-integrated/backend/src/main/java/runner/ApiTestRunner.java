package runner;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;
import com.opencsv.CSVWriter;
import model.ApiTestCase;
import model.AuthContext;
import model.TestRunContext;

import java.io.*;
import java.net.URI;
import java.time.Duration;
import java.util.Locale;
import java.util.LinkedHashMap;
import java.util.concurrent.CancellationException;
import org.sodales.HttpUriUtil;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.HashMap;
import java.util.concurrent.ConcurrentHashMap;
import java.util.Map;
import java.util.UUID;
import java.util.StringJoiner;
import org.sodales.ReportPortalManager;
import org.sodales.GlobalVariableHandler;
import org.sodales.OAuth2Client;

public class ApiTestRunner {

    private static final Map<String, ExtentReports> extentMap = new ConcurrentHashMap<>();

    public enum Outcome { PASS, FAIL, SKIPPED }

    /** Executes one Excel row. Per-row errors are reported as FAIL/SKIPPED, not thrown
     * through the run manager. Only genuine cancellation propagates out of this method. */
    public static Outcome run(ApiTestCase test,
            TestRunContext context,
            GlobalVariableHandler variableHandler,
            AuthContext authContext,
            ReportPortalManager reportPortal) {
        boolean itemStarted = false;
        boolean itemFinished = false;
        try {
            if (Thread.currentThread().isInterrupted()) throw new CancellationException("Run cancelled");
            // Do not let a failed second POST reuse an objectId created by an earlier POST.
            variableHandler.clearGlobalVariable(test.globalvariable);
            validateTestCase(test);
            // Resolve the POST-produced ID before URI validation. Use the exact resolved URL
            // for the report so an incorrect global variable is easy to diagnose.
            String resolvedUrl = variableHandler.globalvariableUrlReplacer(safeValue(test.url));
            if (hasMissingVariable(resolvedUrl))
                throw new MissingDependencyException("Required global variable was not generated for URL: " + resolvedUrl);
            URI uri = HttpUriUtil.fromSpreadsheet(resolvedUrl);

            if (reportPortal != null) {
                reportPortal.startTestItem(test.testName);
                itemStarted = true;
            }
            String method = safeValue(test.method).trim().toUpperCase(Locale.ROOT);
            String bodyType = normalizeBodyType(test.bodyType);
            HttpRequest.BodyPublisher publisher = "GET".equals(method) ? HttpRequest.BodyPublishers.noBody()
                    : buildBodyPublisher(test, context, variableHandler);
            String multipartBoundary = "FORM_DATA".equals(bodyType) && !"GET".equals(method)
                    ? CURRENT_MULTIPART_BOUNDARY.get() : null;
            CURRENT_MULTIPART_BOUNDARY.remove();

            String authType = safeValue(authContext.authenticationType);
            boolean oauth = "OAUTH".equalsIgnoreCase(authType) || "OAUTH2".equalsIgnoreCase(authType);
            if (oauth && OAuth2Client.freshTokenPerApi()) {
                // Optional, for systems requiring a different token for EVERY API row.
                OAuth2Client.getAccessToken(authContext);
            }
            HttpResponse<InputStream> response = null;
            for (int attempt = 0; attempt < 2; attempt++) {
                if (Thread.currentThread().isInterrupted()) throw new CancellationException("Run cancelled");
                HttpRequest.Builder builder = HttpRequest.newBuilder(uri)
                        .timeout(Duration.ofSeconds(apiTimeoutSeconds(test.timeoutSeconds)));
                if (oauth) {
                    if (OAuth2Client.isTokenMissingOrExpired(authContext)) OAuth2Client.getAccessToken(authContext);
                    builder.header("Authorization", "Bearer " + authContext.accessToken);
                } else if ("BASIC".equalsIgnoreCase(authType)) {
                    String creds = authContext.username + ":" + authContext.password;
                    builder.header("Authorization", "Basic " + java.util.Base64.getEncoder()
                            .encodeToString(creds.getBytes(StandardCharsets.UTF_8)));
                }
                if ("BEARER".equalsIgnoreCase(authType)) {
                    builder.header("Authorization", "Bearer " + authContext.bearerToken);
                }
                if ("API_KEY".equalsIgnoreCase(authType)) {
                    builder.header(authContext.apiKeyName, authContext.apiKeyValue);
                }
                if (test.headers != null && !test.headers.isBlank()) {
                    // Newlines are supported as delimiters, as well as legacy semicolons.
                    // Avoid logging header values: they may contain API keys or cookies.
                    for (String h : test.headers.split("\\r?\\n|;(?=\\s*[A-Za-z0-9-]+\\s*:)")) {
                        String[] kv = h.split(":", 2);
                        if (kv.length != 2 || kv[0].isBlank()) continue;
                        String key = kv[0].trim();
                        if (multipartBoundary != null && "content-type".equalsIgnoreCase(key)) continue;
                        if (!"NONE".equalsIgnoreCase(authType) && !"NO_AUTH".equalsIgnoreCase(authType)
                                && "authorization".equalsIgnoreCase(key)) continue;
                        if ("API_KEY".equalsIgnoreCase(authType) && key.equalsIgnoreCase(authContext.apiKeyName)) continue;
                        builder.header(key, variableHandler.globalvariablevaluereplacer(kv[1].trim()));
                    }
                }
                if (multipartBoundary != null) builder.header("Content-Type", "multipart/form-data; boundary=" + multipartBoundary);
                if ("URLENCODED".equals(bodyType) || "X_WWW_FORM_URLENCODED".equals(bodyType)
                        || "FORM_URLENCODED".equals(bodyType)) {
                    // Only supply the default if the spreadsheet did not specify its own content type.
                    if (test.headers == null || !test.headers.toLowerCase(Locale.ROOT).contains("content-type:"))
                        builder.header("Content-Type", "application/x-www-form-urlencoded");
                }
                switch (method) {
                    case "POST" -> builder.POST(publisher);
                    case "PUT" -> builder.PUT(publisher);
                    case "PATCH" -> builder.method("PATCH", publisher);
                    case "DELETE" -> builder.method("DELETE", publisher);
                    case "GET" -> builder.GET();
                    case "HEAD" -> builder.method("HEAD", HttpRequest.BodyPublishers.noBody());
                    case "OPTIONS" -> builder.method("OPTIONS", HttpRequest.BodyPublishers.noBody());
                    default -> throw new IllegalArgumentException("Unsupported HTTP method: " + method);
                }
                response = context.httpClient().send(builder.build(), HttpResponse.BodyHandlers.ofInputStream());
                if (response.statusCode() != 401 || attempt == 1 || !oauth) break;
                try (InputStream ignored = response.body()) { /* discard 401 stream before retry */ }
                org.sodales.LogCollector.log("OAuth 401: refreshing token and retrying API once only.");
                OAuth2Client.refreshAccessToken(authContext);
            }
            if (Thread.currentThread().isInterrupted()) {
                response.body().close();
                throw new CancellationException("Run cancelled");
            }
            int status = response.statusCode();
            boolean downloadable = "GET".equals(method)
                    && (isDownload(response) || requestedFileDownload(test));
            String responseBody;
            try (InputStream content = response.body()) {
                if (downloadable && status >= 200 && status < 300) {
                    Path output = saveAttachment(context, test, response, content);
                    responseBody = "[Attachment saved to downloads/" + output.getFileName()
                            + " (" + Files.size(output) + " bytes)]";
                    org.sodales.LogCollector.log("GET downloaded attachment: " + output.getFileName());
                } else {
                    // Read only text/non-success responses into memory; file bytes stream
                    // directly into per-run downloads/ regardless of file extension.
                    String type = response.headers().firstValue("Content-Type").orElse("");
                    java.nio.charset.Charset charset = StandardCharsets.UTF_8;
                    java.util.regex.Matcher matcher = java.util.regex.Pattern.compile(
                            "charset=([\\w-]+)", java.util.regex.Pattern.CASE_INSENSITIVE).matcher(type);
                    if (matcher.find()) try { charset = java.nio.charset.Charset.forName(matcher.group(1)); }
                        catch (Exception ignored) {}
                    // Limit unstructured text responses to prevent OOM on unexpected huge payloads.
                    // Large binary attachments still stream without this limit.
                    int maxBytes = maxTextResponseBytes();
                    byte[] received = content.readNBytes(maxBytes + 1);
                    if (received.length > maxBytes) {
                        throw new IOException("Response exceeds QA_MAX_TEXT_RESPONSE_MB (" + (maxBytes / 1048576)
                            + " MB). Use ResponseType=FILE to download a large response as an attachment.");
                    }
                    responseBody = new String(received, charset);
                }
            }
            if (status >= 400 && responseBody.toLowerCase(Locale.ROOT).contains("mpl id")) {
                org.sodales.LogCollector.log("Upstream SAP/CPI API failed with HTTP " + status
                        + " and MPL ID. This is a server-side integration error; compare the request URL,"
                        + " method, authorization and headers against Postman. Response: "
                        + responseBody.substring(0, Math.min(responseBody.length(), 750)));
            }
            boolean passed = matchesExpectedStatus(test.expectedStatus, status)
                    && (safeValue(test.expectedResponse).isBlank()
                        || "NA".equalsIgnoreCase(safeValue(test.expectedResponse))
                        || responseBody.contains(safeValue(test.expectedResponse)));

            // A dependent GET must not receive an old objectId if a preceding POST
            // failed its assertions or its variable extraction.
            if (passed && !downloadable && status >= 200 && status < 300) {
                try {
                    variableHandler.setGlobalVariable(test.globalvariablejsonxmlpath,
                            test.globalvariable, responseBody, test.xmlorjson);
                } catch (Exception extractionError) {
                    passed = false;
                    String message = "Global-variable extraction failed: " + safeError(extractionError);
                    org.sodales.LogCollector.log("Test '" + safeValue(test.testName) + "' " + message);
                    responseBody += "\n[" + message + "]";
                }
            } else if (downloadable && hasVariableOutput(test)) {
                passed = false;
                responseBody += "\n[Cannot extract JSON/XML variables from a binary attachment]";
            } else if (!passed && hasVariableOutput(test)) {
                org.sodales.LogCollector.log("Global variable '" + test.globalvariable
                        + "' not saved because the producing test did not pass.");
            }

            Outcome outcome = passed ? Outcome.PASS : Outcome.FAIL;
            recordResult(context, test, resolvedUrl, String.valueOf(status), responseBody, outcome, authContext);
            org.sodales.LogCollector.log("Completed: " + test.testName + " | " + method + " " + uri
                    + " | HTTP " + status + " | " + outcome);
            if (reportPortal != null) {
                reportPortal.log("Method: " + method);
                reportPortal.log("URL: " + resolvedUrl);
                reportPortal.log("HTTP status: " + status);
                reportPortal.log("Test " + (passed ? "PASSED" : "FAILED"));
                reportPortal.finishTestItem(passed ? "PASSED" : "FAILED");
                itemFinished = true;
            }
            return outcome;
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            throw new CancellationException("Run cancelled during HTTP call");
        } catch (CancellationException e) {
            throw e;
        } catch (Exception e) {
            if (Thread.currentThread().isInterrupted()) throw new CancellationException("Run cancelled");
            Outcome outcome = e instanceof MissingDependencyException ? Outcome.SKIPPED : Outcome.FAIL;
            String reason = safeError(e);
            org.sodales.LogCollector.log("Test '" + safeValue(test.testName) + "' " + outcome
                    + ": " + reason + " (continuing to next Excel row)");
            // Record exactly one failure/skip row even if the HTTP request never reached the server.
            try {
                recordResult(context, test, safeValue(test.url),
                        outcome == Outcome.SKIPPED ? "SKIPPED" : "ERROR", reason, outcome, authContext);
            } catch (Exception reportError) {
                org.sodales.LogCollector.log("Failed to record row result: " + safeError(reportError));
            }
            if (reportPortal != null && !itemFinished) {
                if (!itemStarted) reportPortal.startTestItem(test.testName);
                reportPortal.log("Test " + outcome + ": " + reason);
                reportPortal.finishTestItem(outcome == Outcome.SKIPPED ? "SKIPPED" : "FAILED");
            }
            return outcome;
        } finally {
            // Multipart boundary belongs to one Excel row; never leak it into the next.
            CURRENT_MULTIPART_BOUNDARY.remove();
        }
    }

    private static final class MissingDependencyException extends IllegalArgumentException {
        MissingDependencyException(String message) { super(message); }
    }

    private static boolean hasMissingVariable(String value) {
        return value != null && java.util.regex.Pattern.compile(
                "\\[\\[[^]\\r\\n]+]]|\\$\\{[^}\\r\\n]+}|\\{\\{[^}\\r\\n]+}}")
                .matcher(value).find();
    }

    private static boolean hasVariableOutput(ApiTestCase test) {
        String name = safeValue(test.globalvariable).trim();
        return !name.isBlank() && !"NA".equalsIgnoreCase(name);
    }

    private static String safeError(Exception e) {
        String message = e.getMessage();
        if (message == null || message.isBlank()) message = e.getClass().getSimpleName();
        return message.length() > 1500 ? message.substring(0, 1500) : message;
    }

    /** Public only so ApiTests can recover if an unexpected row-level error escapes. */
    public static void recordUnhandledFailure(ApiTestCase test, TestRunContext context, Exception failure) {
        recordResult(context, test, safeValue(test.url), "ERROR", safeError(failure), Outcome.FAIL, null);
    }

    private static void recordResult(TestRunContext context, ApiTestCase test,
                                     String resolvedUrl, String actualCode,
                                     String responseBody, Outcome outcome, AuthContext auth) {
        // Only sanitized diagnostics go into reports. Raw credentials can still be
        // used to execute requests, but must not appear in exported ZIP files.
        String publicUrl = redactSecrets(resolvedUrl, test.headers, auth);
        String publicBody = redactSecrets(responseBody, test.headers, auth);
        String publicExpected = redactSecrets(test.expectedResponse, test.headers, auth);
        String publicHeaders = redactHeaders(safeValue(test.headers));
        writeToCSV(context.csvPath, publicUrl, publicHeaders,
                safeValue(test.expectedStatus), actualCode, publicExpected,
                publicBody, outcome);
        writeToHTML(context.htmlPath, safeValue(test.testName), publicUrl,
                publicHeaders, safeValue(test.expectedStatus), actualCode,
                publicExpected, publicBody, outcome);
        extendReport(context, safeValue(test.testName), publicUrl, publicHeaders,
                safeValue(test.expectedStatus), actualCode, publicExpected,
                publicBody, outcome);
    }

    private static final ThreadLocal<String> CURRENT_MULTIPART_BOUNDARY = new ThreadLocal<>();

    /** Optional Excel ResponseType=FILE handles APIs serving files as text/plain. */
    private static boolean requestedFileDownload(ApiTestCase test) {
        String responseType = safeValue(test.responseType).trim();
        return "FILE".equalsIgnoreCase(responseType)
            || "BINARY".equalsIgnoreCase(responseType)
            || "DOWNLOAD".equalsIgnoreCase(responseType)
            || "ATTACHMENT".equalsIgnoreCase(responseType);
    }

    private static boolean isDownload(HttpResponse<?> response) {
        String disposition = response.headers().firstValue("Content-Disposition").orElse("").toLowerCase(Locale.ROOT);
        String type = response.headers().firstValue("Content-Type").orElse("").toLowerCase(Locale.ROOT);
        if (disposition.contains("attachment") || disposition.contains("filename=")) return true;
        if (type.startsWith("image/") || type.startsWith("audio/") || type.startsWith("video/")
                || type.startsWith("text/csv")) return true;
        if (type.startsWith("application/") && !type.contains("json")
                && !type.contains("xml") && !type.contains("javascript")
                && !type.contains("graphql") && !type.contains("x-www-form-urlencoded")) return true;
        return false;
    }

    private static Path saveAttachment(TestRunContext context, ApiTestCase test,
                                       HttpResponse<?> response, InputStream body) throws IOException {
        Path dir = Path.of(context.runDir, "downloads");
        Files.createDirectories(dir);
        String disposition = response.headers().firstValue("Content-Disposition").orElse("");
        String name = "";
        java.util.regex.Matcher m = java.util.regex.Pattern.compile("filename\\*?=(?:UTF-8''|\")?([^;\"]+)", java.util.regex.Pattern.CASE_INSENSITIVE).matcher(disposition);
        if (m.find()) name = m.group(1).trim();
        if (name.isBlank()) name = safeValue(test.testName) + "_download.bin";
        name = name.replaceAll("[^a-zA-Z0-9._-]", "_");
        if (name.isBlank() || name.equals(".") || name.equals("..")) name = "attachment.bin";
        Path target = dir.resolve(UUID.randomUUID().toString().substring(0,8) + "_" + name);
        try {
            Files.copy(body, target);
            return target;
        } catch (IOException | RuntimeException e) {
            Files.deleteIfExists(target); // never package an incomplete download
            throw e;
        }
    }

    private static void validateTestCase(ApiTestCase test) {
        String method = safeValue(test.method).trim().toUpperCase();
        String bodyType = normalizeBodyType(test.bodyType);

        if (safeValue(test.url).isEmpty()) {
            throw new IllegalArgumentException("URL is missing for test: " + safeValue(test.testName));
        }

        if (method.isEmpty()) {
            throw new IllegalArgumentException("HTTP method is missing for test: " + safeValue(test.testName));
        }

        if (bodyType.equals("RAW") || bodyType.equals("PAYLOAD")) {
            if (safeValue(test.payload).isEmpty()) {
                org.sodales.LogCollector.log("Warning: Payload is empty for test: " + safeValue(test.testName));
            }
        }

        if (bodyType.equals("FORM_DATA")) {
            if (safeValue(test.formData).isEmpty()) {
                org.sodales.LogCollector.log("Warning: FormData is empty for test: " + safeValue(test.testName));
            }
        }

        if (bodyType.equals("BINARY")) {
            if (safeValue(test.filePath).isEmpty()) {
                throw new IllegalArgumentException("Binary file path is missing for test: " + safeValue(test.testName));
            }
        }
    }

    private static HttpRequest.BodyPublisher buildBodyPublisher(
            ApiTestCase test, TestRunContext context, GlobalVariableHandler variableHandler) throws Exception {
        String bodyType = normalizeBodyType(test.bodyType);
        switch (bodyType) {
            case "RAW": case "PAYLOAD":
                return HttpRequest.BodyPublishers.ofString(
                    variableHandler.globalvariablevaluereplacer(safeValue(test.payload)));
            case "URLENCODED": case "X_WWW_FORM_URLENCODED": case "FORM_URLENCODED":
                String formData = variableHandler.globalvariablevaluereplacer(safeValue(test.formData));
                if (formData.isBlank()) formData = variableHandler.globalvariablevaluereplacer(safeValue(test.payload));
                StringJoiner query = new StringJoiner("&");
                for (String pair : formData.split("[;\r\n&]+")) {
                    if (pair.isBlank()) continue;
                    int split = pair.indexOf('=');
                    if (split < 0) split = pair.indexOf(':');
                    if (split <= 0) throw new IllegalArgumentException("URLENCODED fields must be key=value or key:value");
                    query.add(java.net.URLEncoder.encode(pair.substring(0, split).trim(), StandardCharsets.UTF_8)
                        + "=" + java.net.URLEncoder.encode(pair.substring(split + 1).trim(), StandardCharsets.UTF_8));
                }
                return HttpRequest.BodyPublishers.ofString(query.toString());
            case "BINARY":
                return HttpRequest.BodyPublishers.ofFile(
                    resolveUploadPath(context, variableHandler.globalvariablevaluereplacer(safeValue(test.filePath))));
            case "FORM_DATA":
                String boundary = "----Boundary" + UUID.randomUUID();
                CURRENT_MULTIPART_BOUNDARY.set(boundary);
                ParsedFormData parsed = parseFormData(variableHandler.globalvariablevaluereplacer(safeValue(test.formData)));
                // Excel's FilePath column is supported for multipart POST uploads, not only
                // BINARY uploads; "field=@/path" selects the form field name (default: file).
                String pathValue = variableHandler.globalvariablevaluereplacer(safeValue(test.filePath)).trim();
                if (!pathValue.isBlank() && !"NA".equalsIgnoreCase(pathValue)) {
                    String field = "file";
                    if (pathValue.contains("=@")) {
                        String[] chunks = pathValue.split("=@", 2);
                        field = chunks[0].trim(); pathValue = chunks[1].trim();
                    } else if (pathValue.startsWith("@")) pathValue = pathValue.substring(1);
                    if (field.isBlank()) field = "file";
                    parsed.files.put(field, resolveUploadPath(context, pathValue));
                }
                for (Map.Entry<String,Path> file : parsed.files.entrySet()) {
                    file.setValue(resolveUploadPath(context, file.getValue().toString()));
                }
                return buildMultipartBody(parsed.fields, parsed.files, boundary);
            case "NONE": case "": return HttpRequest.BodyPublishers.noBody();
            default: throw new IllegalArgumentException("Unsupported body type: " + bodyType);
        }
    }

    private static Path resolveUploadPath(TestRunContext context, String spreadsheetPath) throws IOException {
        String raw = safeValue(spreadsheetPath).trim();
        if (raw.startsWith("@")) raw = raw.substring(1);
        if (raw.isBlank()) throw new IOException("Attachment path is blank");
        Path direct = Path.of(raw);
        if (Files.isRegularFile(direct)) return direct;
        String base = raw.replace('\\', '/');
        base = base.substring(base.lastIndexOf('/') + 1).replaceAll("[^a-zA-Z0-9._-]", "_");
        String uploaded = context.uploadedAttachments.get(base);
        if (uploaded != null && Files.isRegularFile(Path.of(uploaded))) return Path.of(uploaded);
        throw new IOException("Attachment '" + raw + "' is unavailable to the server. "
                + "Upload it using Additional Attachments in the UI (matching the Excel filename).");
    }

    private static ParsedFormData parseFormData(String formDataText) {
        Map<String, String> fields = new LinkedHashMap<>();
        Map<String, Path> files = new LinkedHashMap<>();

        if (formDataText == null || formDataText.trim().isEmpty()) {
            return new ParsedFormData(fields, files);
        }

        String[] pairs = formDataText.split(";");
        for (String pair : pairs) {
            String[] parts = pair.split(":", 2);
            if (parts.length < 2) {
                continue;
            }

            String key = parts[0].trim();
            String value = parts[1].trim();

            if (value.startsWith("@")) {
                files.put(key, Path.of(value.substring(1)));
            } else {
                fields.put(key, value);
            }
        }

        return new ParsedFormData(fields, files);
    }

    private static HttpRequest.BodyPublisher buildMultipartBody(
            Map<String, String> fields,
            Map<String, Path> files,
            String boundary) throws Exception {

        // Stream directly from each file. The previous ByteArrayOutputStream
        // held every attachment in JVM RAM (100 MB attachments could exhaust
        // the server while other users were waiting in FIFO).
        java.util.List<HttpRequest.BodyPublisher> publishers = new java.util.ArrayList<>();
        for (Map.Entry<String, String> entry : fields.entrySet()) {
            String key = safeMultipartHeader(entry.getKey());
            String prefix = "--" + boundary + "\r\n"
                    + "Content-Disposition: form-data; name=\"" + key + "\"\r\n\r\n"
                    + entry.getValue() + "\r\n";
            publishers.add(HttpRequest.BodyPublishers.ofByteArray(prefix.getBytes(StandardCharsets.UTF_8)));
        }
        for (Map.Entry<String, Path> entry : files.entrySet()) {
            Path path = entry.getValue();
            if (!Files.isRegularFile(path)) throw new IOException("Upload file not found: " + path);
            String mimeType = Files.probeContentType(path);
            if (mimeType == null || mimeType.isBlank()) mimeType = "application/octet-stream";
            String field = safeMultipartHeader(entry.getKey());
            String filename = safeMultipartHeader(path.getFileName().toString());
            String prefix = "--" + boundary + "\r\n"
                    + "Content-Disposition: form-data; name=\"" + field + "\"; filename=\""
                    + filename + "\"\r\n"
                    + "Content-Type: " + mimeType + "\r\n\r\n";
            publishers.add(HttpRequest.BodyPublishers.ofByteArray(prefix.getBytes(StandardCharsets.UTF_8)));
            publishers.add(HttpRequest.BodyPublishers.ofFile(path));
            publishers.add(HttpRequest.BodyPublishers.ofByteArray("\r\n".getBytes(StandardCharsets.UTF_8)));
        }
        publishers.add(HttpRequest.BodyPublishers.ofByteArray(
                ("--" + boundary + "--\r\n").getBytes(StandardCharsets.UTF_8)));
        return HttpRequest.BodyPublishers.concat(publishers.toArray(new HttpRequest.BodyPublisher[0]));
    }

    private static String safeMultipartHeader(String name) {
        // Untrusted filenames/form keys must not insert additional MIME headers.
        return safeValue(name).replace("\r", "_").replace("\n", "_").replace("\"", "_");
    }

    private static class ParsedFormData {
        Map<String, String> fields;
        Map<String, Path> files;

        ParsedFormData(Map<String, String> fields, Map<String, Path> files) {
            this.fields = fields;
            this.files = files;
        }
    }

    private static void writeToCSV(String csvPath, String requestUrl,
                                   String requestHeaders, String expectedCode, String actualCode,
                                   String expectedBody, String actualBody, Outcome outcome) {
        File file = new File(csvPath);
        boolean writeHeader = !file.exists() || file.length() == 0;
        try (CSVWriter writer = new CSVWriter(new FileWriter(file, true))) {
            if (writeHeader) writer.writeNext(new String[] {
                    "Request URL", "Request Headers", "Expected Response Code",
                    "Actual Response Code", "Expected Response Body", "Actual Response Body", "Result"
            });
            writer.writeNext(new String[] { requestUrl, requestHeaders, expectedCode,
                    actualCode, expectedBody, actualBody, outcome.name() });
        } catch (IOException e) {
            throw new java.io.UncheckedIOException("Cannot write CSV result", e);
        }
    }

    private static void writeToHTML(String htmlPath, String testName, String requestUrl,
                                    String requestHeaders, String expectedCode, String actualCode,
                                    String expectedBody, String actualBody, Outcome outcome) {
        File file = new File(htmlPath);
        boolean writeHeader = !file.exists() || file.length() == 0;
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(file, true))) {
            if (writeHeader) {
                writer.write("<html><head><style>body{font-family:Arial;padding:20px}"
                        + "table{border-collapse:collapse;width:100%}"
                        + "th,td{border:1px solid #ddd;padding:8px;vertical-align:top}"
                        + "th{background:#f2f2f2}.pass{background:#d4edda}"
                        + ".fail{background:#f8d7da}.skipped{background:#fff3cd}"
                        + "</style></head><body><h2>API Debug Report</h2><table>"
                        + "<tr><th>Test Name</th><th>Request URL</th>"
                        + "<th>Request Headers</th><th>Expected Response Code</th>"
                        + "<th>Actual Response Code</th><th>Expected Response Body</th>"
                        + "<th>Actual Response Body</th><th>Result</th></tr>");
            }
            String rowClass = outcome.name().toLowerCase(Locale.ROOT);
            writer.write("<tr class='" + rowClass + "'><td>" + escapeHTML(testName)
                    + "</td><td>" + escapeHTML(requestUrl) + "</td><td><pre>"
                    + escapeHTML(requestHeaders) + "</pre></td><td>"
                    + escapeHTML(expectedCode) + "</td><td>" + escapeHTML(actualCode)
                    + "</td><td><pre>" + escapeHTML(expectedBody) + "</pre></td><td><pre>"
                    + escapeHTML(actualBody) + "</pre></td><td>" + outcome.name() + "</td></tr>");
        } catch (IOException e) {
            throw new java.io.UncheckedIOException("Cannot write HTML result", e);
        }
    }

    private static ExtentReports getExtent(TestRunContext context) {
        return extentMap.computeIfAbsent(context.runId, runId -> {
            ExtentReports extent = new ExtentReports();
            ExtentSparkReporter spark = new ExtentSparkReporter(context.extentPath);
            extent.attachReporter(spark);
            return extent;
        });
    }

    private static void extendReport(TestRunContext context, String testName,
                                     String requestUrl, String requestHeaders,
                                     String expectedCode, String actualCode,
                                     String expectedBody, String actualBody,
                                     Outcome outcome) {
        ExtentTest item = getExtent(context).createTest(testName);
        item.info("Request URL: " + requestUrl);
        item.info("Request Headers: " + requestHeaders);
        item.info("Expected HTTP status: " + expectedCode + "; Actual: " + actualCode);
        item.info("Expected response contains: " + expectedBody);
        item.info("Response: " + actualBody);
        if (outcome == Outcome.PASS) item.pass("API passed");
        else if (outcome == Outcome.SKIPPED) item.skip("Dependent API skipped: " + actualBody);
        else item.fail("API failed: " + actualBody);
        getExtent(context).flush();
    }

    public static void closeRun(String runId) {
        ExtentReports extent = extentMap.remove(runId);
        if (extent != null) {
            try {
                extent.flush();
            } catch (Exception ignored) {
            }
        }
    }

    private static String escapeHTML(String text) {
        if (text == null) {
            return "";
        }
        return text.replace("&", "&amp;")
                .replace("<", "&lt;")
                .replace(">", "&gt;");
    }

    private static String normalizeBodyType(String value) {
        String type = safeValue(value).trim().toUpperCase(Locale.ROOT)
                .replace('-', '_').replace(' ', '_');
        if (type.equals("FORMDATA") || type.equals("MULTIPART")
                || type.equals("MULTIPART_FORM_DATA")) return "FORM_DATA";
        return type;
    }

    private static int maxTextResponseBytes() {
        int size = 20;
        try { size = Integer.parseInt(System.getenv().getOrDefault("QA_MAX_TEXT_RESPONSE_MB", "20")); }
        catch (NumberFormatException ignored) { }
        return Math.max(1, Math.min(size, 100)) * 1048576;
    }

    private static int apiTimeoutSeconds(String override) {
        int defaultValue = 120;
        try {
            defaultValue = Integer.parseInt(System.getenv().getOrDefault("QA_API_TIMEOUT_SECONDS", "120"));
        } catch (NumberFormatException ignored) { }
        try {
            if (override != null && !override.isBlank()) defaultValue = Integer.parseInt(override.trim());
        } catch (NumberFormatException e) {
            throw new IllegalArgumentException("TimeoutSeconds must be a whole number: " + override);
        }
        return Math.max(5, Math.min(defaultValue, 1800));
    }

    /** Blank = successful 2xx, or use 200, 200-204, 2xx, 200|201, ANY. */
    private static boolean matchesExpectedStatus(String expected, int actual) {
        String v = safeValue(expected).trim().toUpperCase(Locale.ROOT);
        if (v.isBlank() || v.equals("2XX")) return actual >= 200 && actual < 300;
        if (v.equals("ANY") || v.equals("*")) return true;
        for (String token : v.split("[,|]")) {
            token = token.trim();
            if (token.matches("[1-5]XX") && actual / 100 == (token.charAt(0) - '0')) return true;
            if (token.matches("[1-5]\\d{2}")) {
                if (Integer.parseInt(token) == actual) return true;
            } else if (token.matches("[1-5]\\d{2}-[1-5]\\d{2}")) {
                String[] range = token.split("-");
                if (actual >= Integer.parseInt(range[0]) && actual <= Integer.parseInt(range[1])) return true;
            } else if (!token.matches("[1-5]XX")) {
                throw new IllegalArgumentException("Invalid ExpectedStatus: " + expected);
            }
        }
        return false;
    }


    private static String redactSecrets(String data, String configuredHeaders, AuthContext auth) {
        if (data == null) return "";
        String sanitized = data;
        if (auth != null) {
            sanitized = redactValue(sanitized, auth.password);
            sanitized = redactValue(sanitized, auth.clientSecret);
            sanitized = redactValue(sanitized, auth.bearerToken);
            sanitized = redactValue(sanitized, auth.apiKeyValue);
            sanitized = redactValue(sanitized, auth.accessToken);
            sanitized = redactValue(sanitized, auth.refreshToken);
        }
        // Authorization and API-key values supplied via the Excel Headers column
        // are not present in AuthContext, so mask those separately.
        for (String line : safeValue(configuredHeaders).split("\\r?\\n|;(?=\\s*[A-Za-z0-9-]+\\s*:)" )) {
            String[] pair = line.split(":", 2);
            if (pair.length != 2) continue;
            String key = pair[0].trim().toLowerCase(Locale.ROOT);
            if (key.equals("authorization") || key.equals("proxy-authorization")
                    || key.equals("x-api-key") || key.equals("api-key")
                    || key.equals("cookie") || key.equals("set-cookie")) {
                sanitized = redactValue(sanitized, pair[1].trim());
            }
        }
        return sanitized;
    }

    private static String redactValue(String text, String secret) {
        if (secret == null || secret.length() < 4) return text;
        return text.replace(secret, "[REDACTED]");
    }
    private static String redactHeaders(String headers) {
        if (headers.isBlank()) return headers;
        StringJoiner safe = new StringJoiner("; ");
        for (String header : headers.split("\\r?\\n|;(?=\\s*[A-Za-z0-9-]+\\s*:)")) {
            String[] pair = header.split(":", 2);
            if (pair.length == 2) {
                String key = pair[0].trim().toLowerCase(Locale.ROOT);
                if (key.equals("authorization") || key.equals("proxy-authorization")
                        || key.equals("x-api-key") || key.equals("api-key")
                        || key.equals("cookie") || key.equals("set-cookie")) {
                    safe.add(pair[0].trim() + ": [REDACTED]");
                    continue;
                }
            }
            safe.add(header.trim());
        }
        return safe.toString();
    }

    private static String safeValue(String value) {
        return value == null ? "" : value;
    }
}