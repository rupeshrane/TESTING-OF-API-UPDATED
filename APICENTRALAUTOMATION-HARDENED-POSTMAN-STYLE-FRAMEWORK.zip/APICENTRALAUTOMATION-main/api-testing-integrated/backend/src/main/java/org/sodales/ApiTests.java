package org.sodales;

import model.ApiTestCase;
import model.AuthContext;
import model.RunRecord;
import model.TestRunContext;
import reader.ExcelReader;
import runner.ApiTestRunner;

import java.util.List;
import java.util.concurrent.CancellationException;

public class ApiTests {
    public static void run(TestRunContext context, AuthContext authContext, RunRecord record) {
        GlobalVariableHandler variableHandler = new GlobalVariableHandler(); // per-run only
        List<ApiTestCase> tests = ExcelReader.readTestCases(context.excelPath);
        record.totalTests.set((int) tests.stream().filter(t -> !"yes".equalsIgnoreCase(t.skip)).count());
        ReportPortalManager reportPortal = context.reportPortalEnabled
                ? new ReportPortalManager(context.projectName) : null;
        LogCollector.log("Run " + context.runId + " processing " + record.totalTests.get() + " tests.");
        try {
            checkCancelled(record);
            if (reportPortal != null) reportPortal.startLaunch();
            for (ApiTestCase test : tests) {
                checkCancelled(record);
                if ("yes".equalsIgnoreCase(test.skip)) {
                    LogCollector.log("Skipping " + test.testName);
                    continue;
                }
                LogCollector.log("Executing " + test.testName);
                ApiTestRunner.Outcome result;
                try {
                    result = ApiTestRunner.run(test, context, variableHandler, authContext, reportPortal);
                } catch (CancellationException e) {
                    throw e; // Cancelling the run must stop the remaining Excel rows.
                } catch (Exception e) {
                    checkCancelled(record);
                    LogCollector.log("Unexpected row error for '" + test.testName
                            + "': " + e.getMessage() + "; continuing with next independent API.");
                    try { ApiTestRunner.recordUnhandledFailure(test, context, e); }
                    catch (Exception reportError) {
                        LogCollector.log("Could not save failed row: " + reportError.getMessage());
                    }
                    result = ApiTestRunner.Outcome.FAIL;
                }
                record.executedTests.incrementAndGet();
                switch (result) {
                    case PASS -> record.passedTests.incrementAndGet();
                    case FAIL -> record.failedTests.incrementAndGet();
                    case SKIPPED -> record.skippedTests.incrementAndGet();
                }
                checkCancelled(record);
            }
        } finally {
            // ReportPortal calls may need interrupt cleared so cancellation can still finalize a launch.
            if (reportPortal != null) {
                boolean interrupted = Thread.interrupted();
                try { reportPortal.finishLaunch(); }
                finally { if (interrupted) Thread.currentThread().interrupt(); }
            }
        }
        LogCollector.log("Finished all " + record.executedTests.get() + " executed tests: "
                + record.passedTests.get() + " PASS, " + record.failedTests.get() + " FAIL, "
                + record.skippedTests.get() + " SKIPPED. FIFO queue can now start the next run.");
    }
    private static void checkCancelled(RunRecord record) {
        if (record.cancelRequested.get() || Thread.currentThread().isInterrupted())
            throw new CancellationException("Run was cancelled");
    }
}
