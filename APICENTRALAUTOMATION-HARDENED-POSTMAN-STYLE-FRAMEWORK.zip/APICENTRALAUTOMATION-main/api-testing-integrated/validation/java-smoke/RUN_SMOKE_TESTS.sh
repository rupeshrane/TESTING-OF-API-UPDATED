#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
mkdir -p classes
find src -name '*.java' > sources.list
javac -encoding UTF-8 -d classes @sources.list
for test in ApiIntegrationSmoke IsolationIntegrationSmoke OAuthCancellationSmoke ExtendedApiSmoke; do
  echo "==== $test ===="
  java -cp classes "$test"
done
