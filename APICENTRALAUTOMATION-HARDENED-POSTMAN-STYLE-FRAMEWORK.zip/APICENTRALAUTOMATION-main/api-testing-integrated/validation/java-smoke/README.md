# Local Java mock smoke tests (independent of Maven)

**Windows:** open Command Prompt in this folder and run `RUN_SMOKE_TESTS_WINDOWS.bat` with JDK 17+ installed.

**Linux/macOS:** run `bash RUN_SMOKE_TESTS.sh`.

This suite uses a standard-library local HTTP server and simplified stub classes to validate the HTTP runner. The `src` folder is intentionally **outside** `backend/src` and **is not a substitute** for the real Maven/Spring Boot build. Tests cover authenticated headers, binary multipart POST/download chaining, cookie isolation, bounded OAuth retries/cancellation, and per-API failure continuation.
