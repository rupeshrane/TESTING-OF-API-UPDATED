package org.sodales;
import java.util.regex.*;
public class JSONFilePathHandler {
 protected String readJsonPath(String body,String path) {
  String name = path.substring(path.lastIndexOf('.')+1);
  Matcher m=Pattern.compile("\\\""+Pattern.quote(name)+"\\\"\\s*:\\s*(?:\\\"([^\\\"]+)\\\"|([0-9]+))").matcher(body);
  if(m.find())return m.group(1)==null?m.group(2):m.group(1);
  return null;
 }
 protected String readXmlPath(String body,String path){return null;}
}
