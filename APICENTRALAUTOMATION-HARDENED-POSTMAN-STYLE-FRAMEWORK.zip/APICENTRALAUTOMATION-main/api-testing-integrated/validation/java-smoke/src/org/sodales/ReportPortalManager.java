package org.sodales;
public class ReportPortalManager {
 public ReportPortalManager(String project){}
 public void startLaunch(){}
 public void finishLaunch(){}
 public void startTestItem(String s){}
 public void log(String s){}
 public void finishTestItem(String s){}
}
