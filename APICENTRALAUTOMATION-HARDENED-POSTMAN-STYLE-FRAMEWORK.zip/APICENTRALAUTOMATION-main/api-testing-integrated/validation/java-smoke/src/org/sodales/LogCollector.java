package org.sodales;
public class LogCollector { public static void log(String s) { System.out.println(s); } }
