package reader;
import model.ApiTestCase;
import java.util.*;
public final class ExcelReader {
 public static List<ApiTestCase> tests = new ArrayList<>();
 public static List<ApiTestCase> readTestCases(String ignored){return tests;}
}
