import com.sun.net.httpserver.HttpServer;
import model.*;
import reader.ExcelReader;
import org.sodales.*;
import java.net.*;
import java.nio.file.*;
import java.nio.charset.StandardCharsets;
import java.util.*;

public class IsolationIntegrationSmoke {
 static ApiTestCase api(String title,String method,String url) {
  ApiTestCase t=new ApiTestCase();t.testName=title;t.method=method;t.url=url;
  t.expectedStatus="200";t.expectedResponse="NA";t.bodyType="NONE";
  return t;
 }
 static void reply(com.sun.net.httpserver.HttpExchange e,int status,String data) throws java.io.IOException {
  byte[] b=data.getBytes(StandardCharsets.UTF_8);
  e.getResponseHeaders().set("Content-Type","application/json");
  e.sendResponseHeaders(status,b.length);
  try(var o=e.getResponseBody()){o.write(b);}
 }
 public static void main(String[] args) throws Exception {
  HttpServer server=HttpServer.create(new InetSocketAddress("127.0.0.1",0),0);
  server.createContext("/good", e->reply(e,200,"{\"ok\":true}"));
  server.createContext("/fail", e->reply(e,500,"{\"error\":\"simulated\"}"));
  server.createContext("/create", e->reply(e,200,"{\"objectId\":\"OBJ-42\"}"));
  server.createContext("/missingId", e->reply(e,200,"{\"noObjectId\":\"foo\"}"));
  server.createContext("/download/OBJ-42", e->reply(e,200,"{\"file\":\"ok\"}"));
  server.start();
  String base="http://127.0.0.1:"+server.getAddress().getPort();
  try {
   var tmp=Files.createTempDirectory("isolation-validation");
   var ctx=new TestRunContext();ctx.runId="RTEST1";ctx.runDir=tmp.toString();
   ctx.excelPath="stub";ctx.csvPath=tmp.resolve("test.csv").toString();
   ctx.htmlPath=tmp.resolve("test.html").toString();ctx.extentPath=tmp.resolve("extent.html").toString();
   var rec=new RunRecord(ctx,"owner1");
   var auth=new AuthContext();auth.authenticationType="BASIC";auth.username="user";auth.password="pass";
   List<ApiTestCase> rows=new ArrayList<>();
   rows.add(api("1 PASS", "GET",base+"/good"));
   rows.add(api("2 HTTP 500 fails", "GET",base+"/fail"));
   ApiTestCase missing=api("3 Missing attachment fails","POST",base+"/create");missing.bodyType="BINARY";missing.filePath="this_file_is_missing.zz";rows.add(missing);
   ApiTestCase goodExtract=api("4 POST creates objectId", "POST",base+"/create");goodExtract.globalvariable="objectId";goodExtract.globalvariablejsonxmlpath="$.objectId";goodExtract.xmlorjson="JSON";rows.add(goodExtract);
   ApiTestCase badExtract=api("5 Var extraction fails","POST",base+"/missingId");badExtract.globalvariable="objectId";badExtract.globalvariablejsonxmlpath="$.objectId";badExtract.xmlorjson="JSON";rows.add(badExtract);
   rows.add(api("6 Dependent GET skipped", "GET",base+"/download/[[objectId]]"));
   rows.add(api("7 PASS after failed dependency", "GET",base+"/good"));
   ApiTestCase malformed=api("8 Wrong expected status fails","GET",base+"/good");malformed.expectedStatus="garbage";rows.add(malformed);
   rows.add(api("9 PASS at end", "GET",base+"/good"));
   ExcelReader.tests=rows;
   ApiTests.run(ctx,auth,rec);
   if (rec.totalTests.get()!=9 || rec.executedTests.get()!=9 || rec.passedTests.get()!=4 || rec.failedTests.get()!=4 || rec.skippedTests.get()!=1)
    throw new AssertionError("Bad counts: " + rec.executedTests + " "+rec.passedTests+" "+rec.failedTests+" "+rec.skippedTests);
   var lines=Files.readAllLines(Path.of(ctx.csvPath));
   if (lines.size()!=10) throw new AssertionError("CSV should contain header + 9 rows: "+lines.size());
   if (!lines.get(6).contains("SKIPPED"))throw new AssertionError("Missing skip record: "+lines.get(6));
   if (!lines.get(9).contains("PASS"))throw new AssertionError("After-fail API did not execute: "+lines.get(9));
   String html=Files.readString(Path.of(ctx.htmlPath));
   if(!html.contains("Dependent GET skipped") || !html.contains("Wrong expected status fails"))throw new AssertionError("HTML missing cases");
   System.out.println("PASS: 8 Excel API rows; PASS=3, FAIL=4, SKIPPED=1, continue after errors, report all rows");
   // Run 2: independent execution after first has completed.
   var ctx2=new TestRunContext();ctx2.runId="RTEST2";ctx2.runDir=tmp.resolve("run2").toString();
   Files.createDirectories(Path.of(ctx2.runDir));ctx2.excelPath="stub";
   ctx2.csvPath=Path.of(ctx2.runDir,"test.csv").toString();ctx2.htmlPath=Path.of(ctx2.runDir,"test.html").toString();ctx2.extentPath=Path.of(ctx2.runDir,"extent.html").toString();
   var rec2=new RunRecord(ctx2,"owner2");ExcelReader.tests=List.of(api("Next user succeeds","GET",base+"/good"));
   ApiTests.run(ctx2,auth,rec2);
   if(rec2.passedTests.get()!=1 || rec2.failedTests.get()!=0) throw new AssertionError("Next user failed");
   System.out.println("PASS: Next user execution operates in its own context");
  } finally {server.stop(0);}
 }
}
