package com.fasterxml.jackson.databind;
import java.util.*;
public class ObjectMapper {
  @SuppressWarnings("unchecked")
  public <T> T readValue(String s, Class<T> clazz) {
    Map<String,Object> m = new HashMap<>();
    java.util.regex.Matcher re = java.util.regex.Pattern.compile("\\\"([^\\\"]+)\\\"\\s*:\\s*(?:\\\"([^\\\"]*)\\\"|([0-9]+))").matcher(s);
    while(re.find()) m.put(re.group(1), re.group(2)!=null?re.group(2):Long.parseLong(re.group(3)));
    return (T)m;
  }
}
