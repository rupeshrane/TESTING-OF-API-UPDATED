package com.aventstack.extentreports.reporter;
public class ExtentSparkReporter {public ExtentSparkReporter(String s){} }
