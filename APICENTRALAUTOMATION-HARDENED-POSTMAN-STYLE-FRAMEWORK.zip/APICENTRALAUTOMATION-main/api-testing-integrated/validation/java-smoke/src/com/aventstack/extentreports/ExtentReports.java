package com.aventstack.extentreports;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;
public class ExtentReports { public void attachReporter(ExtentSparkReporter a){} public ExtentTest createTest(String s){return new ExtentTest();} public void flush(){} }
