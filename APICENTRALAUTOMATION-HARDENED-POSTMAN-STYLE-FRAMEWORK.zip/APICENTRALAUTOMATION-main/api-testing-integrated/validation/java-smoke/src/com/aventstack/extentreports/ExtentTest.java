package com.aventstack.extentreports;
public class ExtentTest { public ExtentTest skip(String s){return this;}public ExtentTest info(String a) {return this;} public ExtentTest pass(String s){return this;} public ExtentTest fail(String s){return this;}}
