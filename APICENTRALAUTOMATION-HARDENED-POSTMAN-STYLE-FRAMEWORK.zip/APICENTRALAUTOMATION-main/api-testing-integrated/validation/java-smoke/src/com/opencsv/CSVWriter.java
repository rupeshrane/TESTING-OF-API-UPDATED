package com.opencsv;
import java.io.*;
public class CSVWriter implements AutoCloseable { private Writer w;public CSVWriter(Writer w){this.w=w;}public void writeNext(String[] s){try{for(String x:s)w.write((x==null?"":x.replace("\n"," "))+",");w.write("\n");}catch(IOException e){throw new RuntimeException(e);}}public void close() throws IOException {w.close();} }
