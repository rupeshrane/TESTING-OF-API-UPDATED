import com.sun.net.httpserver.HttpServer;
import model.AuthContext;
import org.sodales.OAuth2Client;
import java.net.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicInteger;

public class OAuthCancellationSmoke {
 public static void main(String[] args)throws Exception {
  HttpServer server=HttpServer.create(new InetSocketAddress("127.0.0.1",0),0);
  AtomicInteger attempts=new AtomicInteger();
  server.createContext("/slow",x->{attempts.incrementAndGet();try{Thread.sleep(2500);}catch(InterruptedException ignored){};byte[] b="unavailable".getBytes();try{x.sendResponseHeaders(503,b.length);x.getResponseBody().write(b);}catch(Exception ignored){} finally{x.close();}});
  server.setExecutor(Executors.newCachedThreadPool());server.start();
  var ctx=new AuthContext();ctx.tokenUrl="http://127.0.0.1:"+server.getAddress().getPort()+"/slow";ctx.clientId="id";ctx.clientSecret="secret";ctx.grantType="client_credentials";
  Thread worker=new Thread(()->{try{OAuth2Client.getAccessToken(ctx);throw new AssertionError("should cancel");}catch(InterruptedException|CancellationException e){}catch(Exception e){throw new AssertionError("wrong exit "+e);}});
  long started=System.nanoTime();worker.start();Thread.sleep(100);worker.interrupt();worker.join(2500);
  if(worker.isAlive())throw new RuntimeException("OAuth did not cancel promptly");
  if(attempts.get()>1)throw new RuntimeException("OAuth kept retrying after cancel");
  System.out.println("PASS - OAuth request cancellation interrupts promptly and prevents further retries in "+((System.nanoTime()-started)/1_000_000)+"ms");
  server.stop(0);System.exit(0);
 }
}
