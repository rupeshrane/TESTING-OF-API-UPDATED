import com.sun.net.httpserver.HttpServer;
import com.sun.net.httpserver.HttpExchange;
import model.*;
import runner.ApiTestRunner;
import org.sodales.GlobalVariableHandler;
import java.net.*;
import java.nio.file.*;
import java.nio.charset.StandardCharsets;
import java.util.*;

public class ExtendedApiSmoke {
 static void send(HttpExchange e, int code, String body) throws java.io.IOException {
  byte[] bytes=body.getBytes(StandardCharsets.UTF_8);
  e.sendResponseHeaders(code, bytes.length);
  try(var out=e.getResponseBody()){out.write(bytes);}
 }
 static ApiTestCase row(String name,String method,String url,String expected) {
   ApiTestCase t=new ApiTestCase(); t.testName=name;t.method=method;t.url=url;t.bodyType="NONE";
   t.expectedStatus=expected;t.expectedResponse="NA";return t;
 }
 static TestRunContext context(Path base,String name)throws Exception {
    Path p=base.resolve(name);Files.createDirectories(p);TestRunContext c=new TestRunContext();c.runId=name;
    c.runDir=p.toString();c.csvPath=p.resolve("out.csv").toString();
    c.htmlPath=p.resolve("out.html").toString();c.extentPath=p.resolve("extent.html").toString();return c;
 }
 static void pass(ApiTestRunner.Outcome actual, String desc){if(actual != ApiTestRunner.Outcome.PASS)throw new AssertionError(desc+" returned "+actual);}
 public static void main(String[] args)throws Exception{
    HttpServer s=HttpServer.create(new InetSocketAddress("127.0.0.1",0),0);
    s.createContext("/auth",e->{String a=e.getRequestHeaders().getFirst("Authorization");send(e,200,a==null?"no-auth":a);});
    s.createContext("/key",e->{String a=e.getRequestHeaders().getFirst("X-API-Key");send(e,200,a==null?"no-key":a);});
    s.createContext("/form",e->{String b=new String(e.getRequestBody().readAllBytes(),StandardCharsets.UTF_8);
      String ct=e.getRequestHeaders().getFirst("Content-Type");
      send(e,200,"application/x-www-form-urlencoded".equals(ct)?b:"wrong-content-type:"+ct);});
    s.createContext("/seed",e->{e.getResponseHeaders().add("Set-Cookie","qa-session=only-run-A; Path=/");send(e,200,"ok");});
    s.createContext("/cookie",e->{String b=e.getRequestHeaders().getFirst("Cookie");send(e,200,b==null?"no-cookie":b);});
    s.createContext("/head",e->{e.sendResponseHeaders(204,-1);e.close();});
    s.createContext("/option",e->{send(e,204,"");});
    s.createContext("/status",e->{send(e,404,"absent");});
    s.start();
    try {
       String base="http://127.0.0.1:"+s.getAddress().getPort(); Path dir=Files.createTempDirectory("qa-extended-");
       TestRunContext c1=context(dir,"A"),c2=context(dir,"B");var vars=new GlobalVariableHandler();
       var none=new AuthContext();none.authenticationType="NONE";
       ApiTestCase manual=row("manual auth","GET",base+"/auth","200");manual.headers="Authorization: Custom demo-token";manual.expectedResponse="Custom demo-token";
       pass(ApiTestRunner.run(manual,c1,vars,none,null),"manual auth");
       var bearer=new AuthContext();bearer.authenticationType="BEARER";bearer.bearerToken="test-secret-987";
       ApiTestCase b=row("bearer","GET",base+"/auth","2xx");b.expectedResponse="Bearer test-secret-987";
       pass(ApiTestRunner.run(b,c1,vars,bearer,null),"bearer");
       var key=new AuthContext();key.authenticationType="API_KEY";key.apiKeyName="X-API-Key";key.apiKeyValue="abcdef";
       ApiTestCase k=row("key","GET",base+"/key","");k.expectedResponse="abcdef";
       pass(ApiTestRunner.run(k,c1,vars,key,null),"apikey");
       ApiTestCase encoded=row("form urlencoded","POST",base+"/form","200");encoded.bodyType="URLENCODED";encoded.formData="first name:Tom Jones; city:New York";encoded.expectedResponse="first+name=Tom+Jones&city=New+York";
       pass(ApiTestRunner.run(encoded,c1,vars,none,null),"form urlencoded");
       pass(ApiTestRunner.run(row("seed cookie","GET",base+"/seed","200"),c1,vars,none,null),"cookie seed");
       ApiTestCase hasCookie=row("check cookie A","GET",base+"/cookie","200");hasCookie.expectedResponse="qa-session=only-run-A";
       pass(ApiTestRunner.run(hasCookie,c1,vars,none,null),"cookie run A");
       ApiTestCase noCookie=row("check cookie B","GET",base+"/cookie","200");noCookie.expectedResponse="no-cookie";
       pass(ApiTestRunner.run(noCookie,c2,new GlobalVariableHandler(),none,null),"cookie run B isolation");
       pass(ApiTestRunner.run(row("head","HEAD",base+"/head","204"),c1,vars,none,null),"HEAD");
       pass(ApiTestRunner.run(row("options","OPTIONS",base+"/option","2xx"),c1,vars,none,null),"OPTIONS");
       pass(ApiTestRunner.run(row("range","GET",base+"/status","400-499"),c1,vars,none,null),"range assertion");
       String csv=Files.readString(Path.of(c1.csvPath));
       if(csv.contains("Custom demo-token"))throw new AssertionError("manual Authorization leaked in report");
       System.out.println("PASS: no-auth / manual auth / bearer / API key / form urlencoded / cookie isolation / HEAD / OPTIONS / status ranges / auth redaction");
    }finally{s.stop(0);}
 }
}
