import com.sun.net.httpserver.HttpServer;
import model.*;
import runner.ApiTestRunner;
import org.sodales.*;
import java.net.*;
import java.nio.file.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicInteger;

public class ApiIntegrationSmoke {
 public static void main(String[] args) throws Exception {
   var server = HttpServer.create(new InetSocketAddress("127.0.0.1",0),0);
   var tokenCount = new AtomicInteger();
   var badCount = new AtomicInteger();
   var retryCount = new AtomicInteger();
   byte[] binary = new byte[16384];new Random(25).nextBytes(binary);
   server.createContext("/token", x->{tokenCount.incrementAndGet();reply(x,200,"application/json","{\"access_token\":\"xyz\",\"expires_in\":10}".getBytes(StandardCharsets.UTF_8));});
   server.createContext("/tokenBad", x->{badCount.incrementAndGet();reply(x,401,"application/json","{\"error\":\"invalid_client\"}".getBytes(StandardCharsets.UTF_8));});
   server.createContext("/tokenRetry", x->{retryCount.incrementAndGet();reply(x,503,"text/plain","down".getBytes(StandardCharsets.UTF_8));});
   server.createContext("/files", x -> {
     if(x.getRequestMethod().equals("POST")) {
       byte[] multipart = x.getRequestBody().readAllBytes();
       String ct = x.getRequestHeaders().getFirst("Content-Type");
       if(ct==null || !ct.contains("multipart/form-data") || !new String(multipart,StandardCharsets.ISO_8859_1).contains("random.zzz"))
          reply(x,400,"text/plain","bad multipart".getBytes(StandardCharsets.UTF_8));
       else reply(x,200,"application/json","{\"objectId\":\"OBJ-77\"}".getBytes(StandardCharsets.UTF_8));
     } else if(x.getRequestURI().getPath().equals("/files/OBJ-77")) {
       x.getResponseHeaders().add("Content-Disposition", "attachment; filename=out.bin");
       reply(x,200,"application/octet-stream",binary);
     } else reply(x,500,"text/plain","The MPL ID for the Failed message is TEST-123".getBytes(StandardCharsets.UTF_8));
   });
   server.createContext("/asText",x->reply(x,200,"text/plain",binary));
   server.createContext("/mpl",x->reply(x,500,"text/plain","The MPL ID for the Failed message is TEST-123".getBytes(StandardCharsets.UTF_8)));
   server.start();
   try {
      String base="http://127.0.0.1:"+server.getAddress().getPort();
      Path dir=Files.createTempDirectory("apitest-");
      Path file=dir.resolve("random.zzz");Files.write(file,binary);
      TestRunContext ctx=new TestRunContext();ctx.runId="T-1";ctx.runDir=dir.toString();ctx.csvPath=dir.resolve("r.csv").toString();ctx.htmlPath=dir.resolve("r.html").toString();ctx.extentPath=dir.resolve("extent.html").toString();
      var auth=new AuthContext();auth.authenticationType="OAUTH2";auth.grantType="client_credentials";auth.clientId="client";auth.clientSecret="secret";auth.tokenUrl=base+"/token";
      GlobalVariableHandler gv=new GlobalVariableHandler();
      ApiTestCase post=new ApiTestCase();post.testName="Post file";post.method="POST";post.bodyType="FORM_DATA";post.formData="documentType:general";post.filePath="file=@"+file;post.url=base+"/files";post.expectedStatus="200";post.expectedResponse="NA";post.globalvariable="objectId";post.globalvariablejsonxmlpath="$.objectId";post.xmlorjson="json";
      ApiTestRunner.run(post,ctx,gv,auth,null);
      ApiTestCase get=new ApiTestCase();get.testName="Get attachment";get.method="GET";get.bodyType="NONE";get.url=base+"/files/[[objectId]]";get.expectedStatus="200";get.expectedResponse="NA";
      ApiTestRunner.run(get,ctx,gv,auth,null);
      var downloads=Files.list(dir.resolve("downloads")).toList();
      if(downloads.size()!=1 || !Arrays.equals(Files.readAllBytes(downloads.get(0)),binary))throw new RuntimeException("Binary download failed");
      if(tokenCount.get()!=1) throw new RuntimeException("Short-expiry token was reacquired per API unexpectedly: "+tokenCount.get());
      ApiTestCase forced=new ApiTestCase();forced.testName="Forced file";forced.method="GET";forced.url=base+"/asText";forced.expectedStatus="200";forced.expectedResponse="NA";forced.responseType="FILE";
      ApiTestRunner.run(forced,ctx,gv,auth,null);
      if(Files.list(dir.resolve("downloads")).count()!=2)throw new RuntimeException("Explicit FILE option failed");
      ApiTestCase upstream=new ApiTestCase();upstream.testName="Upstream MPL failure";upstream.method="GET";upstream.url=base+"/mpl";upstream.expectedStatus="200";upstream.expectedResponse="NA";upstream.responseType="FILE";
      ApiTestRunner.run(upstream,ctx,gv,auth,null);
      if(Files.list(dir.resolve("downloads")).count()!=2)throw new RuntimeException("Erroneously saved MPL error as an attachment");
      var badAuth=new AuthContext();badAuth.grantType="client_credentials";badAuth.clientId="c";badAuth.clientSecret="s";badAuth.tokenUrl=base+"/tokenBad";
      try{OAuth2Client.getAccessToken(badAuth);throw new RuntimeException("Bad credentials incorrectly accepted");}catch(java.io.IOException e){}
      if(badCount.get()!=1)throw new RuntimeException("401 request retried: "+badCount);
      badAuth.tokenUrl=base+"/tokenRetry";
      try{OAuth2Client.getAccessToken(badAuth);throw new RuntimeException("503 token incorrectly accepted");}catch(java.io.IOException e){}
      if(retryCount.get()!=3)throw new RuntimeException("503 token not retried exactly 3 attempts: "+retryCount);
      System.out.println("PASS - multipart POST / objectId / binary GET / text file override / MPL 500 / OAuth 401 nonretry / OAuth 503 bounded retry");
   } finally{server.stop(0);}
 }
 static void reply(com.sun.net.httpserver.HttpExchange x,int code,String type,byte[] body)throws java.io.IOException {x.getResponseHeaders().add("Content-Type",type);x.sendResponseHeaders(code,body.length);try(var out=x.getResponseBody()){out.write(body);}}
}
