@echo off
setlocal
cd /d "%~dp0"
if not exist classes mkdir classes
if exist sources.list del sources.list
for /r src %%F in (*.java) do echo "%%F">> sources.list
javac -encoding UTF-8 -d classes @sources.list
if errorlevel 1 (echo Java compilation failed & exit /b 1)
for %%T in (ApiIntegrationSmoke IsolationIntegrationSmoke OAuthCancellationSmoke ExtendedApiSmoke) do (
 echo ==== %%T ====
 java -cp classes %%T
 if errorlevel 1 (echo Test %%T FAILED & exit /b 1)
)
echo All local mock API smoke tests PASSED
