# QA Portal API Framework — hardened release notes

**Base:** `APICENTRALAUTOMATION-FIFO-PER-API-FAILURE-CONTINUE-FINAL.zip`  
**Purpose:** Extend the existing Excel-driven API testing portal with common Postman-style HTTP request capabilities and reduce failure modes. **This is not a complete replacement for Postman or a claim of zero bugs.**

## Previous behavior retained

- Single active Excel test execution on the server; FIFO waiting queue (capacity controlled by `QA_RUN_QUEUE_CAPACITY`, default 100). No concurrent test suites.
- Cancel run and preserve report rows that finished before cancellation; next queued run starts only when previous worker has exited and completed its cleanup. Do not restart the JVM on Cancel.
- Bounded OAuth client-credentials retry, cancellation and timeout.
- POST multipart upload, per-run global variable capture, dependent GET attachment download and `ResponseType=FILE` option.
- Continue after independent API test case failures; mark missing dependent variables SKIPPED; reports include PASS/FAIL/SKIPPED.
- Strict session/run-access-token checks for status, logs, cancellation and reports (anonymous browser sessions, **not proof of user identity**).
- Existing ReportPortal manager and existing UI Metrics (date range, charts and server logs) **not modified**.
- URL whitespace escaping, server-side Excel reader, and CSV/HTML/Extent reporting retained.

## Enhancements in this release

| Feature | Usage |
|---|---|
| No authentication | Choose **No Auth** in the UI; use a manual `Authorization` header per row if needed |
| Basic authentication | Existing UI option, unchanged |
| Bearer token | Choose **Bearer Token** in the UI |
| API key (request header) | Choose **API Key** and enter the header name and value |
| OAuth 2.0 client credentials | Existing bounded token acquisition and 401 refresh (only this OAuth grant is implemented) |
| Separate cookie jar per run | Cookies set by earlier APIs are sent to later APIs in the same run, not to other users' runs |
| HTTP verbs | GET, POST, PUT, PATCH, DELETE, **HEAD, OPTIONS** |
| `BodyType=URLENCODED` | Encode `FormData` pairs (`key:value;next:value` or `key=value`) as `application/x-www-form-urlencoded` |
| `BodyType=RAW`, `BINARY`, `FORM_DATA`, `NONE` | Existing behavior preserved; binary and multipart attachments stream from server-accessible files |
| `ExpectedStatus` | Exact code `200`; list `200,201`; range `200-204`; family `2xx` / `4xx`; `ANY`; empty defaults to any 2xx |
| `TimeoutSeconds` | Optional per-API Excel column, 5–1800 seconds; overrides `QA_API_TIMEOUT_SECONDS` |
| Response safeguard | Unexpectedly large text response fails its own row clearly instead of reading unbounded response into RAM; `ResponseType=FILE` streams binary payloads |
| Report ZIPs | Streamed from server to browser rather than assembled in one huge `byte[]` |
| Secret redaction | Credential fields and sensitive headers are masked in generated report diagnostics, including common echoed token values |
| Finished-run retention | Expired run records and in-memory run logs are evicted after 24 hours; queued/running records remain live |

## Optional Excel fields

Existing required/recognized template columns are unchanged. Newly recognized optional columns:

- `TimeoutSeconds`: e.g. `600` for a slow SAP POST. Default falls back to `QA_API_TIMEOUT_SECONDS` (120 s) and may be set up to 1800 s.
- `ResponseType`: `FILE` to force successful GET response download, even if upstream sends `text/plain`.

Examples:

| TestName | Method | URL | BodyType | FormData | ExpectedStatus | ExpectedResponseContains | TimeoutSeconds |
|---|---|---|---|---|---|---|---|
| Create file | POST | `https://api.example.com/files` | FORM_DATA | `category:invoice` | `201` | `NA` | `600` |
| Get file | GET | `https://api.example.com/files/[[objectId]]` | NONE | | `2xx` | `NA` | `300` |
| Check missing | HEAD | `https://api.example.com/unknown` | NONE | | `404` | `NA` | `30` |

`GlobalVariable`, `GlobalVariableJsonorXMLPath`, and `JsonorXML` continue to control extraction of `objectId` from successful POST responses; the downstream request must have its URL variable resolved. If extraction fails, that dependent row is SKIPPED and unrelated rows continue.

## Windows Server deployment

1. **Back up** your deployed backend and frontend, ReportPortal configuration, original pages and all active report files.
2. Replace/merge modified Java source files and frontend `ApiTestingPage.jsx`; **deploy backend and frontend together** to expose the new authentication choices.
3. Restore your five original feature page components if they exist outside the supplied base archive. The supplied baseline contains clearly marked placeholders for `TestcaseGenerator`, `RTMGenerator`, `Plugin`, `Converter`, and `PayloadEncryption`.
4. Ensure the frontend's `VITE_API_BASE_URL` points to an externally reachable backend origin at **Vite build time**. `localhost` refers to *each user's computer*, not the Windows Server. For HTTPS production, serve the API through HTTPS/reverse proxy as well.
5. Start the backend with Java 17 or later and restart the frontend serving process after its production build. Preserve your current `reportportal.properties`/Docker endpoint.
6. Test one normal run, one failed API row then continuing rows, one cancellation, two browsers in FIFO, one OAuth failure, one POST file upload → variable → binary GET, a large report download and UI Metrics.
7. Monitor CPU/RAM/disk/HTTP logs. The ZIP was **not** deployed against your live SAP/Windows Server.

### Suggested Windows environment settings

```powershell
QA_API_TIMEOUT_SECONDS=300
QA_OAUTH_TIMEOUT_SECONDS=20
QA_OAUTH_MAX_ATTEMPTS=3
QA_RUN_QUEUE_CAPACITY=100
QA_MAX_TEXT_RESPONSE_MB=20
```

`TimeoutSeconds` can extend individual APIs to 1800 seconds. OAuth timeout is separate from API timeout. Unresponsive upstream APIs may continue processing remotely even after the portal cancels an HTTP call. **Never blindly retry non-idempotent POSTs**.

## Security and production readiness

- This portal accepts users who access a shared URL without a personal login. Anonymous run tokens protect access across browser sessions, but they **do not authenticate a human user**. Use your organization's SSO/Windows Integrated Authentication if you require verified user identities.
- The API testing portal can make arbitrary HTTP calls to destinations reachable from the Windows Server. Before opening it to untrusted networks, restrict access (VPN/SSO/firewall) and ideally allowlist API hosts to prevent server-side request forgery.
- Ensure HTTPS in production, especially for bearer credentials, API keys and session tokens. Revisit `@CrossOrigin("*")` to limit allowed origins.
- CSV/HTML reports may include application response data. Protect report files and do not include secrets in request bodies or URLs. Credential masking is best effort, not general-purpose data-loss prevention.
- Current FIFO and in-memory ownership state **do not survive Spring Boot JVM restarts**. Physical server restart / crash recovery requires a separate durable queue/secret-storage design. Do not promise queue recovery from this release.

## Features NOT implemented (important)

Postman covers a substantially broader feature set than this Excel-driven HTTP runner. **The following are not implemented or not verified here:** collection import/export and visual collection editor; nested collections/workspaces/environments with scope semantics; pre-request/post-response JavaScript sandbox and full Postman test API; OpenAPI import; full OAuth 2.0 grant support such as authorization-code/PKCE and device flow; AWS Signature/Hawk/Digest; GraphQL editor/subscriptions; WebSocket, gRPC, MQTT and SOAP-specific tooling; mutual TLS/client certificate management; proxy/certificate UI; mock servers; collaboration/cloud sync; monitors/scheduled runs; CLI and CI integrations; complete schema assertions; a full request-by-request manual Send console; database-backed or crash-durable run queue. Some GraphQL and SOAP requests may work as ordinary HTTP RAW payloads but there is no protocol-specific UI.

No application can guarantee every arbitrary API will never return errors: upstream auth, authorization, SAP/CPI MPL failures, network access, certificate configuration and server permissions are outside the portal's control.

## Validation in this package

Local JDK-only **mock regression checks** were passed for:

- Multipart POST → capture `objectId` → binary GET saved in the run downloads.
- `ResponseType=FILE`, upstream MPL 500 error classification, bounded OAuth retries and interruption.
- Per-row PASS/FAIL/SKIPPED, later independent rows continue, and the next run can execute.
- No Auth/manual `Authorization`, Bearer, API-key headers, URL-encoded forms, HEAD/OPTIONS and expected-status patterns.
- Per-run cookie isolation and common authorization header/echo redaction in reports.

These are isolated mock-service tests built with Java standard-library HTTP server and simplified stubs for unrelated libraries. They do not replace Maven integration testing, React/Vite production build or acceptance testing against the live Windows Server. Maven and complete npm dependencies were unavailable in the current environment.

## Merge manifest

The merge patch updates only these existing files:

- `backend/src/main/java/model/AuthContext.java`
- `backend/src/main/java/model/ApiTestCase.java`
- `backend/src/main/java/model/TestRunContext.java`
- `backend/src/main/java/reader/ExcelReader.java`
- `backend/src/main/java/org/sodales/ApiController.java`
- `backend/src/main/java/org/sodales/RunManager.java`
- `backend/src/main/java/runner/ApiTestRunner.java`
- `frontend/src/pages/ApiTestingPage.jsx`

This guide is new. The patch should be merged **onto the exact preceding `FIFO-PER-API-FAILURE-CONTINUE-FINAL` release** to avoid overwriting later local changes.
