# Per-API failure isolation — update guide

Base project: `APICENTRALAUTOMATION-FIFO-OAUTH-MULTIPART-GET-FIXED.zip`

## Requested behavior

- One active user run at a time. The original FIFO queue, cancellation, and next-user handoff are unchanged.
- One failed API row must not abort the entire Excel test suite. HTTP 400/500 assertions, OAuth failures, request timeouts, missing upload files, invalid spreadsheet row settings, and global variable extraction exceptions become row-level FAIL entries.
- An API whose URL still references `[[objectId]]`, `${objectId}`, or `{{objectId}}` after variable replacement is SKIPPED, with the unresolved variable documented; independent later API rows continue.
- A new row that writes a global variable first clears any old value of that variable. A failed POST cannot accidentally feed an earlier object ID into a later dependent GET.
- After the final Excel row, finished reports remain downloadable and the FIFO worker is released for the next user.
- User cancellation still stops the remaining rows; fatal run-level failures (e.g. unreadable workbook, unrecoverable report storage) are not suppressed.

## Changed backend files (only these six)

- `src/main/java/runner/ApiTestRunner.java` — per-row PASS/FAIL/SKIPPED results and report writing, post-response extraction failure handling, missing-variable detection, cancellation preserved.
- `src/main/java/org/sodales/ApiTests.java` — continue after row-level failure, count results and keep cancellation terminal.
- `src/main/java/org/sodales/GlobalVariableHandler.java` — invalidate stale variables when the generating row is retried.
- `src/main/java/model/RunRecord.java` — add passed/failed/skipped counters.
- `src/main/java/org/sodales/ApiController.java` — expose counts via the existing run status response without changing routes or security.
- `src/main/java/org/sodales/RunManager.java` — clarify final execution log as completed processing, not "all APIs passed".

No frontend files, UI Metrics, OAuth implementation, ReportPortalManager, executor queue, or attachment transport were changed.

## Example

| Excel API | Outcome |
|---|---|
| 1–20 | PASS |
| 21: token endpoint rejects request | FAIL, logged with reason |
| 22–50 (independent) | Keep running |
| 51: attachment path missing | FAIL, logged with reason |
| 52: GET depends on missing objectId | SKIPPED |
| 53–100 (independent) | Keep running |

Status endpoint includes `executedTests`, `totalTests`, `passedTests`, `failedTests`, `skippedTests`. `COMPLETED` means the spreadsheet has finished processing, **not** that every API passed. Downloaded CSV/HTML/Extent reports include row-level outcomes. ReportPortal test items are finished as PASSED/FAILED/SKIPPED where available.

## Deployment and merge

1. Back up the Windows Server deployment.
2. Stop the Spring Boot application and save/download any in-memory run reports you need.
3. Apply only the six Java source files above to the matching FIFO+OAuth+multipart baseline; if your deployed code has subsequent custom changes, reconcile differences rather than blindly overwriting.
4. Build with `mvn clean package` using JDK 17 or compatible JDK on your server, then restart the backend.
5. Run tests: passing API, HTTP 500, OAuth invalid credentials, missing upload, POST with missing `objectId`, subsequent dependent GET, subsequent independent GET, and user cancellation with another run waiting.
6. Confirm current UI Metrics, ReportPortal launch finishing and report downloads behave unchanged.

## Validation and limitations

A local Java compile with test doubles and local HTTP mock integration test passed for 9 cases (4 PASS, 4 FAIL, 1 SKIPPED) and an independent subsequent user run. A separate OAuth interruption smoke test also passed. This is not a complete Maven/Spring build or a test against your live Windows Server, SAP/CPI, or ReportPortal.

The FIFO queue remains **in-memory**. A real JVM/Windows Server restart still loses queued runs; this change does not add restart persistence. Normal cancellation does **not** restart the server.
