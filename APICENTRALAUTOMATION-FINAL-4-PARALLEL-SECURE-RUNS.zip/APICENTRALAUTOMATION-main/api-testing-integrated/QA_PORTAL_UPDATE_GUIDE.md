# QA Portal - Parallel Runs, Cancel + Partial Reports, Attachments, UI Metrics

Updated using `APICENTRALAUTOMATION-main (3).zip` as the base. No database is required.

## Updated behavior

| Need | Implementation |
|------|----------------|
| Run multiple users concurrently | Spring Boot has a configurable fixed parallel run pool; default **4** simultaneous independent runs, no queue. The 5th submission returns **HTTP 429** instead of waiting FIFO. Each run has its own folder, authentication context, global variables, report and logs. |
| Cancel run | UI button **Cancel Run & Save Results** calls `POST /runs/{runId}/cancel` with its secret `X-Run-Cancel-Token`, returned only with the original run creation response. A cancelled run ends with `CANCELLED`. HTTP requests are interrupted where supported; previous report rows are retained. |
| Partial report | `GET /runs/{runId}/report` downloads completed results even during execution (once results exist), when **CANCELLED**, when **FAILED**, or **COMPLETED**. The ZIP contains `RUN_SUMMARY.txt`, any CSV/HTML/Extent reports available, and downloaded GET files in `downloads/`. The UI auto-downloads results after cancelling, and exposes **Download Current Results** while records exist. |
| Spaces in API URLs | Whitespace is percent-encoded; existing URL percent-escapes are preserved. Variable values injected into URLs use URL-component encoding. |
| POST attachment -> GET download | Multipart `FORM_DATA` or `BINARY` upload can use **FilePath**, Excel `FormData` entries such as `document:@file.pdf`, and/or additional attachments selected in the UI. Headers use the generated multipart boundary. Extract a POST response value using `GlobalVariableJsonorXMLPath`, store it in `GlobalVariable`, then use the placeholder in the next GET URL. GET binary attachments are saved in the per-run `downloads/` directory and included in the report ZIP. |
| Run ownership | Anonymous browser sessions are issued by the backend and stored per browser tab. Each run has a separate access token; status, logs, report downloads and cancellation require BOTH the issuing browser session and the matching run access token. Cancel still requires its separate cancellation token. No database or login required. This is session isolation, not verified user identity. |
| Metrics | Tracks page/tab visits, session IDs and active portal time. Creates server-side daily JSONL raw logs and daily plaintext summaries. Restricted admin view at `/ui-metrics-admin` works only with a server-held admin key. Normal users are not shown a Metrics tab or given access to summaries. |

## Start the project

Backend: from `api-testing-integrated/backend`, run `mvn spring-boot:run` on Java 17+ with Maven installed. Port: 9090.

Frontend: from `api-testing-integrated/frontend`, run `npm install` and `npm run dev` with a supported Node version. `VITE_API_BASE_URL` defaults to `http://localhost:9090`.

### Server options (environment variables)

- `QA_MAX_CONCURRENT_RUNS=4` – default 4, accepted range 1–32, limited by your server's CPU, memory, and remote API capacity. **Multiple simultaneous runs, not unlimited parallelism.** Requests beyond capacity get a 429 response. If users are still seeing FIFO, check your deployment uses this new backend and whether a load balancer/reverse proxy is limiting requests.
- `QA_UI_METRICS_DIR=logs/ui-metrics` – relative to backend working directory, or an absolute path.
- `QA_UI_METRICS_ADMIN_KEY=<long-random-private-key>` – **required** to enable viewing metrics from the restricted UI. Use at least 16 characters, store it only on the server, never in React source or an unprotected `.env` file that Vite publishes.
- Retention defaults to 90 days in `backend/src/main/resources/application.yml`.

Open **`/ui-metrics-admin`** manually if you administer the server. It is intentionally not in the public navigation. Enter the admin key and select a date; the backend rejects requests without the correct key. Without a configured admin key, all metrics remain available only as files on the server.

### Excel columns supported

Header-driven reading accepts 11-column legacy sheets and 14-column sheets with:

`TestName, Method, URL, Headers, BodyType, Payload, FormData, FilePath, ExpectedStatus, ExpectedResponseContains, Skip?, GlobalVariableJsonorXMLPath, GlobalVariable, JsonorXML`

For a multipart + chained download:

1. POST row: `Method=POST`, `BodyType=FORM_DATA`, `FilePath=document=@C:\\files\\sample.pdf` (or FormData contains `document:@C:\\files\\sample.pdf`). If the backend cannot access the Windows path, select **sample.pdf** under **Additional Attachments** in the browser. The backend matches the selected file by basename; do not upload two files with the same basename.
2. POST row variable columns: `GlobalVariableJsonorXMLPath=$.id`, `GlobalVariable=[[attachmentId]]`, `JsonorXML=json`. Numeric and string JSON values are both supported. Use the actual JSON path returned by *your* POST API.
3. GET row: `Method=GET`, `URL=https://your-server/api/download/[[attachmentId]]`, `BodyType=NONE`, `ExpectedStatus=200`, `ExpectedResponseContains=NA`. The GET's `Content-Disposition`/binary `Content-Type` makes the binary file downloadable into the run report ZIP.
4. Run the Excel file. The POST and GET execute sequentially **within one run** so its global variable is available. Different users' runs execute simultaneously.

**Path compatibility:** If attachment paths in the Excel template refer to files on the user's laptop while the backend runs on another server, Java cannot read those paths directly. Use **Additional Attachments** to transfer local files to the server for this run. Maximum uploaded file size defaults to 100 MB per file, 300 MB request total, configurable in `application.yml` and potentially at a reverse proxy.

**When a GET returns an MPL error:** The portal can pass through correct IDs, headers, auth and file bytes, but a remote SAP/integration error can still arise due to application-specific endpoints, authorization, message status or ID format. Compare the **actual resolved URL**, HTTP response and authorization with Postman; the fix here does not guarantee a remote integration will accept every request.

### Run endpoints

- `POST /portal-session` -> creates/resumes an anonymous browser session and returns `{sessionToken}`; send it in `X-QA-Session` for every run operation.
- `POST /run-tests` with Excel, optional attachment files and auth parameters, header `X-QA-Session` -> `202 {runId, accessToken, cancelToken, status, ...}`. Only the initial response contains the secrets.
- `GET /runs/{runId}/status` + headers `X-QA-Session`, `X-Run-Access-Token` -> `QUEUED`, `RUNNING`, `CANCELLING`, `CANCELLED`, `COMPLETED` or `FAILED`, plus `executedTests`, `totalTests` and `partialReportAvailable`.
- `GET /runs/{runId}/logs` + headers `X-QA-Session`, `X-Run-Access-Token` -> logs scoped to the run.
- `POST /runs/{runId}/cancel` + headers `X-QA-Session`, `X-Run-Access-Token`, `X-Run-Cancel-Token` -> requested cancellation. The UI waits for terminal status before automatically downloading results.
- `GET /runs/{runId}/report` + headers `X-QA-Session`, `X-Run-Access-Token` -> ZIP of available results, including downloaded attachments. During active runs, download is a snapshot, not necessarily all rows.
- `POST /ui-metrics/event` -> write-only usage event endpoint.
- `GET /ui-metrics/admin/summary?date=YYYY-MM-DD` + `X-UI-Metrics-Admin-Key` -> restricted server summary; disabled unless a strong key is configured.

### Known limitations / important deployment notes

- **No login/verified identity service is included.** Backend-enforced anonymous browser sessions plus per-run capabilities now protect status, logs, downloads, and cancellation (403 for another browser session). A Run ID alone never authorizes access. This does not prove human identity: someone who can copy the browser session AND run access secrets can act as that browser. Restrict portal network access and use HTTPS; for user-level identity use SSO/Windows Integrated Authentication.
- **Cancellation is cooperative:** it interrupts the Java worker and HTTP call. A remote server may already have processed a POST before interruption. Cancellation does not roll back a remote API side effect. Completed results remain available until the run-directory cleanup.
- **Automatic browser downloads** require the user to keep the page open until cancellation finishes; after refresh in the same browser tab the UI restores the last run and its capabilities from `sessionStorage`. A Run ID alone is no longer enough. Closing the tab or clearing session storage loses access to that run, because there is no login-based recovery.
- **Run access tokens:** Keep `X-QA-Session`, `X-Run-Access-Token` and `X-Run-Cancel-Token` out of URLs and logs. The frontend uses `sessionStorage` (one browser tab); do not save tokens in Excel reports, share screenshots of network headers, or expose them through analytics. These server-memory sessions and run records do not survive backend restart. The access checks add minimal load.
- **HTTP 403 migration requirement:** Clients that previously called the run status, logs, report or cancel endpoints with only `runId` MUST now send valid session and run access headers. Update any scripts that call these endpoints.
- **Browser configuration:** Vite `VITE_API_BASE_URL` must point to the Windows Server backend or a reverse-proxied `/api` origin; browser-side `localhost:9090` means the visitor's machine, not the server. HTTPS on the public portal is strongly recommended. The existing `@CrossOrigin("*")` setting is kept for compatibility and should be restricted to your portal origin for production security.
- **Report persistence:** run files are temporary under `${java.io.tmpdir}/api-testing/<runId>`. Cleanup removes expired directories after approximately 24 hours when another run starts. There is no durable database storage. Maintain server access backups if required.
- **Missing files in uploaded ZIP:** This particular archive's `AppRoutes.jsx` imported 5 absent pages: `TestcaseGenerator`, `RTMGenerator`, `Plugin`, `Converter`, `PayloadEncryption`. To make the archive buildable, clearly labelled **placeholder components** are supplied for these pages; replace them with the original source files from your complete portal. The original ZIP did not include those implementations; this update does not re-create their previous functionality.
- **ReportPortalManager.java has been retained unchanged** to avoid accidental changes to its Docker integration configuration/credentials.

## Validation performed

- Passed Java compilation + smoke test for URI spaces and global-variable URL substitutions.
- Passed local Java HTTP integration test: multipart POST with server-staged attachment -> capture response `id` -> GET binary download with a space in the ID -> saved downloaded bytes -> CSV result generation.
- Passed local threaded worker test: two runs started simultaneously; cancelling the first did not interrupt the second.
- Passed React JSX/JS syntactic checks using the TypeScript parser (no errors).
- Run-ownership API checks (Java stubs) passed for own-session access (200), cross-session access (403) on status/logs/report/cancel, wrong or missing tokens (403) and no secret leakage in status. React JS/JSX parsing passed. Full Spring Boot/Maven and Vite builds were **not available**: Maven was not installed in the test container and `npm ci --offline` could not find all dependency packages. Run the builds and an end-to-end test against *your* actual server and authentication setup before production release.

## Windows Server starting configuration (4 vCPU / 16 GB RAM)

Default is **4** simultaneous test runs. The pool has no FIFO backlog: when all four worker threads are occupied, the next start request receives HTTP 429. This is a starting cap, not guaranteed safe capacity; monitor CPU, memory, timeouts, external API limits and file attachment sizes. A preexisting `QA_MAX_CONCURRENT_RUNS` environment variable overrides this setting; set it to `4` or remove it and restart the backend.
