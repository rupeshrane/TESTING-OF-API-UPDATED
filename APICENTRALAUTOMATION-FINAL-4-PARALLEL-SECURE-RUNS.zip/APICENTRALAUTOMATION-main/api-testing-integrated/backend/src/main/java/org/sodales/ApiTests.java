package org.sodales;

import model.ApiTestCase;
import model.AuthContext;
import model.RunRecord;
import model.TestRunContext;
import reader.ExcelReader;
import runner.ApiTestRunner;

import java.util.List;
import java.util.concurrent.CancellationException;

public class ApiTests {
    public static void run(TestRunContext context, AuthContext authContext, RunRecord record) {
        GlobalVariableHandler variableHandler = new GlobalVariableHandler(); // per-run only
        List<ApiTestCase> tests = ExcelReader.readTestCases(context.excelPath);
        record.totalTests.set((int) tests.stream().filter(t -> !"yes".equalsIgnoreCase(t.skip)).count());
        ReportPortalManager reportPortal = context.reportPortalEnabled
                ? new ReportPortalManager(context.projectName) : null;
        LogCollector.log("Run " + context.runId + " processing " + record.totalTests.get() + " tests.");
        try {
            checkCancelled(record);
            if (reportPortal != null) reportPortal.startLaunch();
            for (ApiTestCase test : tests) {
                checkCancelled(record);
                if ("yes".equalsIgnoreCase(test.skip)) {
                    LogCollector.log("Skipping " + test.testName);
                    continue;
                }
                LogCollector.log("Executing " + test.testName);
                ApiTestRunner.run(test, context, variableHandler, authContext, reportPortal);
                record.executedTests.incrementAndGet();
                checkCancelled(record);
            }
        } finally {
            // ReportPortal calls may need interrupt cleared so cancellation can still finalize a launch.
            if (reportPortal != null) {
                boolean interrupted = Thread.interrupted();
                try { reportPortal.finishLaunch(); }
                finally { if (interrupted) Thread.currentThread().interrupt(); }
            }
        }
        LogCollector.log("Finished " + record.executedTests.get() + " tests.");
    }
    private static void checkCancelled(RunRecord record) {
        if (record.cancelRequested.get() || Thread.currentThread().isInterrupted())
            throw new CancellationException("Run was cancelled");
    }
}
