package org.sodales;

import com.fasterxml.jackson.databind.ObjectMapper;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Value;
import java.time.LocalDate;
import java.security.MessageDigest;
import java.nio.charset.StandardCharsets;
import model.UiMetricEvent;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@CrossOrigin("*")
@RequestMapping("/ui-metrics")
public class UiMetricsController {
    private final UiMetricsService uiMetricsService;
    private final ObjectMapper objectMapper;
    @Value("${ui.metrics.admin-key:}")
    private String adminKey;

    public UiMetricsController(UiMetricsService uiMetricsService, ObjectMapper objectMapper) {
        this.uiMetricsService = uiMetricsService;
        this.objectMapper = objectMapper;
    }

    /**
     * Write-only endpoint. There is intentionally no GET endpoint for UI metrics,
     * so normal portal users cannot read server usage data through the UI.
     * text/plain keeps page-close beacons lightweight and avoids a CORS preflight.
     */
    @PostMapping(value = "/event", consumes = MediaType.TEXT_PLAIN_VALUE)
    public ResponseEntity<Void> record(@RequestBody String payload, HttpServletRequest request) {
        try {
            UiMetricEvent event = objectMapper.readValue(payload, UiMetricEvent.class);
            uiMetricsService.record(event, request.getRemoteAddr(), request.getHeader("User-Agent"));
            return ResponseEntity.noContent().build();
        } catch (IllegalArgumentException e) {
            return ResponseEntity.badRequest().build();
        } catch (Exception e) {
            // Metrics are non-critical and must never expose internal details to the browser.
            return ResponseEntity.badRequest().build();
        }
    }
    /** Hidden optional admin UI, disabled unless a long server-side key is configured. */
    @GetMapping(value = "/admin/summary", produces = MediaType.TEXT_PLAIN_VALUE)
    public ResponseEntity<String> summary(
            @RequestParam(required = false) String date,
            @RequestHeader(value = "X-UI-Metrics-Admin-Key", required = false) String supplied) {
        if (adminKey == null || adminKey.length() < 16)
            return ResponseEntity.status(503).body("Metrics admin access is disabled on the server.");
        if (supplied == null || !MessageDigest.isEqual(
                adminKey.getBytes(StandardCharsets.UTF_8), supplied.getBytes(StandardCharsets.UTF_8)))
            return ResponseEntity.status(403).body("Metrics admin authorization required.");
        try {
            LocalDate day = date == null || date.isBlank() ? LocalDate.now() : LocalDate.parse(date);
            return ResponseEntity.ok().header("Cache-Control", "no-store")
                    .body(uiMetricsService.dailySummary(day));
        } catch (IllegalArgumentException e) {
            return ResponseEntity.badRequest().body("Invalid metrics date");
        } catch (Exception e) {
            return ResponseEntity.internalServerError().body("Could not read metrics summary");
        }
    }
}
