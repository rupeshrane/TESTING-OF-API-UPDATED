package org.sodales;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;

import java.io.IOException;
import java.io.InputStream;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

/**
 * ReportPortal integration scoped to one test run.
 *
 * The endpoint/API key are shared immutable configuration, while project,
 * launch ID and test item ID are instance fields. This is important because
 * multiple API automation runs can execute at the same time.
 */
public final class ReportPortalManager {
    private static final HttpClient CLIENT = HttpClient.newHttpClient();
    private static final ObjectMapper MAPPER = new ObjectMapper();
    private static final Configuration CONFIG = loadConfiguration();

    private final String project;
    private String launchId;
    private String testItemId;

    public ReportPortalManager(String projectName) {
        String selected = isBlank(projectName) ? CONFIG.defaultProject : projectName.trim();
        this.project = selected;
    }

    public boolean isReady() {
        return CONFIG.valid && !isBlank(project) && !isBlank(CONFIG.launchName);
    }

    public void startLaunch() {
        if (!isReady()) {
            LogCollector.log("ReportPortal is enabled but configuration/project is incomplete. Continuing without ReportPortal publishing.");
            return;
        }

        try {
            launchId = null;
            testItemId = null;

            ObjectNode launch = MAPPER.createObjectNode();
            launch.put("name", CONFIG.launchName);
            launch.put("description", "QUALITY API Automation Run");
            launch.put("mode", "DEFAULT");
            launch.put("startTime", Instant.now().toString());

            HttpResponse<String> response = sendJson(
                    CONFIG.endpoint + "/api/v1/" + project + "/launch",
                    "POST",
                    MAPPER.writeValueAsString(launch));

            LogCollector.log("ReportPortal launch status: " + response.statusCode());
            if (isSuccess(response.statusCode())) {
                JsonNode json = MAPPER.readTree(response.body());
                if (json.hasNonNull("id")) {
                    launchId = json.get("id").asText();
                    LogCollector.log("ReportPortal launch created for project '" + project + "'.");
                } else {
                    LogCollector.log("ReportPortal launch was created but no launch ID was returned.");
                }
            } else {
                LogCollector.log("ReportPortal launch creation failed: " + compact(response.body()));
            }
        } catch (Exception e) {
            LogCollector.log("ReportPortal launch creation failed: " + safeMessage(e));
        }
    }

    /** Starts an item for the current test. Reuses an open item during OAuth retry. */
    public String startTestItem(String testName) {
        if (!isReady() || launchId == null) return null;
        if (testItemId != null) return testItemId;

        try {
            ObjectNode item = MAPPER.createObjectNode();
            item.put("name", safeValue(testName));
            item.put("description", "API Test");
            item.put("startTime", Instant.now().toString());
            item.put("type", "STEP");
            item.put("launchUuid", launchId);

            HttpResponse<String> response = sendJson(
                    CONFIG.endpoint + "/api/v1/" + project + "/item",
                    "POST",
                    MAPPER.writeValueAsString(item));

            if (isSuccess(response.statusCode())) {
                JsonNode json = MAPPER.readTree(response.body());
                if (json.hasNonNull("id")) {
                    testItemId = json.get("id").asText();
                    return testItemId;
                }
            }

            LogCollector.log("ReportPortal test item creation failed (HTTP " + response.statusCode() + ").");
        } catch (Exception e) {
            LogCollector.log("ReportPortal test item creation failed: " + safeMessage(e));
        }
        return null;
    }

    public void log(String message) {
        if (!isReady() || launchId == null || testItemId == null) return;

        try {
            ObjectNode log = MAPPER.createObjectNode();
            log.put("itemUuid", testItemId);
            log.put("launchUuid", launchId);
            log.put("level", "INFO");
            log.put("time", Instant.now().toString());
            log.put("message", safeValue(message));

            HttpResponse<String> response = sendJson(
                    CONFIG.endpoint + "/api/v1/" + project + "/log",
                    "POST",
                    MAPPER.writeValueAsString(log));

            if (!isSuccess(response.statusCode())) {
                LogCollector.log("ReportPortal log publishing failed (HTTP " + response.statusCode() + ").");
            }
        } catch (Exception e) {
            LogCollector.log("ReportPortal log publishing failed: " + safeMessage(e));
        }
    }

    public void finishTestItem(String status) {
        if (!isReady() || testItemId == null) return;

        String itemId = testItemId;
        try {
            ObjectNode finish = MAPPER.createObjectNode();
            finish.put("endTime", Instant.now().toString());
            finish.put("status", normalizeStatus(status));

            HttpResponse<String> response = sendJson(
                    CONFIG.endpoint + "/api/v1/" + project + "/item/" + itemId,
                    "PUT",
                    MAPPER.writeValueAsString(finish));

            if (!isSuccess(response.statusCode())) {
                LogCollector.log("ReportPortal test item finish failed (HTTP " + response.statusCode() + ").");
            }
        } catch (Exception e) {
            LogCollector.log("ReportPortal test item finish failed: " + safeMessage(e));
        } finally {
            testItemId = null;
        }
    }

    public void finishLaunch() {
        if (!isReady() || launchId == null) return;

        String id = launchId;
        try {
            ObjectNode finish = MAPPER.createObjectNode();
            finish.put("endTime", Instant.now().toString());

            HttpResponse<String> response = sendJson(
                    CONFIG.endpoint + "/api/v1/" + project + "/launch/" + id + "/finish",
                    "PUT",
                    MAPPER.writeValueAsString(finish));

            if (isSuccess(response.statusCode())) {
                LogCollector.log("ReportPortal launch finished for project '" + project + "'.");
            } else {
                LogCollector.log("ReportPortal launch finish failed (HTTP " + response.statusCode() + ").");
            }
        } catch (Exception e) {
            LogCollector.log("ReportPortal launch finish failed: " + safeMessage(e));
        } finally {
            launchId = null;
            testItemId = null;
        }
    }

    public static List<String> getProjects() {
        List<String> names = new ArrayList<>();
        if (!CONFIG.valid) return names;

        try {
            HttpRequest request = HttpRequest.newBuilder()
                    .uri(URI.create(CONFIG.endpoint + "/api/v1/project/names"))
                    .header("Authorization", "Bearer " + CONFIG.apiKey)
                    .header("Content-Type", "application/json")
                    .GET()
                    .build();

            HttpResponse<String> response = CLIENT.send(request, HttpResponse.BodyHandlers.ofString());
            if (!isSuccess(response.statusCode())) {
                System.out.println("ReportPortal project lookup failed (HTTP " + response.statusCode() + ").");
                return names;
            }

            JsonNode json = MAPPER.readTree(response.body());
            JsonNode source = json.isArray() ? json : json.path("content");
            if (source.isArray()) {
                for (JsonNode project : source) {
                    String name;
                    if (project.isTextual()) name = project.asText();
                    else if (project.hasNonNull("projectName")) name = project.get("projectName").asText();
                    else if (project.hasNonNull("name")) name = project.get("name").asText();
                    else name = "";
                    if (!isBlank(name)) names.add(name);
                }
            }
        } catch (Exception e) {
            System.out.println("ReportPortal project lookup failed: " + safeMessage(e));
        }
        return names;
    }

    public static boolean createProject(String projectName) {
        if (!CONFIG.valid || isBlank(projectName)) return false;

        try {
            ObjectNode project = MAPPER.createObjectNode();
            project.put("projectName", projectName.trim());
            project.put("entryType", "INTERNAL");

            HttpRequest request = HttpRequest.newBuilder()
                    .uri(URI.create(CONFIG.endpoint + "/api/v1/project"))
                    .header("Authorization", "Bearer " + CONFIG.apiKey)
                    .header("Content-Type", "application/json")
                    .POST(HttpRequest.BodyPublishers.ofString(MAPPER.writeValueAsString(project)))
                    .build();

            HttpResponse<String> response = CLIENT.send(request, HttpResponse.BodyHandlers.ofString());
            if (!isSuccess(response.statusCode())) {
                System.out.println("ReportPortal project creation failed (HTTP " + response.statusCode() + "): " + compact(response.body()));
            }
            return isSuccess(response.statusCode());
        } catch (Exception e) {
            System.out.println("ReportPortal project creation failed: " + safeMessage(e));
            return false;
        }
    }

    private static HttpResponse<String> sendJson(String url, String method, String body) throws IOException, InterruptedException {
        HttpRequest.Builder builder = HttpRequest.newBuilder()
                .uri(URI.create(url))
                .header("Authorization", "Bearer " + CONFIG.apiKey)
                .header("Content-Type", "application/json");

        if ("POST".equals(method)) builder.POST(HttpRequest.BodyPublishers.ofString(body));
        else if ("PUT".equals(method)) builder.PUT(HttpRequest.BodyPublishers.ofString(body));
        else throw new IllegalArgumentException("Unsupported ReportPortal HTTP method: " + method);

        return CLIENT.send(builder.build(), HttpResponse.BodyHandlers.ofString());
    }

    private static Configuration loadConfiguration() {
        Properties properties = new Properties();
        try (InputStream input = ReportPortalManager.class.getClassLoader().getResourceAsStream("reportportal.properties")) {
            if (input == null) {
                return new Configuration("", "", "", "", false);
            }
            properties.load(input);
            String endpoint = removeTrailingSlash(properties.getProperty("rp.endpoint"));
            String apiKey = trim(properties.getProperty("rp.api.key"));
            String defaultProject = trim(properties.getProperty("rp.project"));
            String launchName = trim(properties.getProperty("rp.launch"));
            boolean valid = !isBlank(endpoint) && !isBlank(apiKey);
            return new Configuration(endpoint, apiKey, defaultProject, launchName, valid);
        } catch (IOException e) {
            return new Configuration("", "", "", "", false);
        }
    }

    private static boolean isSuccess(int code) { return code >= 200 && code < 300; }

    private static String normalizeStatus(String status) {
        String normalized = safeValue(status).trim().toUpperCase();
        return switch (normalized) {
            case "PASSED", "FAILED", "SKIPPED", "STOPPED", "CANCELLED" -> normalized;
            default -> "FAILED";
        };
    }

    private static String compact(String value) {
        if (value == null) return "";
        String compact = value.replaceAll("\\s+", " ").trim();
        return compact.length() > 300 ? compact.substring(0, 300) + "..." : compact;
    }

    private static String safeMessage(Throwable e) {
        return e.getMessage() == null ? e.getClass().getSimpleName() : e.getMessage();
    }

    private static String safeValue(String value) { return value == null ? "" : value; }
    private static String trim(String value) { return value == null ? "" : value.trim(); }
    private static boolean isBlank(String value) { return value == null || value.trim().isEmpty(); }

    private static String removeTrailingSlash(String value) {
        String result = trim(value);
        while (result.endsWith("/")) result = result.substring(0, result.length() - 1);
        return result;
    }

    private record Configuration(String endpoint, String apiKey, String defaultProject, String launchName, boolean valid) {}
}
