package org.sodales;

import org.springframework.stereotype.Service;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.time.Duration;
import java.util.Base64;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Anonymous browser-session capabilities. This is NOT user authentication.
 * Tokens exist only in server memory; run records store the session fingerprint.
 */
@Service
public class PortalSessionService {
    private static final long SESSION_TTL_MS = Duration.ofHours(24).toMillis();
    private final SecureRandom secureRandom = new SecureRandom();
    private final Map<String, Long> sessions = new ConcurrentHashMap<>();

    public String createOrResume(String presentedToken) {
        long now = System.currentTimeMillis();
        sessions.entrySet().removeIf(entry -> entry.getValue() < now);
        if (validAndTouch(presentedToken)) return presentedToken;
        String token = secureToken();
        sessions.put(fingerprint(token), now + SESSION_TTL_MS);
        return token;
    }

    public boolean validAndTouch(String token) {
        if (token == null || !token.matches("[A-Za-z0-9_-]{40,128}")) return false;
        String key = fingerprint(token);
        long now = System.currentTimeMillis();
        return sessions.computeIfPresent(key, (ignored, expiresAt) ->
                expiresAt > now ? now + SESSION_TTL_MS : null) != null;
    }

    public String fingerprint(String token) {
        try {
            byte[] hash = MessageDigest.getInstance("SHA-256")
                    .digest(token.getBytes(StandardCharsets.UTF_8));
            return Base64.getUrlEncoder().withoutPadding().encodeToString(hash);
        } catch (NoSuchAlgorithmException e) {
            throw new IllegalStateException("SHA-256 is unavailable", e);
        }
    }

    public String secureToken() {
        byte[] bytes = new byte[32];
        secureRandom.nextBytes(bytes);
        return Base64.getUrlEncoder().withoutPadding().encodeToString(bytes);
    }

    public boolean ownsRun(String sessionToken, String ownerFingerprint) {
        if (!validAndTouch(sessionToken) || ownerFingerprint == null) return false;
        return MessageDigest.isEqual(fingerprint(sessionToken).getBytes(StandardCharsets.US_ASCII),
                ownerFingerprint.getBytes(StandardCharsets.US_ASCII));
    }

    public static boolean tokenMatches(String supplied, String expected) {
        if (supplied == null || expected == null || supplied.length() > 256) return false;
        return MessageDigest.isEqual(supplied.getBytes(StandardCharsets.UTF_8),
                expected.getBytes(StandardCharsets.UTF_8));
    }
}
