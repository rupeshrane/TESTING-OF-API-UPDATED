package org.sodales;

import com.fasterxml.jackson.databind.ObjectMapper;
import model.UiMetricEvent;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import jakarta.annotation.PostConstruct;
import java.io.BufferedReader;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.time.*;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicLong;

@Service
public class UiMetricsService {
    private static final DateTimeFormatter DAY_FORMAT = DateTimeFormatter.ISO_LOCAL_DATE;
    private static final Set<String> ALLOWED_EVENTS = Set.of(
            "SESSION_START", "SESSION_RESUME", "PAGE_VIEW", "TAB_VIEW",
            "HEARTBEAT", "VISIBLE", "HIDDEN", "SESSION_END"
    );

    private final ObjectMapper objectMapper;
    private final Path logDirectory;
    private final int retentionDays;
    private final Object fileLock = new Object();
    private final Map<LocalDate, DailyMetrics> daily = new ConcurrentHashMap<>();

    public UiMetricsService(
            ObjectMapper objectMapper,
            @Value("${ui.metrics.log-directory:logs/ui-metrics}") String logDirectory,
            @Value("${ui.metrics.retention-days:90}") int retentionDays) {
        this.objectMapper = objectMapper;
        this.logDirectory = Paths.get(logDirectory).toAbsolutePath().normalize();
        this.retentionDays = Math.max(1, retentionDays);
    }

    @PostConstruct
    public void initialize() throws IOException {
        Files.createDirectories(logDirectory);
        cleanupOldFiles();
        rebuildTodayFromLog();
        writeSummary(LocalDate.now());
        System.out.println("[UI_METRICS] Server-only UI metrics logging enabled at: " + logDirectory);
    }

    public void record(UiMetricEvent input, String remoteAddress, String userAgent) {
        UiMetricEvent event = sanitize(input);
        LocalDate today = LocalDate.now();
        Instant receivedAt = Instant.now();

        Map<String, Object> record = new LinkedHashMap<>();
        record.put("serverTimestamp", receivedAt.toString());
        record.put("eventType", event.eventType);
        record.put("sessionId", event.sessionId);
        record.put("pageName", event.pageName);
        record.put("path", event.path);
        record.put("activeSeconds", event.activeSeconds);
        record.put("clientTimestamp", event.clientTimestamp);
        record.put("remoteAddress", safeText(remoteAddress, 100));
        record.put("userAgent", safeText(userAgent, 300));

        synchronized (fileLock) {
            try {
                Path eventFile = eventLogPath(today);
                String line = objectMapper.writeValueAsString(record) + System.lineSeparator();
                Files.writeString(eventFile, line, StandardCharsets.UTF_8,
                        StandardOpenOption.CREATE, StandardOpenOption.APPEND);

                applyEvent(today, event);
                writeSummary(today);
            } catch (IOException e) {
                // UI metrics must never break the QA portal.
                System.err.println("[UI_METRICS] Unable to write UI metric: " + e.getMessage());
            }
        }
    }

    private UiMetricEvent sanitize(UiMetricEvent input) {
        if (input == null) throw new IllegalArgumentException("Metric event is required.");

        UiMetricEvent event = new UiMetricEvent();
        event.eventType = safeText(input.eventType, 40).toUpperCase(Locale.ROOT);
        if (!ALLOWED_EVENTS.contains(event.eventType)) {
            throw new IllegalArgumentException("Unsupported metric event type.");
        }

        event.sessionId = safeText(input.sessionId, 100);
        if (event.sessionId.isBlank() || !event.sessionId.matches("[A-Za-z0-9._:-]{8,100}")) {
            throw new IllegalArgumentException("Invalid metric session ID.");
        }

        event.pageName = safeText(input.pageName, 120);
        event.path = safeText(input.path, 250);
        event.clientTimestamp = safeText(input.clientTimestamp, 80);
        event.activeSeconds = Math.max(0, Math.min(input.activeSeconds, 7L * 24 * 60 * 60));
        return event;
    }

    private void applyEvent(LocalDate date, UiMetricEvent event) {
        DailyMetrics metrics = daily.computeIfAbsent(date, ignored -> new DailyMetrics());
        metrics.sessions.add(event.sessionId);

        if ("SESSION_START".equals(event.eventType)) {
            metrics.portalVisits.incrementAndGet();
        }

        if ("PAGE_VIEW".equals(event.eventType) || "TAB_VIEW".equals(event.eventType)) {
            String page = event.pageName.isBlank() ? "Unknown" : event.pageName;
            metrics.pageVisits.computeIfAbsent(page, ignored -> new AtomicLong()).incrementAndGet();
        }

        long previous = metrics.sessionActiveSeconds.getOrDefault(event.sessionId, 0L);
        if (event.activeSeconds > previous) {
            metrics.totalActiveSeconds.addAndGet(event.activeSeconds - previous);
            metrics.sessionActiveSeconds.put(event.sessionId, event.activeSeconds);
        }
        metrics.lastUpdated = Instant.now();
    }

    private void rebuildTodayFromLog() {
        LocalDate today = LocalDate.now();
        Path log = eventLogPath(today);
        if (!Files.exists(log)) return;

        try (BufferedReader reader = Files.newBufferedReader(log, StandardCharsets.UTF_8)) {
            String line;
            while ((line = reader.readLine()) != null) {
                if (line.isBlank()) continue;
                try {
                    @SuppressWarnings("unchecked")
                    Map<String, Object> value = objectMapper.readValue(line, Map.class);
                    UiMetricEvent event = new UiMetricEvent();
                    event.eventType = Objects.toString(value.get("eventType"), "");
                    event.sessionId = Objects.toString(value.get("sessionId"), "");
                    event.pageName = Objects.toString(value.get("pageName"), "");
                    event.path = Objects.toString(value.get("path"), "");
                    Object active = value.get("activeSeconds");
                    event.activeSeconds = active instanceof Number ? ((Number) active).longValue() : 0;
                    event.clientTimestamp = Objects.toString(value.get("clientTimestamp"), "");
                    if (!event.sessionId.isBlank() && ALLOWED_EVENTS.contains(event.eventType)) {
                        applyEvent(today, event);
                    }
                } catch (Exception ignored) {
                    // A malformed historical line must not stop the application.
                }
            }
        } catch (IOException e) {
            System.err.println("[UI_METRICS] Unable to rebuild today's metrics: " + e.getMessage());
        }
    }

    private void writeSummary(LocalDate date) {
        DailyMetrics metrics = daily.computeIfAbsent(date, ignored -> new DailyMetrics());
        StringBuilder out = new StringBuilder();
        out.append("QA PORTAL UI METRICS - ").append(DAY_FORMAT.format(date)).append(System.lineSeparator());
        out.append("============================================================").append(System.lineSeparator());
        out.append("Portal visits       : ").append(metrics.portalVisits.get()).append(System.lineSeparator());
        out.append("Unique sessions     : ").append(metrics.sessions.size()).append(System.lineSeparator());
        out.append("Total active time   : ").append(formatDuration(metrics.totalActiveSeconds.get())).append(System.lineSeparator());
        out.append("Last updated        : ").append(metrics.lastUpdated).append(System.lineSeparator());
        out.append(System.lineSeparator()).append("TAB / PAGE VISITS").append(System.lineSeparator());
        out.append("------------------------------------------------------------").append(System.lineSeparator());

        metrics.pageVisits.entrySet().stream()
                .sorted((a, b) -> Long.compare(b.getValue().get(), a.getValue().get()))
                .forEach(entry -> out.append(String.format(Locale.ROOT, "%-40s %8d%n", entry.getKey(), entry.getValue().get())));

        Path target = summaryPath(date);
        Path temp = target.resolveSibling(target.getFileName() + ".tmp");
        try {
            Files.writeString(temp, out.toString(), StandardCharsets.UTF_8,
                    StandardOpenOption.CREATE, StandardOpenOption.TRUNCATE_EXISTING);
            try {
                Files.move(temp, target, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE);
            } catch (AtomicMoveNotSupportedException e) {
                Files.move(temp, target, StandardCopyOption.REPLACE_EXISTING);
            }
        } catch (IOException e) {
            System.err.println("[UI_METRICS] Unable to write summary: " + e.getMessage());
        }
    }

    /** Text-only summary, never raw user/IP log lines. Caller must authorize access. */
    public String dailySummary(LocalDate date) throws IOException {
        if (date.isAfter(LocalDate.now()) || date.isBefore(LocalDate.now().minusDays(retentionDays)))
            throw new IllegalArgumentException("Date outside retained period");
        if (date.equals(LocalDate.now())) {
            synchronized (fileLock) { writeSummary(date); }
        }
        Path file = summaryPath(date);
        if (!Files.isRegularFile(file)) return "No UI metrics for " + date;
        return Files.readString(file, StandardCharsets.UTF_8);
    }

    private Path eventLogPath(LocalDate date) {
        return logDirectory.resolve("ui-metrics-events-" + DAY_FORMAT.format(date) + ".jsonl");
    }

    private Path summaryPath(LocalDate date) {
        return logDirectory.resolve("ui-metrics-summary-" + DAY_FORMAT.format(date) + ".log");
    }

    private void cleanupOldFiles() {
        LocalDate cutoff = LocalDate.now().minusDays(retentionDays);
        try (DirectoryStream<Path> stream = Files.newDirectoryStream(logDirectory, "ui-metrics-*") ) {
            for (Path path : stream) {
                String name = path.getFileName().toString();
                LocalDate fileDate = dateFromName(name);
                if (fileDate != null && fileDate.isBefore(cutoff)) {
                    Files.deleteIfExists(path);
                }
            }
        } catch (IOException e) {
            System.err.println("[UI_METRICS] Unable to clean old metric files: " + e.getMessage());
        }
    }

    private LocalDate dateFromName(String name) {
        for (int i = 0; i <= name.length() - 10; i++) {
            String candidate = name.substring(i, i + 10);
            try {
                return LocalDate.parse(candidate, DAY_FORMAT);
            } catch (Exception ignored) {
            }
        }
        return null;
    }

    private String safeText(String value, int max) {
        if (value == null) return "";
        String cleaned = value.replace("\r", " ").replace("\n", " ").trim();
        return cleaned.length() <= max ? cleaned : cleaned.substring(0, max);
    }

    private String formatDuration(long totalSeconds) {
        long hours = totalSeconds / 3600;
        long minutes = (totalSeconds % 3600) / 60;
        long seconds = totalSeconds % 60;
        return String.format(Locale.ROOT, "%02d:%02d:%02d", hours, minutes, seconds);
    }

    private static class DailyMetrics {
        final AtomicLong portalVisits = new AtomicLong();
        final AtomicLong totalActiveSeconds = new AtomicLong();
        final Set<String> sessions = ConcurrentHashMap.newKeySet();
        final Map<String, Long> sessionActiveSeconds = new ConcurrentHashMap<>();
        final Map<String, AtomicLong> pageVisits = new ConcurrentHashMap<>();
        volatile Instant lastUpdated = Instant.now();
    }
}
