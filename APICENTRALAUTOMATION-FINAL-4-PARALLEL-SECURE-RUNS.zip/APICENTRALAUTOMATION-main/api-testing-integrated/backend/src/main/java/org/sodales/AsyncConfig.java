package org.sodales;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

@Configuration
public class AsyncConfig {
    // Core == max, queue == zero: up to N runs start immediately in parallel, instead
    // of waiting FIFO behind a small core pool. Excess requests receive a 429 response.
    @Bean("testRunExecutor")
    public ThreadPoolTaskExecutor testRunExecutor(@Value("${qa.runs.max-concurrent:4}") int parallel) {
        int count = Math.max(1, Math.min(parallel, 32));
        ThreadPoolTaskExecutor executor = new ThreadPoolTaskExecutor();
        executor.setCorePoolSize(count);
        executor.setMaxPoolSize(count);
        executor.setQueueCapacity(0);
        executor.setThreadNamePrefix("api-test-run-");
        executor.setWaitForTasksToCompleteOnShutdown(false);
        executor.setAwaitTerminationSeconds(10);
        executor.initialize();
        return executor;
    }
}
