package org.sodales;

import java.net.URI;
import java.nio.charset.StandardCharsets;

/** Retains existing %-escapes while encoding whitespace in Excel URL values and injected IDs. */
public final class HttpUriUtil {
    private HttpUriUtil() {}
    public static URI fromSpreadsheet(String value) {
        if (value == null || value.isBlank()) throw new IllegalArgumentException("API URL is empty");
        String raw = value.trim();
        StringBuilder encoded = new StringBuilder();
        raw.codePoints().forEach(cp -> {
            if (Character.isWhitespace(cp) || Character.isISOControl(cp)) {
                for (byte b : new String(Character.toChars(cp)).getBytes(StandardCharsets.UTF_8)) {
                    encoded.append('%'); encoded.append(Character.forDigit((b >> 4) & 15,16));
                    encoded.append(Character.forDigit(b & 15,16));
                }
            } else encoded.appendCodePoint(cp);
        });
        try {
            URI uri = URI.create(encoded.toString());
            if (!"http".equalsIgnoreCase(uri.getScheme()) && !"https".equalsIgnoreCase(uri.getScheme()))
                throw new IllegalArgumentException("Only http(s) APIs are supported");
            if (uri.getHost() == null) throw new IllegalArgumentException("API URL must contain a valid host");
            return uri;
        } catch (IllegalArgumentException e) {
            throw new IllegalArgumentException("Invalid API URL after escaping spaces: " + e.getMessage(), e);
        }
    }
}
