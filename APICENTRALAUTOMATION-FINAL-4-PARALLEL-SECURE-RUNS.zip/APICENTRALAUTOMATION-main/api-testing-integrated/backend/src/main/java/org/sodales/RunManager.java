package org.sodales;

import model.AuthContext;
import model.RunRecord;
import model.RunStatus;
import model.TestRunContext;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;
import org.springframework.stereotype.Service;

import java.io.File;
import java.time.Instant;
import java.util.Map;
import java.util.concurrent.CancellationException;
import java.util.concurrent.ConcurrentHashMap;

@Service
public class RunManager {
    private final Map<String, RunRecord> runs = new ConcurrentHashMap<>();
    private final ThreadPoolTaskExecutor executor;

    public RunManager(@Qualifier("testRunExecutor") ThreadPoolTaskExecutor executor) {
        this.executor = executor;
    }

    public RunRecord submit(TestRunContext context, AuthContext authContext, String ownerSessionFingerprint) {
        RunRecord record = new RunRecord(context, ownerSessionFingerprint);
        runs.put(context.runId, record);
        LogCollector.createRun(context.runId);
        try {
            record.future = executor.submit(() -> execute(record, authContext));
            LogCollector.log(context.runId, "Run accepted (parallel worker available).");
            if (record.cancelRequested.get()) record.future.cancel(true);
        } catch (RuntimeException e) {
            runs.remove(context.runId);
            LogCollector.log(context.runId, "All parallel execution slots are busy: " + e.getMessage());
            throw e;
        }
        return record;
    }

    public synchronized boolean requestCancel(RunRecord record) {
        if (record == null || isTerminal(record.status)) return false;
        record.cancelRequested.set(true);
        if (record.status == RunStatus.QUEUED && record.startedAt == null) {
            record.status = RunStatus.CANCELLED;
            record.completedAt = Instant.now();
        } else {
            record.status = RunStatus.CANCELLING;
        }
        LogCollector.log(record.context.runId, "Cancellation requested. Completed test results will be preserved.");
        if (record.future != null) record.future.cancel(true);
        return true;
    }

    private void execute(RunRecord record, AuthContext authContext) {
        TestRunContext context = record.context;
        LogCollector.beginRun(context.runId);
        try {
            if (record.cancelRequested.get()) throw new CancellationException("Cancelled before execution");
            record.status = RunStatus.RUNNING;
            record.startedAt = Instant.now();
            LogCollector.log("Execution started on " + Thread.currentThread().getName());
            ApiTests.run(context, authContext, record);
            if (record.cancelRequested.get() || Thread.currentThread().isInterrupted())
                throw new CancellationException("Cancellation requested");
            verifyReports(context);
            record.status = RunStatus.COMPLETED;
            LogCollector.log("Execution completed successfully.");
        } catch (Throwable e) {
            if (record.cancelRequested.get() || e instanceof CancellationException || e instanceof InterruptedException) {
                record.status = RunStatus.CANCELLED;
                record.errorCode = "CANCELLED";
                record.errorMessage = "Run cancelled. Reports include all completed tests.";
                LogCollector.log("Run cancelled; partial results retained (" + record.executedTests.get() + " completed rows).");
                Thread.interrupted(); // clear interrupt to allow report flush/cleanup
            } else {
                record.status = RunStatus.FAILED;
                record.errorCode = e instanceof IllegalArgumentException ? "VALIDATION_FAILED" : "EXECUTION_FAILED";
                record.errorMessage = safeMessage(e);
                LogCollector.log("Execution failed: " + e.getClass().getSimpleName() + ": " + safeMessage(e));
                e.printStackTrace();
            }
        } finally {
            record.completedAt = Instant.now();
            runner.ApiTestRunner.closeRun(context.runId);
            LogCollector.endRun();
        }
    }

    public RunRecord get(String runId) { return runs.get(runId); }
    public boolean isActive(String runId) {
        RunRecord r = runs.get(runId);
        return r != null && !isTerminal(r.status);
    }
    public static boolean isTerminal(RunStatus status) {
        return status == RunStatus.COMPLETED || status == RunStatus.CANCELLED || status == RunStatus.FAILED;
    }
    private void verifyReports(TestRunContext context) {
        if (!new File(context.htmlPath).exists() && !new File(context.csvPath).exists()
                && !new File(context.extentPath).exists()) {
            throw new IllegalStateException("Test execution finished but no report was generated.");
        }
    }
    private String safeMessage(Throwable e) {
        String message = e.getMessage();
        if (message == null || message.isBlank()) return "Test execution failed. See run logs.";
        return message.length() > 1000 ? message.substring(0, 1000) : message;
    }
}
