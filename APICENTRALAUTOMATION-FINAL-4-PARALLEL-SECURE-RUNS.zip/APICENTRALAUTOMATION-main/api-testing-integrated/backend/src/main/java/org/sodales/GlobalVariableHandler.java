package org.sodales;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/** Variables are isolated per run, including POST-to-GET attachment chains. */
public class GlobalVariableHandler extends JSONFilePathHandler {
    private final Map<String, String> variables = new ConcurrentHashMap<>();

    public void setGlobalVariable(String path, String name, String response, String format) {
        if (name == null || name.isBlank() || "na".equalsIgnoreCase(name.trim())
                || path == null || path.isBlank() || "na".equalsIgnoreCase(path.trim())) return;
        try {
            String value = "json".equalsIgnoreCase(format) ? readJsonPath(response, path)
                : "xml".equalsIgnoreCase(format) ? readXmlPath(response, path)
                : null;
            if (value == null || value.isBlank())
                throw new IllegalArgumentException("No value found in response at path: " + path);
            variables.put(name.trim(), value);
            LogCollector.log("Global variable saved: " + name + " (value hidden)");
        } catch (Exception e) {
            throw new IllegalArgumentException("Failed to extract '" + name + "' from " + format
                + " response using " + path + ": " + e.getMessage(), e);
        }
    }

    /** Encode replacement values for a single URL path/query parameter (e.g. an MPL ID). */
    public String globalvariableUrlReplacer(String input) {
        if (input == null) return null;
        String output = input;
        for (String name : variables.keySet().stream().sorted((a,b) -> Integer.compare(b.length(),a.length())).toList()) {
            String value = variables.get(name);
            if (value == null) continue;
            String encoded = java.net.URLEncoder.encode(value, java.nio.charset.StandardCharsets.UTF_8)
                    .replace("+", "%20").replace("%7E", "~");
            if (name.startsWith("[[") || name.startsWith("${") || name.startsWith("{{"))
                output = output.replace(name, encoded);
            else output = output.replace("[[" + name + "]]", encoded)
                    .replace("${" + name + "}", encoded).replace("{{" + name + "}}", encoded);
        }
        return output;
    }

    public String globalvariablevaluereplacer(String input) {
        if (input == null) return null;
        String output = input;
        // Longer placeholders first; prevents partial replacements. Never replace plain words
        // throughout URLs: a variable called ID must not change a hostname containing ID.
        for (String name : variables.keySet().stream().sorted((a,b) -> Integer.compare(b.length(),a.length())).toList()) {
            String value = variables.get(name);
            if (value == null) continue;
            if (name.startsWith("[[") || name.startsWith("${") || name.startsWith("{{")) {
                output = output.replace(name, value); // historical Excel template names: [[id]]
            } else {
                output = output.replace("[[" + name + "]]", value)
                    .replace("${" + name + "}", value)
                    .replace("{{" + name + "}}", value);
            }
        }
        return output;
    }
}
