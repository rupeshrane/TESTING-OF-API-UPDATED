package runner;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;
import com.opencsv.CSVWriter;
import model.ApiTestCase;
import model.AuthContext;
import model.TestRunContext;

import java.io.*;
import java.net.URI;
import java.time.Duration;
import java.util.Locale;
import java.util.LinkedHashMap;
import java.util.concurrent.CancellationException;
import org.sodales.HttpUriUtil;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.HashMap;
import java.util.concurrent.ConcurrentHashMap;
import java.util.Map;
import java.util.UUID;
import org.sodales.ReportPortalManager;
import org.sodales.GlobalVariableHandler;
import org.sodales.OAuth2Client;

public class ApiTestRunner {

    private static final Map<String, ExtentReports> extentMap = new ConcurrentHashMap<>();
    // Java HttpClient is thread-safe. Reuse the pool across parallel executions.
    private static final HttpClient HTTP_CLIENT = HttpClient.newBuilder()
            .connectTimeout(Duration.ofSeconds(30)).build();

    public static void run(ApiTestCase test,
            TestRunContext context,
            GlobalVariableHandler variableHandler,
            AuthContext authContext,
            ReportPortalManager reportPortal) {
        boolean itemStarted = false;
        boolean itemFinished = false;
        try {
            if (Thread.currentThread().isInterrupted()) throw new CancellationException("Run cancelled");
            validateTestCase(test);
            // Resolve the POST-produced ID before URI validation. Use the exact resolved URL
            // for the report so an incorrect global variable is easy to diagnose.
            String resolvedUrl = variableHandler.globalvariableUrlReplacer(safeValue(test.url));
            URI uri = HttpUriUtil.fromSpreadsheet(resolvedUrl);
            if (resolvedUrl.contains("[[") || resolvedUrl.contains("${"))
                throw new IllegalArgumentException("Unresolved placeholder in request URL: " + resolvedUrl);

            if (reportPortal != null) {
                reportPortal.startTestItem(test.testName);
                itemStarted = true;
            }
            String method = safeValue(test.method).trim().toUpperCase(Locale.ROOT);
            String bodyType = safeValue(test.bodyType).trim().toUpperCase(Locale.ROOT);
            HttpRequest.BodyPublisher publisher = "GET".equals(method) ? HttpRequest.BodyPublishers.noBody()
                    : buildBodyPublisher(test, context, variableHandler);
            String multipartBoundary = "FORM_DATA".equals(bodyType) && !"GET".equals(method)
                    ? CURRENT_MULTIPART_BOUNDARY.get() : null;
            CURRENT_MULTIPART_BOUNDARY.remove();

            HttpResponse<byte[]> response = null;
            for (int attempt = 0; attempt < 2; attempt++) {
                if (Thread.currentThread().isInterrupted()) throw new CancellationException("Run cancelled");
                HttpRequest.Builder builder = HttpRequest.newBuilder(uri).timeout(Duration.ofMinutes(5));
                String authType = safeValue(authContext.authenticationType);
                if ("OAUTH".equalsIgnoreCase(authType) || "OAUTH2".equalsIgnoreCase(authType)) {
                    if (OAuth2Client.isTokenMissingOrExpired(authContext)) OAuth2Client.getAccessToken(authContext);
                    builder.header("Authorization", "Bearer " + authContext.accessToken);
                } else if ("BASIC".equalsIgnoreCase(authType)) {
                    String creds = authContext.username + ":" + authContext.password;
                    builder.header("Authorization", "Basic " + java.util.Base64.getEncoder()
                            .encodeToString(creds.getBytes(StandardCharsets.UTF_8)));
                }
                if (test.headers != null && !test.headers.isBlank()) {
                    for (String h : test.headers.split(";")) {
                        String[] kv = h.split(":", 2);
                        if (kv.length != 2 || kv[0].isBlank()) continue;
                        // Multipart boundary must match the encoded body, even if Excel
                        // contains a hard-coded Content-Type: multipart/form-data header.
                        if (multipartBoundary != null && "content-type".equalsIgnoreCase(kv[0].trim())) continue;
                        if ("authorization".equalsIgnoreCase(kv[0].trim())) continue;
                        builder.header(kv[0].trim(), variableHandler.globalvariablevaluereplacer(kv[1].trim()));
                    }
                }
                if (multipartBoundary != null) builder.header("Content-Type", "multipart/form-data; boundary=" + multipartBoundary);
                switch (method) {
                    case "POST" -> builder.POST(publisher);
                    case "PUT" -> builder.PUT(publisher);
                    case "PATCH" -> builder.method("PATCH", publisher);
                    case "DELETE" -> builder.method("DELETE", publisher);
                    case "GET" -> builder.GET();
                    default -> throw new IllegalArgumentException("Unsupported HTTP method: " + method);
                }
                response = HTTP_CLIENT.send(builder.build(), HttpResponse.BodyHandlers.ofByteArray());
                if (response.statusCode() != 401 || attempt == 1 ||
                        !("OAUTH".equalsIgnoreCase(authType) || "OAUTH2".equalsIgnoreCase(authType))) break;
                org.sodales.LogCollector.log("OAuth 401: refreshing token and retrying once.");
                OAuth2Client.refreshAccessToken(authContext);
            }
            if (Thread.currentThread().isInterrupted()) throw new CancellationException("Run cancelled");
            int status = response.statusCode();
            boolean downloadable = "GET".equals(method) && isDownload(response);
            String responseBody;
            if (downloadable && status >= 200 && status < 300) {
                Path output = saveAttachment(context, test, response);
                responseBody = "[Attachment saved to downloads/" + output.getFileName()
                        + " (" + response.body().length + " bytes)]";
                org.sodales.LogCollector.log("GET downloaded attachment: " + output.getFileName());
            } else {
                // Never interpret binary response data as JSON to extract global variables.
                String type = response.headers().firstValue("Content-Type").orElse("").toLowerCase(Locale.ROOT);
                java.nio.charset.Charset charset = StandardCharsets.UTF_8;
                java.util.regex.Matcher matcher = java.util.regex.Pattern.compile("charset=([\\w-]+)", java.util.regex.Pattern.CASE_INSENSITIVE).matcher(type);
                if (matcher.find()) try { charset = java.nio.charset.Charset.forName(matcher.group(1)); } catch (Exception ignored) {}
                responseBody = new String(response.body(), charset);
            }
            int expectedStatus = Integer.parseInt(safeValue(test.expectedStatus).trim());
            boolean passed = status == expectedStatus && ("NA".equalsIgnoreCase(safeValue(test.expectedResponse))
                || responseBody.contains(safeValue(test.expectedResponse)));
            // Commit the completed test row before any subsequent global-variable extraction
            // throws, so cancellation/failure still offers the run's completed results.
            writeToCSV(context.csvPath, resolvedUrl, safeValue(test.headers), safeValue(test.expectedStatus),
                    status, safeValue(test.expectedResponse), responseBody);
            writeToHTML(context.htmlPath, safeValue(test.testName), resolvedUrl, safeValue(test.headers),
                    safeValue(test.expectedStatus), status, safeValue(test.expectedResponse), responseBody);
            extendReport(context, safeValue(test.testName), resolvedUrl, safeValue(test.headers),
                    safeValue(test.expectedStatus), status, safeValue(test.expectedResponse), responseBody);
            org.sodales.LogCollector.log("Completed: " + test.testName + " | " + method + " " + uri
                    + " | HTTP " + status + " | " + (passed ? "PASS" : "FAIL"));
            if (reportPortal != null) {
                reportPortal.log("Method: " + method);
                reportPortal.log("URL: " + resolvedUrl);
                reportPortal.log("HTTP status: " + status);
                reportPortal.log(passed ? "Test PASSED" : "Test FAILED");
                reportPortal.finishTestItem(passed ? "PASSED" : "FAILED");
                itemFinished = true;
            }
            // Only a text/JSON/XML response can supply variables for the next GET.
            if (downloadable) {
                if (test.globalvariable != null && !test.globalvariable.isBlank()
                        && !"NA".equalsIgnoreCase(test.globalvariable))
                    throw new IllegalArgumentException("Cannot extract JSON/XML variables from a binary attachment");
            } else {
                variableHandler.setGlobalVariable(test.globalvariablejsonxmlpath,
                        test.globalvariable, responseBody, test.xmlorjson);
            }
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            throw new CancellationException("Run cancelled during HTTP call");
        } catch (CancellationException e) {
            throw e;
        } catch (Exception e) {
            if (Thread.currentThread().isInterrupted()) throw new CancellationException("Run cancelled");
            org.sodales.LogCollector.log("Test '" + safeValue(test.testName) + "' failed: " + e.getMessage());
            if (reportPortal != null && itemStarted && !itemFinished) {
                reportPortal.log("Test exception: " + e.getMessage());
                reportPortal.finishTestItem("FAILED");
            }
            // Failure is surfaced on the UI, prior report rows are retained.
            throw new RuntimeException("Test '" + safeValue(test.testName) + "' failed: " + e.getMessage(), e);
        }
    }

    private static final ThreadLocal<String> CURRENT_MULTIPART_BOUNDARY = new ThreadLocal<>();

    private static boolean isDownload(HttpResponse<byte[]> response) {
        String disposition = response.headers().firstValue("Content-Disposition").orElse("").toLowerCase(Locale.ROOT);
        String type = response.headers().firstValue("Content-Type").orElse("").toLowerCase(Locale.ROOT);
        if (disposition.contains("attachment") || disposition.contains("filename=")) return true;
        if (type.startsWith("image/") || type.startsWith("audio/") || type.startsWith("video/")
                || type.startsWith("text/csv")) return true;
        if (type.startsWith("application/") && !type.contains("json")
                && !type.contains("xml") && !type.contains("javascript")
                && !type.contains("graphql") && !type.contains("x-www-form-urlencoded")) return true;
        return false;
    }

    private static Path saveAttachment(TestRunContext context, ApiTestCase test, HttpResponse<byte[]> response) throws IOException {
        Path dir = Path.of(context.runDir, "downloads");
        Files.createDirectories(dir);
        String disposition = response.headers().firstValue("Content-Disposition").orElse("");
        String name = "";
        java.util.regex.Matcher m = java.util.regex.Pattern.compile("filename\\*?=(?:UTF-8''|\")?([^;\"]+)", java.util.regex.Pattern.CASE_INSENSITIVE).matcher(disposition);
        if (m.find()) name = m.group(1).trim();
        if (name.isBlank()) name = safeValue(test.testName) + "_download.bin";
        name = name.replaceAll("[^a-zA-Z0-9._-]", "_");
        if (name.isBlank() || name.equals(".") || name.equals("..")) name = "attachment.bin";
        Path target = dir.resolve(UUID.randomUUID().toString().substring(0,8) + "_" + name);
        Files.write(target, response.body());
        return target;
    }

    private static void validateTestCase(ApiTestCase test) {
        String method = safeValue(test.method).trim().toUpperCase();
        String bodyType = safeValue(test.bodyType).trim().toUpperCase();

        if (safeValue(test.url).isEmpty()) {
            throw new IllegalArgumentException("URL is missing for test: " + safeValue(test.testName));
        }

        if (method.isEmpty()) {
            throw new IllegalArgumentException("HTTP method is missing for test: " + safeValue(test.testName));
        }

        if (bodyType.equals("RAW") || bodyType.equals("PAYLOAD")) {
            if (safeValue(test.payload).isEmpty()) {
                org.sodales.LogCollector.log("Warning: Payload is empty for test: " + safeValue(test.testName));
            }
        }

        if (bodyType.equals("FORM_DATA")) {
            if (safeValue(test.formData).isEmpty()) {
                org.sodales.LogCollector.log("Warning: FormData is empty for test: " + safeValue(test.testName));
            }
        }

        if (bodyType.equals("BINARY")) {
            if (safeValue(test.filePath).isEmpty()) {
                throw new IllegalArgumentException("Binary file path is missing for test: " + safeValue(test.testName));
            }
        }
    }

    private static HttpRequest.BodyPublisher buildBodyPublisher(
            ApiTestCase test, TestRunContext context, GlobalVariableHandler variableHandler) throws Exception {
        String bodyType = safeValue(test.bodyType).trim().toUpperCase(Locale.ROOT);
        switch (bodyType) {
            case "RAW": case "PAYLOAD":
                return HttpRequest.BodyPublishers.ofString(
                    variableHandler.globalvariablevaluereplacer(safeValue(test.payload)));
            case "BINARY":
                return HttpRequest.BodyPublishers.ofFile(
                    resolveUploadPath(context, variableHandler.globalvariablevaluereplacer(safeValue(test.filePath))));
            case "FORM_DATA":
                String boundary = "----Boundary" + UUID.randomUUID();
                CURRENT_MULTIPART_BOUNDARY.set(boundary);
                ParsedFormData parsed = parseFormData(variableHandler.globalvariablevaluereplacer(safeValue(test.formData)));
                // Excel's FilePath column is supported for multipart POST uploads, not only
                // BINARY uploads; "field=@/path" selects the form field name (default: file).
                String pathValue = variableHandler.globalvariablevaluereplacer(safeValue(test.filePath)).trim();
                if (!pathValue.isBlank() && !"NA".equalsIgnoreCase(pathValue)) {
                    String field = "file";
                    if (pathValue.contains("=@")) {
                        String[] chunks = pathValue.split("=@", 2);
                        field = chunks[0].trim(); pathValue = chunks[1].trim();
                    } else if (pathValue.startsWith("@")) pathValue = pathValue.substring(1);
                    if (field.isBlank()) field = "file";
                    parsed.files.put(field, resolveUploadPath(context, pathValue));
                }
                for (Map.Entry<String,Path> file : parsed.files.entrySet()) {
                    file.setValue(resolveUploadPath(context, file.getValue().toString()));
                }
                return buildMultipartBody(parsed.fields, parsed.files, boundary);
            case "NONE": case "": return HttpRequest.BodyPublishers.noBody();
            default: throw new IllegalArgumentException("Unsupported body type: " + bodyType);
        }
    }

    private static Path resolveUploadPath(TestRunContext context, String spreadsheetPath) throws IOException {
        String raw = safeValue(spreadsheetPath).trim();
        if (raw.startsWith("@")) raw = raw.substring(1);
        if (raw.isBlank()) throw new IOException("Attachment path is blank");
        Path direct = Path.of(raw);
        if (Files.isRegularFile(direct)) return direct;
        String base = raw.replace('\\', '/');
        base = base.substring(base.lastIndexOf('/') + 1).replaceAll("[^a-zA-Z0-9._-]", "_");
        String uploaded = context.uploadedAttachments.get(base);
        if (uploaded != null && Files.isRegularFile(Path.of(uploaded))) return Path.of(uploaded);
        throw new IOException("Attachment '" + raw + "' is unavailable to the server. "
                + "Upload it using Additional Attachments in the UI (matching the Excel filename).");
    }

    private static ParsedFormData parseFormData(String formDataText) {
        Map<String, String> fields = new LinkedHashMap<>();
        Map<String, Path> files = new LinkedHashMap<>();

        if (formDataText == null || formDataText.trim().isEmpty()) {
            return new ParsedFormData(fields, files);
        }

        String[] pairs = formDataText.split(";");
        for (String pair : pairs) {
            String[] parts = pair.split(":", 2);
            if (parts.length < 2) {
                continue;
            }

            String key = parts[0].trim();
            String value = parts[1].trim();

            if (value.startsWith("@")) {
                files.put(key, Path.of(value.substring(1)));
            } else {
                fields.put(key, value);
            }
        }

        return new ParsedFormData(fields, files);
    }

    private static HttpRequest.BodyPublisher buildMultipartBody(
            Map<String, String> fields,
            Map<String, Path> files,
            String boundary) throws Exception {

        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        PrintWriter writer = new PrintWriter(new OutputStreamWriter(bos, StandardCharsets.UTF_8), true);

        for (Map.Entry<String, String> entry : fields.entrySet()) {
            writer.append("--").append(boundary).append("\r\n");
            writer.append("Content-Disposition: form-data; name=\"")
                    .append(entry.getKey())
                    .append("\"\r\n");
            writer.append("\r\n");
            writer.append(entry.getValue()).append("\r\n");
            writer.flush();
        }

        for (Map.Entry<String, Path> entry : files.entrySet()) {
            if (!Files.isRegularFile(entry.getValue())) throw new IOException("Upload file not found: " + entry.getValue());
            String mimeType = Files.probeContentType(entry.getValue());
            if (mimeType == null) {
                mimeType = "application/octet-stream";
            }

            writer.append("--").append(boundary).append("\r\n");
            writer.append("Content-Disposition: form-data; name=\"")
                    .append(entry.getKey())
                    .append("\"; filename=\"")
                    .append(entry.getValue().getFileName().toString())
                    .append("\"\r\n");
            writer.append("Content-Type: ").append(mimeType).append("\r\n");
            writer.append("\r\n");
            writer.flush();

            Files.copy(entry.getValue(), bos);
            bos.write("\r\n".getBytes(StandardCharsets.UTF_8));
        }

        writer.append("--").append(boundary).append("--").append("\r\n");
        writer.flush();

        return HttpRequest.BodyPublishers.ofByteArray(bos.toByteArray());
    }

    private static class ParsedFormData {
        Map<String, String> fields;
        Map<String, Path> files;

        ParsedFormData(Map<String, String> fields, Map<String, Path> files) {
            this.fields = fields;
            this.files = files;
        }
    }

    private static void writeToCSV(
            String csvPath,
            String requestUrl,
            String requestHeaders,
            String expectedresponsecode,
            int responseCode,
            String expectedresponsebody,
            String responseBody) {
        File file = new File(csvPath);
        boolean fileExists = file.exists();

        try (CSVWriter writer = new CSVWriter(new FileWriter(csvPath, true))) {
            if (!fileExists) {
                writer.writeNext(new String[] {
                        "Request URL",
                        "Request Headers",
                        "Expected Response Code",
                        "Actual Response Code",
                        "Expected Response Body",
                        "Actual Response Body"
                });
            }
            writer.writeNext(new String[] {
                    requestUrl,
                    requestHeaders,
                    expectedresponsecode,
                    String.valueOf(responseCode),
                    expectedresponsebody,
                    responseBody
            });
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private static void writeToHTML(
            String htmlPath,
            String testName,
            String requestUrl,
            String requestHeaders,
            String expectedresponsecode,
            int responseCode,
            String expectedresponsebody,
            String responseBody) {
        File htmlFile = new File(htmlPath);

        try (BufferedWriter writer = new BufferedWriter(new FileWriter(htmlPath, true))) {
            if (!htmlFile.exists() || htmlFile.length() == 0) {
                writer.write(
                        "<html><head><style>" +
                                "body { font-family: Arial; padding: 20px; }" +
                                "table { border-collapse: collapse; width: 100%;}" +
                                "th, td { border: 1px solid #ddd; padding: 8px; vertical-align: top; }" +
                                "th { background-color: #f2f2f2; }" +
                                ".pass { background-color: #d4edda; }" +
                                ".fail { background-color: #f8d7da; }" +
                                "</style></head><body>" +
                                "<h2>API Debug Report</h2><table>");
                writer.write(
                        "<tr>" +
                                "<th>Test Name</th>" +
                                "<th>Request URL</th>" +
                                "<th>Request Headers</th>" +
                                "<th>Expected Response Code</th>" +
                                "<th>Actual Response Code</th>" +
                                "<th>Expected Response Body</th>" +
                                "<th>Actual Response Body</th>" +
                                "</tr>");
            }

            String status;
            if (!"NA".equalsIgnoreCase(expectedresponsebody)) {
                status = ((responseCode == Integer.parseInt(expectedresponsecode))
                        && responseBody.contains(expectedresponsebody)) ? "PASS" : "FAIL";
            } else {
                status = (responseCode == Integer.parseInt(expectedresponsecode)) ? "PASS" : "FAIL";
            }

            String rowClass = status.equals("PASS") ? "pass" : "fail";

            writer.write("<tr class='" + rowClass + "'>");
            writer.write("<td>" + escapeHTML(testName) + "</td>");
            writer.write("<td>" + escapeHTML(requestUrl) + "</td>");
            writer.write("<td><pre>" + escapeHTML(requestHeaders) + "</pre></td>");
            writer.write("<td>" + escapeHTML(expectedresponsecode) + "</td>");
            writer.write("<td>" + responseCode + "</td>");
            writer.write("<td><pre>" + escapeHTML(expectedresponsebody) + "</pre></td>");
            writer.write("<td><pre>" + escapeHTML(responseBody) + "</pre></td>");
            writer.write("</tr>");
            writer.flush();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private static ExtentReports getExtent(TestRunContext context) {
        return extentMap.computeIfAbsent(context.runId, runId -> {
            ExtentReports extent = new ExtentReports();
            ExtentSparkReporter spark = new ExtentSparkReporter(context.extentPath);
            extent.attachReporter(spark);
            return extent;
        });
    }

    private static void extendReport(
            // String extentPath,
            TestRunContext context,
            String testName,
            String requestUrl,
            String requestHeaders,
            String expectedresponsecode,
            int responseCode,
            String expectedresponsebody,
            String responseBody) {
        ExtentReports extent = getExtent(context);

        ExtentTest test = extent.createTest(testName);
        test.info(requestUrl);
        test.info(requestHeaders);
        test.info(expectedresponsecode);
        test.info(expectedresponsebody);

        Boolean responseflag;
        Boolean codeflag;

        if (responseCode == Integer.parseInt(expectedresponsecode)) {
            test.info("Response code matching");
            responseflag = true;
        } else {
            test.info("Response code not matching");
            responseflag = false;
        }

        if (expectedresponsebody.equalsIgnoreCase("NA")) {
            codeflag = true;
        } else {
            if (responseBody.contains(expectedresponsebody)) {
                test.info("Response body matching");
                codeflag = true;
            } else {
                test.info("Response body not matching");
                codeflag = false;
            }
        }

        if (responseflag && codeflag) {
            test.pass("Response Code and Response Body Matched");
        } else {
            test.fail("Either Response Body or Response Code or both of them not Matched");
        }

        test.info("Response Body").info(responseBody);
        extent.flush();
    }

    public static void closeRun(String runId) {
        ExtentReports extent = extentMap.remove(runId);
        if (extent != null) {
            try {
                extent.flush();
            } catch (Exception ignored) {
            }
        }
    }

    private static String escapeHTML(String text) {
        if (text == null) {
            return "";
        }
        return text.replace("&", "&amp;")
                .replace("<", "&lt;")
                .replace(">", "&gt;");
    }

    private static String safeValue(String value) {
        return value == null ? "" : value;
    }
}