package model;

public enum RunStatus { QUEUED, RUNNING, CANCELLING, CANCELLED, COMPLETED, FAILED }
