package model;

public class TestRunContext {
    public String runId;
    public String runDir;
    public String excelPath;
    public String htmlPath;
    public String extentPath;
    public String csvPath;
    public boolean reportPortalEnabled;
    public String projectName;
    // Browser-uploaded attachments are stored only under the isolated run directory.
    public final java.util.Map<String, String> uploadedAttachments = new java.util.concurrent.ConcurrentHashMap<>();
}
