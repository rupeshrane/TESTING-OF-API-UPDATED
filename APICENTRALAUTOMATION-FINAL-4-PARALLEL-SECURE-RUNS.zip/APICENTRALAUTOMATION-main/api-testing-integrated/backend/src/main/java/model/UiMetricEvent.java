package model;

public class UiMetricEvent {
    public String eventType;
    public String sessionId;
    public String pageName;
    public String path;
    public long activeSeconds;
    public String clientTimestamp;
}
