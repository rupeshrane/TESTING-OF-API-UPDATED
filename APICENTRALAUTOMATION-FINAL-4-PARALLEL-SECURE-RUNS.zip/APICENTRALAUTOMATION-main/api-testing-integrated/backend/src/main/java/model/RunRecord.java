package model;

import java.time.Instant;
import java.util.UUID;
import java.security.SecureRandom;
import java.util.Base64;
import java.util.concurrent.Future;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;

public class RunRecord {
    public final TestRunContext context;
    public final String cancelToken = UUID.randomUUID().toString() + UUID.randomUUID();
    /** Opaque read-capability; returned once when this run is created. */
    public final String accessToken = newAccessToken();
    /** SHA-256 fingerprint of the anonymous browser session owning this run. */
    public final String ownerSessionFingerprint;
    public final AtomicBoolean cancelRequested = new AtomicBoolean(false);
    public final AtomicInteger totalTests = new AtomicInteger(0);
    public final AtomicInteger executedTests = new AtomicInteger(0);
    public volatile Future<?> future;
    public volatile RunStatus status = RunStatus.QUEUED;
    public volatile String errorCode;
    public volatile String errorMessage;
    public final Instant createdAt = Instant.now();
    public volatile Instant startedAt;
    public volatile Instant completedAt;
    public RunRecord(TestRunContext context, String ownerSessionFingerprint) {
        this.context = context;
        this.ownerSessionFingerprint = ownerSessionFingerprint;
    }

    private static String newAccessToken() {
        byte[] secret = new byte[32];
        new SecureRandom().nextBytes(secret);
        return Base64.getUrlEncoder().withoutPadding().encodeToString(secret);
    }
}
