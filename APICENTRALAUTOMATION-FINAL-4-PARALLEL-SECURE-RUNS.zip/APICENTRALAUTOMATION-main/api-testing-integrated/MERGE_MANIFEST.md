# Merge guide — run ownership + prior QA Portal changes

**Base ZIP:** `APICENTRALAUTOMATION-main-UPDATED-4-PARALLEL-RUNS.zip`.
The full ZIP contains **all previously supplied features** and this new ownership protection. Use the *merge-only patch* ZIP if you already deployed that exact four-run version. Back up your current live project before copying.

## New files (ownership change only)
- `backend/src/main/java/org/sodales/PortalSessionService.java` — server-managed anonymous browser capability/session tokens.
- `frontend/src/utils/runOwnership.js` — frontend anonymous browser session and per-run token management.

## Modified files (ownership change only)
- `backend/src/main/java/model/RunRecord.java` — per-run access token and owner session fingerprint.
- `backend/src/main/java/org/sodales/RunManager.java` — associates owner session fingerprint with the run.
- `backend/src/main/java/org/sodales/ApiController.java` — session issue/resume and backend ownership checks on status, logs, report and cancel.
- `frontend/src/pages/ApiTestingPage.jsx` — send appropriate ownership headers for each run; retain run credentials in per-tab sessionStorage and restore after refresh.
- `QA_PORTAL_UPDATE_GUIDE.md` — updated endpoint contract/deployment guidance.
- `MERGE_MANIFEST.md` — this list.

## Prior enhancements **retained** in full ZIP
- Four concurrent worker threads by default, zero FIFO queue, HTTP 429 if full (`AsyncConfig.java`, `application.yml`).
- Cancel and partial results download in React and backend (`RunManager`, `ApiController`, runner).
- URL spaces + encoded variables (`HttpUriUtil`, `GlobalVariableHandler`).
- Multipart/selected attachments, POST ID capture, GET attachment save (`ApiTests`, `ApiTestRunner`, API page).
- Server-side UI metrics, daily logs and key-restricted metrics admin view (`UiMetricsService`, `UiMetricsController`, `MainLayout`, `UiMetricsAdmin`).
- `ReportPortalManager.java` untouched by this patch.

## Critical server deployment notes
1. Deploy **frontend and backend together**, because the new backend requires `X-QA-Session` and `X-Run-Access-Token` from the matching frontend. An old frontend paired with the secured backend will receive HTTP 403.
2. Restart the backend; in-memory old runs/session records cannot migrate. Download valuable reports **before deployment**. Four parallel runs remain the default (`QA_MAX_CONCURRENT_RUNS=4` overrides it).
3. Use the actual Windows Server backend address / reverse proxy in `VITE_API_BASE_URL`; HTTPS is recommended. Do not put tokens in browser URLs or server logs.
4. **No user login**: this isolates anonymous *browser sessions*, not known human identities. Closing the browser tab or clearing sessionStorage loses access; users sharing the same tab share its runs. Tokens stolen from browser code/devtools can be misused.
5. `AppRoutes.jsx` in the original supplied `main (3)` archive referenced five absent page components. The full ZIP retains the prior update's **labelled placeholders** for these pages; do NOT overwrite the real implementations when merging into your larger working portal. The merge-only patch excludes these placeholder pages entirely.
6. CORS currently permits all origins for compatibility. Restrict it to your hosted frontend origin behind your Windows deployment/reverse proxy before public exposure.

## Smoke tests
Run A and B in two different browser sessions, open browser developer tools and confirm:
- Both users can start jobs concurrently, up to the 4-run limit.
- A accesses own status/logs/report; B's session headers with A's Run ID return HTTP 403 (even when A's read-token is supplied).
- B's cancellation request for A's run returns HTTP 403; A can cancel and download completed rows.
- Run POST with attachment, capture ID, then GET/download file; inspect report ZIP.
- Review Windows Server `logs/ui-metrics` and admin metrics screen if enabled.
