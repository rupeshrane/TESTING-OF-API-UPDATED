import { useEffect } from "react";
import { NavLink, Outlet, useLocation } from "react-router-dom";
import { initUiMetrics, trackPageView } from "../utils/uiMetrics";
import logo from "../assets/sodales-Logos_White.png";
import "../styles/global.css";

const PAGE_NAMES = {
  "/": "API Automation", "/api-testing": "API Automation",
  "/testcase-generator": "AI Test Case Generator", "/rtm-generator": "RTM Generator",
  "/convert": "Template Converter", "/payload-encrypt-decrypt": "Encryption/Decryption",
  "/plugin": "Plugins / Utilities", "/ui-metrics-admin": "Restricted Metrics Console",
};

export default function MainLayout() {
  const location = useLocation();
  useEffect(() => { initUiMetrics(); }, []);
  useEffect(() => { trackPageView(PAGE_NAMES[location.pathname] || location.pathname, location.pathname); }, [location.pathname]);
  return (
    <div className="appShell">
      <div className="navbar">
        <div className="nav-left">
          <div className="header">
            <img src={logo} alt="Logo" className="logo" />
          </div>
          <span className="nav-title">QA Utilities For Testing </span>
        </div>

        <nav className="nav-right">
          <NavLink
            to="/api-testing"
            className={({ isActive }) =>
              `navTab ${isActive ? "navTabActive" : ""}`
            }
          >
            API Automation
          </NavLink>

          <NavLink
            to="/testcase-generator"
            className={({ isActive }) =>
              `navTab ${isActive ? "navTabActive" : ""}`
            }
          >
            AI Test Case Generator
          </NavLink>

          <NavLink
            to="/rtm-generator"
            className={({ isActive }) =>
              `navTab ${isActive ? "navTabActive" : ""}`
            }
          >
            RTM Generator
          </NavLink>

          <NavLink
            to="/convert"
            className={({ isActive }) =>
              `navTab ${isActive ? "navTabActive" : ""}`
            }
          >
            Template Converter
          </NavLink>

           <NavLink
            to="/payload-encrypt-decrypt"
            className={({ isActive }) =>
              `navTab ${isActive ? "navTabActive" : ""}`
            }
          >
            Encryption/Decryption
          </NavLink>

            <NavLink
            to="/plugin"
            className={({ isActive }) =>
              `navTab ${isActive ? "navTabActive" : ""}`
            }
          >
            Plugins / Utilities
          </NavLink>
        </nav>
      </div>

      <main className="mainContent">
        <Outlet />
      </main>

      <footer className="footer">
        © {new Date().getFullYear()} Sodales Solutions. All Rights Reserved.
      </footer>
    </div>
  );
}
