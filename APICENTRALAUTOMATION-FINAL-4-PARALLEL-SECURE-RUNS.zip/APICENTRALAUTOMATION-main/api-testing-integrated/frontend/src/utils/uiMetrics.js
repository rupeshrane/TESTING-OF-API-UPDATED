const API_BASE_URL = import.meta.env.VITE_API_BASE_URL || "http://localhost:9090";
const ENDPOINT = `${API_BASE_URL}/ui-metrics/event`;
const SESSION_ID_KEY = "qaPortalUiMetricsSessionId";
const SESSION_STARTED_KEY = "qaPortalUiMetricsStarted";
const ACTIVE_SECONDS_KEY = "qaPortalUiMetricsActiveSeconds";
const HEARTBEAT_MS = 30000;
const IDLE_AFTER_MS = 60000;

let initialized = false;
let lastActivityAt = Date.now();
let activeSeconds = Number(sessionStorage.getItem(ACTIVE_SECONDS_KEY) || 0);
let activeTimer = null;
let heartbeatTimer = null;
let lastPageKey = "";
let lastPageAt = 0;

function createId() {
  if (globalThis.crypto?.randomUUID) {
    return `ui_${globalThis.crypto.randomUUID()}`;
  }
  return `ui_${Date.now()}_${Math.random().toString(36).slice(2, 14)}`;
}

function sessionId() {
  let id = sessionStorage.getItem(SESSION_ID_KEY);
  if (!id) {
    id = createId();
    sessionStorage.setItem(SESSION_ID_KEY, id);
  }
  return id;
}

function payload(eventType, pageName = "", path = window.location.pathname) {
  return JSON.stringify({
    eventType,
    sessionId: sessionId(),
    pageName,
    path,
    activeSeconds,
    clientTimestamp: new Date().toISOString(),
  });
}

function send(eventType, pageName = "", path = window.location.pathname, useBeacon = false) {
  const body = payload(eventType, pageName, path);

  try {
    if (useBeacon && navigator.sendBeacon) {
      const blob = new Blob([body], { type: "text/plain;charset=UTF-8" });
      if (navigator.sendBeacon(ENDPOINT, blob)) return;
    }

    fetch(ENDPOINT, {
      method: "POST",
      headers: { "Content-Type": "text/plain;charset=UTF-8" },
      body,
      keepalive: true,
    }).catch(() => {
      // Usage metrics must never affect the portal experience.
    });
  } catch {
    // Usage metrics must never affect the portal experience.
  }
}

function markActivity() {
  lastActivityAt = Date.now();
}

function isActive() {
  return document.visibilityState === "visible" && Date.now() - lastActivityAt < IDLE_AFTER_MS;
}

export function initUiMetrics() {
  if (initialized) return;
  initialized = true;

  const alreadyStarted = sessionStorage.getItem(SESSION_STARTED_KEY) === "true";
  sessionStorage.setItem(SESSION_STARTED_KEY, "true");
  send(alreadyStarted ? "SESSION_RESUME" : "SESSION_START");

  ["pointerdown", "keydown", "scroll", "touchstart"].forEach((eventName) => {
    window.addEventListener(eventName, markActivity, { passive: true });
  });

  document.addEventListener("visibilitychange", () => {
    send(document.visibilityState === "visible" ? "VISIBLE" : "HIDDEN");
    if (document.visibilityState === "visible") markActivity();
  });

  activeTimer = window.setInterval(() => {
    if (isActive()) {
      activeSeconds += 1;
      sessionStorage.setItem(ACTIVE_SECONDS_KEY, String(activeSeconds));
    }
  }, 1000);

  heartbeatTimer = window.setInterval(() => {
    send("HEARTBEAT");
  }, HEARTBEAT_MS);

  window.addEventListener("pagehide", () => {
    sessionStorage.setItem(ACTIVE_SECONDS_KEY, String(activeSeconds));
    send("SESSION_END", "", window.location.pathname, true);
  });
}

export function trackPageView(pageName, path = window.location.pathname) {
  const key = `${pageName}|${path}`;
  const now = Date.now();

  // React StrictMode can execute effects twice in development.
  if (key === lastPageKey && now - lastPageAt < 1500) return;

  lastPageKey = key;
  lastPageAt = now;
  send("PAGE_VIEW", pageName, path);
}

// Use this for any nested tab inside a page that is not represented by a route.
export function trackTabVisit(tabName, path = window.location.pathname) {
  send("TAB_VIEW", tabName, path);
}
