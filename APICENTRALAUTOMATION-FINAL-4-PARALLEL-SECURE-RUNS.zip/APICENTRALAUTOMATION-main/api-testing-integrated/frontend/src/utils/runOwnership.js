// Anonymous session + per-run capabilities. Deliberately sessionStorage, not URL/query params.
// A tab's sessions are isolated; a server restart invalidates anonymous sessions and runs.
const API_BASE_URL = import.meta.env.VITE_API_BASE_URL || "http://localhost:9090";
const SESSION_KEY = "qaPortalAnonymousSessionV1";
const LAST_RUN_KEY = "qaPortalLastRunV1";
const RUN_KEY_PREFIX = "qaPortalRunV1:";
let inflightSession = null;

export async function ensurePortalSession() {
  if (inflightSession) return inflightSession;
  inflightSession = (async () => {
    const existing = sessionStorage.getItem(SESSION_KEY);
    const response = await fetch(`${API_BASE_URL}/portal-session`, {
      method: "POST",
      headers: existing ? { "X-QA-Session": existing } : {},
      cache: "no-store",
    });
    if (!response.ok) throw new Error(`Unable to establish portal session (${response.status})`);
    const body = await response.json();
    if (!body.sessionToken) throw new Error("Missing portal session token");
    // When the backend restarts or a session expires, old runs cannot be recovered.
    if (existing && existing !== body.sessionToken) sessionStorage.removeItem(LAST_RUN_KEY);
    sessionStorage.setItem(SESSION_KEY, body.sessionToken);
    return body.sessionToken;
  })();
  try { return await inflightSession; }
  finally { inflightSession = null; }
}

export function getRunHeaders(runId) {
  const ownerSession = sessionStorage.getItem(SESSION_KEY);
  const run = loadRun(runId);
  if (!ownerSession || !run?.accessToken) throw new Error("Run access is unavailable in this browser session.");
  return { "X-QA-Session": ownerSession, "X-Run-Access-Token": run.accessToken };
}

export function saveRun(runId, accessToken, cancelToken) {
  if (!runId || !accessToken) throw new Error("Backend did not return a Run Access Token.");
  const details = { runId, accessToken, cancelToken: cancelToken || "", autoDownloaded: false };
  sessionStorage.setItem(RUN_KEY_PREFIX + runId, JSON.stringify(details));
  sessionStorage.setItem(LAST_RUN_KEY, runId);
}

export function loadRun(runId) {
  if (!runId) return null;
  try { return JSON.parse(sessionStorage.getItem(RUN_KEY_PREFIX + runId) || "null"); }
  catch { return null; }
}

export function loadLastRun() { return loadRun(sessionStorage.getItem(LAST_RUN_KEY)); }

export function markAutoDownloaded(runId) {
  const run = loadRun(runId);
  if (run) {
    run.autoDownloaded = true;
    sessionStorage.setItem(RUN_KEY_PREFIX + runId, JSON.stringify(run));
  }
}
