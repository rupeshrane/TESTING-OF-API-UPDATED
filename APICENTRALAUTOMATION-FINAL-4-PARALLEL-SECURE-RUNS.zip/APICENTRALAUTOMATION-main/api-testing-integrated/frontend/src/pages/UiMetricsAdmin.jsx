import React, { useState } from "react";

const API_BASE_URL = import.meta.env.VITE_API_BASE_URL || "http://localhost:9090";

export default function UiMetricsAdmin() {
  const [key, setKey] = useState("");
  const [date, setDate] = useState(new Date().toLocaleDateString("en-CA"));
  const [summary, setSummary] = useState("");
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);

  async function getSummary() {
    setBusy(true); setError(""); setSummary("");
    try {
      const response = await fetch(`${API_BASE_URL}/ui-metrics/admin/summary?date=${encodeURIComponent(date)}`, {
        headers: { "X-UI-Metrics-Admin-Key": key }, cache: "no-store"
      });
      const text = await response.text();
      if (!response.ok) throw new Error(text || `Server error (${response.status})`);
      setSummary(text);
    } catch (err) { setError(err.message); }
    finally { setBusy(false); }
  }
  return (
    <div className="card metricsAdmin" style={{maxWidth:850,margin:"24px auto", padding:24}}>
      <h1>Server UI Usage Metrics</h1>
      <p>Restricted administrative view. No database is used. Access requires the admin key set on the server.</p>
      <div className="grid two">
        <div><label>Admin access key</label><input type="password" autoComplete="off" value={key} onChange={e => setKey(e.target.value)} /></div>
        <div><label>Usage date</label><input type="date" value={date} onChange={e => setDate(e.target.value)} /></div>
      </div>
      <button className="runBtn" disabled={busy || !key || !date} onClick={getSummary}>{busy ? "Loading..." : "View server metrics"}</button>
      {error && <div className="status" role="alert">{error}</div>}
      {summary && <pre style={{overflowX:"auto",whiteSpace:"pre",padding:18,background:"#f5f7fa",color:"#18212b",borderRadius:8,marginTop:20}}>{summary}</pre>}
    </div>
  );
}
